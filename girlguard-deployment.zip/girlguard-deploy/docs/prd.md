# Requirements Document

## 1. Application Overview

### 1.1 Application Name
girlGuard

### 1.2 Application Description
A private, on-device web application designed to help women and girls document online harassment, store evidence safely, track incidents, and generate reports for authorities or trusted adults. The application emphasizes safety, privacy, control, and empowerment with a colorful, soft aesthetic. All data is stored locally on the user's device with no external uploads.

### 1.3 Modification Scope
This release includes:
- Complete UI/UX redesign of the kidsGuard section (route /kids and all child pages) with new color system, refined layout structure, enhanced component styling, improved typography, and mobile-responsive design
- Addition of Download All Code functionality for exporting GitHub-ready source code
- Complete removal of chat feature and all related components
- Implementation of encryption for documentation content and sensitive user data in Supabase
- Strengthening of security measures including RLS policies and API key handling

All existing functionality and interactive logic remain unchanged.

## 2. Users and Usage Scenarios

### 2.1 Target Users
- Children aged 8-12 seeking to learn about online safety
- Parents and guardians looking for age-appropriate safety education tools for their children
- Educators using interactive resources for digital citizenship lessons
- Developers and administrators needing to export application source code

### 2.2 Core Usage Scenarios
- Children accessing kidsGuard to play safety games and complete activities
- Learning online safety concepts through interactive gameplay
- Completing daily safety missions and earning achievement badges
- Parents reviewing kidsGuard content and understanding its educational value
- Accessing emergency help resources when needed
- Developers downloading complete source code for GitHub deployment
- Users storing encrypted documentation and sensitive data securely

## 3. Page Structure and Functionality

### 3.1 Page Structure Overview

```
girlGuard Application
├── Login/Registration Page (unchanged)
├── Main Application Pages (unchanged)
├── Download All Code Button (NEW - accessible in layout header or developer section)
└── kidsGuard Section (/kids) (REDESIGNED UI/UX)
    ├── KidsLayout (Sidebar + Header + Footer)
    ├── KidsHomePage
    ├── KidsBullyingPage
    ├── KidsFeelingsPage
    ├── KidsSafeOnlinePage
    ├── KidsHelpPage
    ├── KidsResourcesPage
    └── KidsGamesPage
```

### 3.2 Download All Code Functionality (NEW)

#### 3.2.1 Download Button Placement
- Button located in accessible location (layout header or dedicated developer/admin section)
- Visible to authenticated users with appropriate permissions
- Clear labeling: \"Download All Code\"

#### 3.2.2 Code Export Functionality
- Clicking button triggers packaging of all source code into ZIP file
- ZIP file downloads to user's device
- File naming convention includes application name and timestamp

#### 3.2.3 ZIP File Contents
- Complete source code structure:
  + package.json
  + vite.config file
  + tsconfig file
  + src/ directory with all source files
  + public/ directory with all public assets
  + All configuration files
  + README with setup instructions
- Excludes:
  + node_modules/
  + .env files (template .env.example included)
  + Build artifacts
  + Git history

#### 3.2.4 GitHub-Ready Requirements
- Exported code must work immediately after:
  1. Unzipping archive
  2. Running npm install
  3. Running npm run dev
- No additional configuration required
- All dependencies specified in package.json
- Environment variable template provided

### 3.3 Chat Feature Removal (MODIFIED)

#### 3.3.1 Removed Components
- All chat interface components
- Chat-related routes
- Chat state management
- Chat-related edge functions
- Chat database tables and references

#### 3.3.2 Code Cleanup
- Remove all chat imports and references
- Clean up navigation items related to chat
- Remove chat-related API endpoints
- Update routing configuration

### 3.4 Data Encryption (NEW)

#### 3.4.1 Encrypted Data Types
- Documentation content stored in Supabase
- Sensitive user information
- Evidence preservation data
- Timeline tracking data
- Impact recording data
- Report generation data

#### 3.4.2 Encryption Implementation
- Data encrypted at rest in Supabase
- Encryption applied before storage
- Decryption applied on retrieval
- Only authenticated user can access their own encrypted data

#### 3.4.3 Access Control
- RLS policies enforce per-user data isolation
- User can only read/write their own data
- No cross-user data access permitted

### 3.5 Design System

#### 3.5.1 Color System (K Constants)

**Expanded Color Tokens:**
- Existing K colors retained
- K.surface: card background color
- K.panel: interactive panel background color
- K.border: default border color
- K.inputBg: input field background color
- K.quizBtn: unselected quiz button background
- K.quizBtnBorder: unselected quiz button border

**Color Usage Rules:**
- Replace all hardcoded white, #E2E8F0, #F8FAFC, #F8FFFE, #FEF2F2 with K tokens
- All colors applied via inline style={{}} using K constants
- Maintain theme coherence across all kidsGuard pages

#### 3.5.2 Typography

**Font Family:**
- Nunito font imported via Google Fonts

**Font Weight Hierarchy:**
- Headings: font-black
- Body text: font-bold
- Secondary text: font-semibold

**Font Sizes:**
- Hero headings: text-3xl md:text-5xl
- Section headings: text-2xl md:text-3xl
- Body text: text-base md:text-lg

#### 3.5.3 Spacing and Layout

**Content Width:**
- Content pages: max-w-3xl
- Section gaps: gap-10

**Touch Targets:**
- Minimum size: 48px for all interactive elements

**Responsive Breakpoints:**
- Mobile: 375px+
- Tablet/Desktop: md breakpoint

### 3.6 KidsLayout Component (Sidebar + Header + Footer)

#### 3.6.1 Sidebar

**Desktop Layout:**
- Width: 232px when expanded
- Navigation items with improved active state
- Active state: filled icon + left accent bar
- Refined spacing between items

**Mobile Layout:**
- Hamburger menu toggle
- Overlay sidebar on mobile

#### 3.6.2 Header

**Left Side:**
- Breadcrumb pill displaying current page name + icon

**Right Side:**
- Tagline text

#### 3.6.3 Footer

**Content:**
- kidsGuard brand text
- Parent corner note
- Clean minimal design

### 3.7 KidsHomePage (REDESIGNED)

#### 3.7.1 Hero Section

**Layout:**
- Full-width rounded-3xl gradient panel
- Shield icon displayed
- Large headline
- Feature pills below headline
- Two CTA buttons at bottom

**Styling:**
- Padding: py-10 md:py-14
- Subtle gradient background

#### 3.7.2 Stats Row

**Layout:**
- Four small cards in horizontal row

**Card Content:**
- Emoji icon
- Large value number
- Label text

#### 3.7.3 Daily Mission Card

**Styling:**
- Prominent card with yellow accent
- XP badge displayed
- Complete button

**Content:**
- Mission title
- Mission description
- Completion status indicator

#### 3.7.4 Tips Carousel

**Design:**
- Minimal design
- Left/right navigation arrows
- Tip text with tag pill

#### 3.7.5 Sections Grid

**Layout:**
- 2-column grid on md+
- 1-column on mobile

**Section Card Design:**
- Left colored accent border
- Icon box
- Label text
- Tag pill
- Description blurb
- Hover effect: scale-[1.02] + shadow lift + right arrow appears

**Seven Section Cards:**
1. Bullying section card
2. Feelings section card
3. Safe Online section card
4. Help section card
5. Resources section card
6. Games section card
7. Additional section card

#### 3.7.6 Safety Pledge

**Design:**
- Clean card with checklist items
- User can tick off items
- Confirm button at bottom

#### 3.7.7 Badges Section

**Layout:**
- 2×4 grid of badge circles

**Badge States:**
- Locked: gray background + locked icon
- Earned: colored background + emoji

#### 3.7.8 Reassurance Card

**Styling:**
- Green gradient background
- Checklist items
- Two action buttons

#### 3.7.9 Parent Corner

**Design:**
- Collapsible section
- Blue tint background
- Expands/collapses on click

**Content:**
- Information about kidsGuard purpose
- Guidance for parents

#### 3.7.10 Emergency Banner

**Styling:**
- Pink tint background
- 🆘 icon box
- Get Help Now button
- Always visible

### 3.8 KidsBullyingPage (REDESIGNED)

#### 3.8.1 Hero Section

**Layout:**
- Centered layout
- Large emoji with kids-bounce animation
- Clean heading: text-3xl md:text-5xl font-black
- One-line subtitle
- Colored info pill at bottom

**Styling:**
- Padding: py-10 md:py-14
- Rounded-3xl
- Subtle gradient background

#### 3.8.2 Activity Hub (4 Tabs)

**Tab Bar Design:**
- Rounded-2xl pills
- Emoji + label for each tab
- 4-across grid on desktop
- 2×2 grid on mobile
- Active tab: filled background
- Inactive tab: tinted background

**Panel Container:**
- Rounded-3xl
- Colored top header strip
- White interior background
- Proper padding inside

**Four Tabs:**
1. Is It Bullying game
2. What Would You Do scenarios
3. Quiz
4. Kind Words Builder

**Quiz Button Styling:**
- Unselected: K.quizBtn background + K.quizBtnBorder border
- Selected correct: green tint + green border
- Selected wrong: pink tint + pink border
- All buttons: rounded-2xl, font-bold, min-h-[44px], proper text padding

#### 3.8.3 4-Step Action Plan

**Design:**
- Four step cards
- Numbered indicators
- Clear action descriptions

#### 3.8.4 Reminder Card

**Content:**
- Reassurance message
- Supportive tone

### 3.9 KidsFeelingsPage (REDESIGNED)

#### 3.9.1 Hero Section

**Design:**
- Same hero structure as KidsBullyingPage
- Feelings-themed emoji and content

#### 3.9.2 Activity Hub (4 Tabs)

**Tab Bar and Panel:**
- Same design system as KidsBullyingPage

**Four Tabs:**
1. Feelings Wheel
2. Coping Toolkit
3. Mood Check-In
4. Calm Down Breathing

#### 3.9.3 When to Tell Adult Section

**Content:**
- Guidance on recognizing when to seek help
- Clear indicators

#### 3.9.4 Reassurance Card

**Design:**
- Supportive message
- Encouraging tone

### 3.10 KidsSafeOnlinePage (REDESIGNED)

#### 3.10.1 Hero Section

**Design:**
- Same hero structure as other pages
- Online safety themed content

#### 3.10.2 Safety Topics Grid

**Layout:**
- Grid of topic cards
- 2-column on md+, 1-column on mobile

**Card Design:**
- Icon + topic name
- Brief description
- Clickable to expand details

#### 3.10.3 Interactive Activities

**Activities Included:**
- Interactive quiz
- Scam-or-safe detector
- Password builder
- Other safety activities

**Activity Styling:**
- Consistent with activity hub design system
- Quiz buttons follow standard styling rules

### 3.11 KidsHelpPage (REDESIGNED)

#### 3.11.1 Hero Section

**Design:**
- Same hero structure
- Help-themed content

#### 3.11.2 Activity Hub (3 Tabs)

**Three Tabs:**
1. Who Can Help quiz
2. Brave Words Builder
3. What Happens Next card reveal

**Design:**
- Same tab bar and panel system
- 3-across on desktop, 2+1 on mobile

#### 3.11.3 Reassurance Section

**Content:**
- Supportive messaging
- Encouragement to seek help

### 3.12 KidsResourcesPage (REDESIGNED)

#### 3.12.1 Hero Section

**Design:**
- Same hero structure
- Resources-themed content

#### 3.12.2 Activity Hub (3 Tabs)

**Three Tabs:**
1. Hotlines flip cards
2. Safe Websites flip cards
3. Resources Quiz

**Flip Card Design:**
- Card flips on click
- Front: resource name + icon
- Back: details and contact info

#### 3.12.3 Reminder Section

**Content:**
- Reminder about available resources
- Encouragement to use them

### 3.13 KidsGamesPage (REDESIGNED)

#### 3.13.1 Hero Section

**Design:**
- Same hero structure
- Games-themed content

#### 3.13.2 Game Selector

**Desktop Layout:**
- Grid of game pill tabs

**Mobile Layout:**
- Horizontal scrollable pill tabs

**Eight Games:**
1. Snake game
2. Virus Buster
3. Safe Surfer
4. Memory game
5. Password Sprint
6. Encryption Decoder
7. Tower Defence
8. Crossword

#### 3.13.3 Game Container

**Design:**
- Clean panel with colored header strip
- White interior background
- Game content area with proper padding

**Game Logic:**
- All existing game state machines unchanged
- Only styling updated

### 3.14 Other Application Pages (UNCHANGED)

- Login/Registration Page
- Documentation pages
- Evidence preservation pages
- Timeline tracking pages
- Impact recording pages
- Report generation pages
- Action and healing resources pages
- All other existing girlGuard functionality

## 4. Business Rules and Logic

### 4.1 kidsGuard Access
- No login required to access /kids route and child pages
- Accessible from main girlGuard landing page
- Back to girlGuard link returns to main application

### 4.2 Navigation
- Sidebar navigation between kidsGuard pages
- Active page indicated with filled icon + left accent bar
- Breadcrumb in header shows current page

### 4.3 Daily Mission Logic
- Mission content determined by current day of week
- Seven unique missions cycle throughout week
- Completion status tracked in component state during session
- Status resets on page reload

### 4.4 Game and Activity Logic
- All existing game state machines unchanged
- Quiz scoring and feedback logic unchanged
- Interactive activity logic unchanged
- Only UI/UX styling updated

### 4.5 Achievement Badge System
- Badges earned by completing specific activities
- Badge status tracked in component state during session
- Visual celebration animation when badge unlocked
- No badge data persisted between sessions

### 4.6 Interactive Feedback
- Celebratory micro-animations trigger on activity completion
- Encouraging messages display throughout interactions
- Visual progress indicators update in real-time
- Positive reinforcement for all attempts

### 4.7 Emergency Help
- Emergency Help Button always visible on all pages
- Clicking button navigates to /public/action route
- No confirmation required for navigation

### 4.8 Responsive Behavior
- Activity hub tabs: 4×1 on desktop, 2×2 on mobile
- Section cards: 2-column on md+, 1-column on mobile
- Game selector: grid on desktop, horizontal scroll on mobile
- All touch targets minimum 48px

### 4.9 Code Export Logic (NEW)
- Download All Code button triggers ZIP generation
- ZIP packaging includes all necessary files for GitHub deployment
- Excludes node_modules, .env files, build artifacts, git history
- Includes .env.example template for environment variables
- Downloaded file named with application name and timestamp

### 4.10 Data Encryption Logic (NEW)
- All documentation and sensitive user data encrypted before storage in Supabase
- Encryption applied automatically on write operations
- Decryption applied automatically on read operations
- Encryption keys managed securely
- Only authenticated user can decrypt their own data

### 4.11 RLS Policy Enforcement (NEW)
- Row Level Security policies enforce per-user data isolation
- User can only access rows where user_id matches their authenticated user ID
- No public write access without authentication
- Read access restricted to data owner only
- Admin access handled through separate secure channels

### 4.12 API Key Security (NEW)
- All API keys handled server-side via Edge Functions
- No API keys or secrets exposed in client-side code
- Environment variables used for sensitive configuration
- Edge Functions act as secure proxy for external API calls

## 5. Exception and Boundary Conditions

| Scenario | Handling |
|----------|----------|
| Child accesses any /kids page directly | Page loads normally without login |
| Mobile viewport below 375px | Layout adapts gracefully, maintains minimum touch targets |
| Sidebar collapsed on mobile | Hamburger menu opens overlay sidebar |
| Activity hub tab switching | Active tab updates, panel content switches, no page reload |
| Quiz button rapid clicking | State updates appropriately, no errors |
| Game selector scrolling on mobile | Horizontal scroll enabled, smooth scrolling |
| Flip card interaction | Card flips on click, smooth animation |
| Safety pledge checklist | Items toggle on/off, confirm button enabled when all checked |
| Badge grid with locked badges | Locked badges display gray + lock icon, earned badges display color + emoji |
| Parent corner collapsed by default | Section expands on click, collapses on second click |
| Emergency banner always visible | Banner remains visible during scroll, button always accessible |
| Tips carousel at first/last item | Navigation arrows disable or loop to opposite end |
| Desktop viewport | Sidebar expanded by default, full layout visible |
| Tablet viewport | Layout adapts between mobile and desktop breakpoints |
| Color system K constants | All colors applied via inline style={{}}, no hardcoded hex in components |
| Typography inconsistency | Font weights strictly follow hierarchy: font-black for headings, font-bold for body, font-semibold for secondary |
| Download All Code button clicked | ZIP file generation initiated, download starts automatically |
| ZIP generation fails | Error message displayed, user prompted to retry |
| Downloaded ZIP file corrupted | User can re-download, file integrity verified |
| User attempts to access encrypted data without authentication | Access denied, redirect to login |
| User attempts to access another user's encrypted data | RLS policy blocks access, returns empty result |
| Encryption key unavailable | Error handled gracefully, user notified |
| Decryption fails | Error logged, user notified, data remains encrypted |
| Chat feature references remain after removal | All references cleaned up, no broken links or errors |
| API key exposed in client code | Build process fails validation, deployment blocked |
| Edge Function unavailable | Fallback error handling, user notified of service unavailability |

## 6. Acceptance Criteria

1. Download All Code button visible in accessible location (layout header or developer section)
2. Clicking Download All Code button generates ZIP file containing all source code
3. ZIP file includes package.json, vite.config, tsconfig, src/, public/, all configuration files
4. ZIP file excludes node_modules/, .env files, build artifacts, git history
5. ZIP file includes .env.example template
6. Unzipping and running npm install && npm run dev works immediately without additional configuration
7. All chat interface components removed from application
8. All chat routes removed from routing configuration
9. All chat-related edge functions removed
10. All chat database tables and references removed
11. No broken links or errors from chat feature removal
12. All documentation content in Supabase encrypted at rest
13. All sensitive user information in Supabase encrypted at rest
14. Encryption applied automatically before data storage
15. Decryption applied automatically on data retrieval
16. RLS policies enforce per-user data isolation
17. User can only read/write their own data
18. No cross-user data access permitted
19. No public write access without authentication
20. All API keys handled server-side via Edge Functions
21. No API keys or secrets exposed in client-side code
22. Environment variables used for sensitive configuration
23. KidsLayout sidebar width updated to 232px on desktop
24. Sidebar navigation items display filled icon + left accent bar when active
25. Header displays breadcrumb pill with current page name + icon on left
26. Header displays tagline on right side
27. Footer displays kidsGuard brand + parent corner note
28. All K color constants expanded to include K.surface, K.panel, K.border, K.inputBg, K.quizBtn, K.quizBtnBorder
29. All hardcoded white, #E2E8F0, #F8FAFC, #F8FFFE, #FEF2F2 replaced with K tokens
30. All colors applied via inline style={{}} using K constants
31. Nunito font applied across all kidsGuard pages
32. Font weights follow hierarchy: font-black for headings, font-bold for body, font-semibold for secondary
33. KidsHomePage hero section displays full-width rounded-3xl gradient panel with shield icon, headline, feature pills, two CTA buttons
34. KidsHomePage stats row displays four small cards with emoji + value + label
35. KidsHomePage daily mission card displays yellow accent, XP badge, complete button
36. KidsHomePage tips carousel displays minimal design with left/right arrows
37. KidsHomePage sections grid displays 2-column on md+, 1-column on mobile
38. Section cards display left colored accent border, icon box, label, tag pill, blurb
39. Section cards hover effect: scale-[1.02] + shadow lift + right arrow appears
40. KidsHomePage safety pledge displays checklist with confirm button
41. KidsHomePage badges section displays 2×4 grid with locked (gray + lock icon) and earned (color + emoji) states
42. KidsHomePage reassurance card displays green gradient with checklist and two buttons
43. KidsHomePage parent corner displays blue tint, collapses/expands on click
44. KidsHomePage emergency banner displays pink tint, 🆘 icon box, Get Help Now button
45. All page hero sections display centered layout, large emoji with kids-bounce, heading text-3xl md:text-5xl font-black, subtitle, colored info pill
46. All page hero sections use padding py-10 md:py-14, rounded-3xl, subtle gradient background
47. All activity hub tab bars display rounded-2xl pills with emoji + label
48. Activity hub tabs display 4-across on desktop, 2×2 on mobile
49. Activity hub panel containers display rounded-3xl, colored top header strip, white interior
50. Quiz buttons unselected state: K.quizBtn background + K.quizBtnBorder border
51. Quiz buttons selected correct state: green tint + green border
52. Quiz buttons selected wrong state: pink tint + pink border
53. All quiz buttons: rounded-2xl, font-bold, min-h-[44px], proper text padding
54. KidsGamesPage game selector displays grid on desktop, horizontal scrollable pills on mobile
55. KidsGamesPage game container displays clean panel with colored header strip
56. All interactive elements minimum touch target 48px
57. All pages responsive on 375px+ mobile viewports
58. Content pages use max-w-3xl width
59. Section gaps use gap-10 spacing
60. All existing game logic and interactive state machines unchanged
61. All existing kidsGuard functionality unchanged, only UI/UX styling updated
62. No dark mode in kidsGuard section
63. Readable contrast maintained for accessibility
64. Emergency Help Button navigates to /public/action on all pages
65. Back to girlGuard link navigates to main application
66. All girlGuard pages outside /kids section remain unchanged

## 7. Out of Scope for This Release

- Changes to girlGuard pages or functionality outside /kids section beyond Download All Code button and encryption
- Changes to existing game logic or interactive state machines
- New games or activities beyond existing eight games
- New pages beyond existing seven kidsGuard pages
- Dark mode for kidsGuard section
- New npm packages or dependencies beyond those required for ZIP generation and encryption
- User account system changes for kidsGuard section
- Parental controls or access restrictions
- Multi-language support for kidsGuard content
- Integration with external educational platforms
- Video content or tutorials
- Social features or sharing capabilities beyond code export
- Printable certificates or reports
- Advanced analytics or progress tracking across sessions
- Customizable avatars or profiles
- Multiplayer or competitive features
- In-app purchases or premium content
- Email notifications or reminders
- Integration with school curriculum standards
- Voice narration or audio content
- Augmented reality or 3D elements
- Changes to Google Fonts import method
- Migration away from inline style={{}} for K colors
- Automated deployment to GitHub
- Version control integration beyond code export
- Continuous integration/deployment pipelines
- Automated testing for encryption functionality
- Key rotation mechanisms for encryption keys
- Backup and recovery systems for encrypted data
- Multi-factor authentication
- Password strength requirements beyond existing implementation
- Session management changes
- Audit logging for data access
- Compliance certifications (GDPR, COPPA, etc.)
- Data retention policies
- Right to be forgotten implementation