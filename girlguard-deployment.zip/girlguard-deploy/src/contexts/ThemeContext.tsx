import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';

export type ThemeMode = 'girlguard' | 'clay' | 'orphism' | 'sage' | 'aurora' | 'rose' | 'calm' | 'focus' | 'comfort';

interface ThemeContextType {
  mode: ThemeMode;
  setMode: (mode: ThemeMode) => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [mode, setMode] = useState<ThemeMode>(() => {
    if (typeof window !== 'undefined') {
      const stored = localStorage.getItem('theme-mode');
      return (stored as ThemeMode) || 'girlguard';
    }
    return 'girlguard';
  });

  useEffect(() => {
    if (typeof window !== 'undefined') {
      localStorage.setItem('theme-mode', mode);
      document.documentElement.setAttribute('data-theme', mode);
    }
  }, [mode]);

  return (
    <ThemeContext.Provider value={{ mode, setMode }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const context = useContext(ThemeContext);
  if (context === undefined) {
    // Fallback — renders outside ThemeProvider (e.g. during SSR or test isolation)
    return {
      mode: 'girlguard' as ThemeMode,
      setMode: (_mode: ThemeMode) => {
        if (typeof window !== 'undefined') {
          document.documentElement.setAttribute('data-theme', _mode);
        }
      },
    };
  }
  return context;
}
