import { createRoot } from "react-dom/client";
import "./index.css";
import App from "./App.tsx";
import { AppWrapper } from "./components/common/PageMeta.tsx";

// Signal to index.html that the app has successfully started (hides the uncompiled warning)
;(window as any).__REACT_APP_STARTED__ = true;

createRoot(document.getElementById("root")!).render(
  <AppWrapper>
    <App />
  </AppWrapper>
);
