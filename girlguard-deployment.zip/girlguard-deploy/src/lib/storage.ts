// Local storage utilities for Digitally Fortified

const STORAGE_KEYS = {
  IDENTITY: 'df_identity',
  EVIDENCE: 'df_evidence',
  TIMELINE: 'df_timeline',
  IMPACT: 'df_impact',
  USER_NAME: 'df_user_name',
  PASSCODE: 'df_passcode',
} as const;

export const storage = {
  // Identity
  getIdentity: () => {
    const data = localStorage.getItem(STORAGE_KEYS.IDENTITY);
    return data ? JSON.parse(data) : { usernames: '', realName: '', otherDetails: '' };
  },
  setIdentity: (identity: unknown) => {
    localStorage.setItem(STORAGE_KEYS.IDENTITY, JSON.stringify(identity));
  },

  // Evidence
  getEvidence: () => {
    const data = localStorage.getItem(STORAGE_KEYS.EVIDENCE);
    return data ? JSON.parse(data) : [];
  },
  setEvidence: (evidence: unknown) => {
    localStorage.setItem(STORAGE_KEYS.EVIDENCE, JSON.stringify(evidence));
  },

  // Timeline
  getTimeline: () => {
    const data = localStorage.getItem(STORAGE_KEYS.TIMELINE);
    return data ? JSON.parse(data) : [];
  },
  setTimeline: (timeline: unknown) => {
    localStorage.setItem(STORAGE_KEYS.TIMELINE, JSON.stringify(timeline));
  },

  // Impact
  getImpact: () => {
    const data = localStorage.getItem(STORAGE_KEYS.IMPACT);
    return data ? JSON.parse(data) : { reportsFiled: '', impactJournal: '' };
  },
  setImpact: (impact: unknown) => {
    localStorage.setItem(STORAGE_KEYS.IMPACT, JSON.stringify(impact));
  },

  // User credentials
  getUserName: () => {
    return localStorage.getItem(STORAGE_KEYS.USER_NAME) || '';
  },
  setUserName: (name: string) => {
    localStorage.setItem(STORAGE_KEYS.USER_NAME, name);
  },

  getPasscode: () => {
    return localStorage.getItem(STORAGE_KEYS.PASSCODE) || '';
  },
  setPasscode: (passcode: string) => {
    localStorage.setItem(STORAGE_KEYS.PASSCODE, passcode);
  },

  // Clear all data
  clearAll: () => {
    Object.values(STORAGE_KEYS).forEach(key => {
      localStorage.removeItem(key);
    });
  },
};
