/**
 * downloadCode.ts
 *
 * Two download modes:
 *
 * PRODUCTION (import.meta.env.PROD === true)
 *   Fetches the currently-running built assets from the same origin and
 *   packages them into a ready-to-drop static ZIP.
 *   → Drop the ZIP directly on Netlify (netlify.app/drop) — no build needed.
 *
 * DEVELOPMENT (import.meta.env.PROD === false)
 *   Falls back to bundling the full TypeScript source tree so the user can
 *   connect a GitHub repo to Netlify / GitHub Pages and let the CI build run.
 *
 * srcBundle.generated.ts is written by src-bundle-plugin at config-resolve
 * time, guaranteeing the import resolves in both modes.
 */

import JSZip from 'jszip';
import allSourceFiles from './srcBundle.generated';

// ─── Shared constants ─────────────────────────────────────────────────────────

// Netlify SPA catch-all: rewrite every path to index.html so React Router
// handles routing.  Status 200 = silent rewrite (not a visible redirect).
// _redirects has NO file extension, so it must always be injected explicitly.
const NETLIFY_REDIRECTS = `/* /index.html 200\n`;

// ─── MODE A: Static deploy ZIP ───────────────────────────────────────────────
/**
 * Builds a ready-to-drop static ZIP by reading what the browser has ALREADY
 * loaded — no server fetch needed, works regardless of base-path or platform.
 *
 * Strategy:
 *  1. Query the live DOM for <script src> and <link rel="stylesheet"> elements
 *     that belong to this origin (these are the compiled Vite bundles).
 *  2. Check whether they're real bundles (hashed filenames) or TS source files.
 *     If they're TS source → fall through to source-code ZIP.
 *  3. Fetch each bundle (already in browser cache — instant).
 *  4. Strip any sub-path prefix (e.g. /app-id/assets/… → /assets/…) so the
 *     ZIP works when deployed to any Netlify domain root.
 *  5. Build a clean index.html referencing those root-absolute paths.
 *  6. Add _redirects so every React Router route works on direct access.
 *
 * ZIP layout:
 *   index.html
 *   assets/index-<hash>.js
 *   assets/index-<hash>.css
 *   favicon.png
 *   _redirects          (/* /index.html 200)
 */
async function downloadStaticDeploy(): Promise<void> {
  const origin = window.location.origin;
  // BASE_URL e.g. '/' (root deploy) or '/app-beb5sqrdjcox/' (sub-path deploy)
  const baseRaw  = import.meta.env.BASE_URL ?? '/';
  const basePath = baseRaw.endsWith('/') ? baseRaw.slice(0, -1) : baseRaw; // strip trailing /

  /** Remove sub-path prefix so /app-id/assets/x.js → /assets/x.js */
  const toRootPath = (pathname: string): string =>
    basePath && pathname.startsWith(basePath)
      ? pathname.slice(basePath.length) || '/'
      : pathname;

  // ── 1. Collect loaded same-origin JS bundles ───────────────────────────────
  const jsEntries: { zipPath: string; url: string }[] = [];
  for (const el of document.querySelectorAll('script[src]')) {
    const src = (el as HTMLScriptElement).src;
    if (!src || !src.startsWith(origin)) continue;
    const pathname  = new URL(src).pathname;
    const rootPath  = toRootPath(pathname);
    // If this is a TypeScript source file the dev server is serving we can't use it
    if (rootPath.endsWith('.tsx') || rootPath.endsWith('.ts')) {
      throw new Error('Dev-mode TS source detected — use git-based deploy instead.');
    }
    jsEntries.push({ zipPath: rootPath.startsWith('/') ? rootPath.slice(1) : rootPath, url: src });
  }

  if (jsEntries.length === 0) {
    throw new Error('No compiled JS bundles found in DOM — is the app built?');
  }

  // ── 2. Collect loaded same-origin CSS bundles ──────────────────────────────
  const cssEntries: { zipPath: string; url: string }[] = [];
  for (const el of document.querySelectorAll('link[rel="stylesheet"]')) {
    const href = (el as HTMLLinkElement).href;
    if (!href || !href.startsWith(origin)) continue;
    const pathname = new URL(href).pathname;
    const rootPath = toRootPath(pathname);
    cssEntries.push({ zipPath: rootPath.startsWith('/') ? rootPath.slice(1) : rootPath, url: href });
  }

  // ── 3. Collect loaded same-origin Images (for drag-and-drop perfection) ────
  const imgEntries: { zipPath: string; url: string }[] = [];
  for (const el of document.querySelectorAll('img[src]')) {
    const src = (el as HTMLImageElement).src;
    if (!src || !src.startsWith(origin)) continue;
    const pathname = new URL(src).pathname;
    const rootPath = toRootPath(pathname);
    imgEntries.push({ zipPath: rootPath.startsWith('/') ? rootPath.slice(1) : rootPath, url: src });
  }

  // ── 4. Favicon ─────────────────────────────────────────────────────────────
  let faviconHref = '/favicon.png'; // default
  for (const el of document.querySelectorAll('link[rel~="icon"]')) {
    const href = (el as HTMLLinkElement).href;
    if (href && href.startsWith(origin)) {
      faviconHref = toRootPath(new URL(href).pathname);
      break;
    }
  }
  const faviconZipPath = faviconHref.startsWith('/') ? faviconHref.slice(1) : faviconHref;
  const faviconUrl     = `${origin}${basePath}${faviconHref}`;

  // ── 5. Fetch all assets in parallel (already cached by the browser) ────────
  const zip = new JSZip();

  // Also include all public/ text files from the source bundle (e.g. SVGs, JSON)
  for (const [filePath, content] of Object.entries(allSourceFiles)) {
    if (filePath.startsWith('public/')) {
      const zipPath = filePath.substring(7); // strip 'public/'
      if (zipPath !== 'index.html' && zipPath !== '_redirects' && zipPath !== 'favicon.png') {
        zip.file(zipPath, content);
      }
    }
  }

  // Deduplicate entries by URL to avoid redundant fetches
  const uniqueAssets = new Map<string, string>();
  [...jsEntries, ...cssEntries, ...imgEntries].forEach(e => {
    uniqueAssets.set(e.url, e.zipPath);
  });

  await Promise.all([
    ...Array.from(uniqueAssets.entries()).map(async ([url, zipPath]) => {
      try {
        const r = await fetch(url);
        if (r.ok) zip.file(zipPath, await r.blob());
      } catch { /* non-fatal */ }
    }),
    (async () => {
      try {
        const r = await fetch(faviconUrl);
        if (r.ok) zip.file(faviconZipPath, await r.blob());
      } catch { /* non-fatal */ }
    })(),
  ]);

  // ── 6. Build a clean index.html with root-absolute asset paths ─────────────
  //    No SPA redirect script needed — Netlify's _redirects handles routing.
  const styleTags  = cssEntries.map(({ zipPath }) =>
    `  <link rel="stylesheet" crossorigin href="/${zipPath}">`).join('\n');
  const scriptTags = jsEntries.map(({ zipPath }) =>
    `  <script type="module" crossorigin src="/${zipPath}"></script>`).join('\n');

  const indexHtml = `<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <link rel="icon" href="${faviconHref}" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
${styleTags}
  </head>
  <body>
    <div id="root"></div>
${scriptTags}
  </body>
</html>`;

  zip.file('index.html', indexHtml);

  // ── 7. Netlify SPA catch-all ───────────────────────────────────────────────
  //    Status 200 = silent rewrite: browser URL stays as /dashboard etc. and
  //    React Router handles it — no 404 on direct access or page refresh.
  zip.file('_redirects', NETLIFY_REDIRECTS);

  // ── 8. Generate and download ───────────────────────────────────────────────
  const blob = await zip.generateAsync({
    type: 'blob',
    compression: 'DEFLATE',
    compressionOptions: { level: 6 },
  });
  triggerDownload(blob, `digitally-fortified-${today()}.zip`);
}

// ─── MODE B: Source code ZIP (DEV fallback) ───────────────────────────────────

// GitHub Pages: 404.html SPA redirect
// pathSegmentsToKeep is auto-detected at runtime:
//   0 → user/org site   (username.github.io)
//   1 → project site    (username.github.io/repo-name)
const PAGE_404 = `<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <title>Digitally Fortified</title>
    <script>
      var segments = window.location.pathname.split('/').filter(function(s){ return s.length > 0; });
      var pathSegmentsToKeep = segments.length > 1 ? 1 : 0;
      var l = window.location;
      l.replace(
        l.protocol + '//' + l.hostname + (l.port ? ':' + l.port : '') +
        l.pathname.split('/').slice(0, 1 + pathSegmentsToKeep).join('/') + '/?/' +
        l.pathname.slice(1).split('/').join('/').replace(/&/g, '~and~') +
        (l.search ? '&' + l.search.slice(1).replace(/&/g, '~and~') : '') +
        l.hash
      );
    <\/script>
  </head>
  <body></body>
</html>
`;

// GitHub Actions workflow — builds & pushes to gh-pages branch
const GITHUB_WORKFLOW = `name: Deploy to GitHub Pages

on:
  push:
    branches: [main, master]
  workflow_dispatch:

permissions:
  contents: write

jobs:
  deploy:
    runs-on: ubuntu-latest

    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Set up Node
        uses: actions/setup-node@v4
        with:
          node-version: '22'
          cache: 'npm'

      - name: Install dependencies
        run: npm install

      - name: Detect base path
        id: base
        run: |
          REPO="\${{ github.event.repository.name }}"
          OWNER="\${{ github.repository_owner }}"
          if [[ "\$REPO" == "\$OWNER.github.io" || "\$REPO" == "\$OWNER.github.com" ]]; then
            echo "VITE_BASE_PATH=/" >> "\$GITHUB_OUTPUT"
          else
            echo "VITE_BASE_PATH=/\$REPO" >> "\$GITHUB_OUTPUT"
          fi

      - name: Build
        run: npm run build
        env:
          VITE_SUPABASE_URL: \${{ secrets.VITE_SUPABASE_URL }}
          VITE_SUPABASE_ANON_KEY: \${{ secrets.VITE_SUPABASE_ANON_KEY }}
          VITE_BASE_PATH: \${{ steps.base.outputs.VITE_BASE_PATH }}

      - name: Deploy to gh-pages branch
        uses: JamesIves/github-pages-deploy-action@v4
        with:
          folder: dist
          branch: gh-pages
          clean: true
`;

const ENV_EXAMPLE = `# Digitally Fortified — environment variables
# Copy to .env and fill in your Supabase credentials.

VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key-here

# Optional: set the Vite base path for sub-path deployments (defaults to /).
# VITE_BASE_PATH=/my-repo-name
`;

const README = `# Digitally Fortified

React 18 · TypeScript · Vite · Tailwind CSS · shadcn/ui · Supabase

---

## Option 1 — Netlify drag-and-drop (fastest, no build needed)

Download the ZIP using the "Download Code" button in the app **while
the app is open in a browser** (it bundles the live compiled assets).

1. Go to **https://app.netlify.com/drop**
2. Drag the downloaded ZIP straight onto the page
3. Your site is live at \`https://random-name.netlify.app\`

> The ZIP already contains the compiled JS/CSS bundles and a \`_redirects\`
> file so every route (e.g. \`/dashboard\`) works without a 404.

---

## Option 2 — Netlify via GitHub (automatic deploys on push)

\`\`\`bash
# 1. Enter the extracted folder (do NOT push the outer folder)
unzip digitally-fortified-YYYY-MM-DD.zip
cd digitally-fortified

# 2. Init repo and push
git init && git add . && git commit -m "initial commit"
git remote add origin https://github.com/<you>/<repo>.git
git push -u origin main
\`\`\`

In the Netlify dashboard: **New site → Import from GitHub → select your repo**.
Netlify auto-reads \`netlify.toml\` (build command, publish dir, redirect rule).

Add environment variables under **Site settings → Environment variables**:

| Key | Value |
|---|---|
| \`VITE_SUPABASE_URL\` | your Supabase project URL |
| \`VITE_SUPABASE_ANON_KEY\` | your Supabase anon key |

---

## Option 3 — GitHub Pages

See the \`.github/workflows/deploy.yml\` included in this ZIP.

1. Push the repo contents to GitHub (same \`git init\` steps above).
2. Go to **Settings → Pages → Source: Deploy from a branch → gh-pages → / (root)**.
3. Add \`VITE_SUPABASE_URL\` and \`VITE_SUPABASE_ANON_KEY\` under
   **Settings → Secrets and variables → Actions**.
4. Push any commit to trigger the workflow.

---

## Local development

\`\`\`bash
npm install
cp .env.example .env   # fill in your Supabase credentials
npm run dev
\`\`\`

---

## Project structure

\`\`\`
src/
  components/   shadcn/ui + custom components
  pages/        One file per route
  contexts/     Auth & Theme providers
  hooks/        Reusable React hooks
  lib/          Utilities (Supabase client, helpers)
  services/     API / data-access layer
  types/        Shared TypeScript types
supabase/
  functions/    Edge Functions
  migrations/   Database migrations
\`\`\`

| Layer | Technology |
|---|---|
| Frontend | React 18, TypeScript, Vite |
| Styling | Tailwind CSS, shadcn/ui |
| Backend | Supabase (Postgres + Auth + Storage + Edge Functions) |
| Deploy | Netlify / GitHub Pages / Vercel |
`;

async function downloadSourceZip(): Promise<void> {
  const zip  = new JSZip();
  const root = zip.folder('digitally-fortified')!;

  for (const [filePath, content] of Object.entries(allSourceFiles)) {
    addToZip(root, filePath, content);
  }

  // Deployment helpers whose file names have no extension (scanner misses them)
  addToZip(root, 'public/_redirects',             NETLIFY_REDIRECTS);
  addToZip(root, '_redirects',                    NETLIFY_REDIRECTS); // For root dir in case of direct drag/drop
  addToZip(root, 'public/.nojekyll',              '');
  addToZip(root, '.github/workflows/deploy.yml',  GITHUB_WORKFLOW);
  addToZip(root, 'public/404.html',               PAGE_404);
  root.file('.env.example', ENV_EXAMPLE);
  root.file('README.md',    README);

  const blob = await zip.generateAsync({
    type: 'blob',
    compression: 'DEFLATE',
    compressionOptions: { level: 6 },
  });
  triggerDownload(blob, `digitally-fortified-source-${today()}.zip`);
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function addToZip(folder: JSZip, filePath: string, content: string): void {
  const parts = filePath.split('/');
  if (parts.length === 1) { folder.file(filePath, content); return; }
  let dir = folder;
  for (let i = 0; i < parts.length - 1; i++) dir = dir.folder(parts[i])!;
  dir.file(parts[parts.length - 1], content);
}

function today(): string {
  return new Date().toISOString().slice(0, 10);
}

function triggerDownload(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const a   = document.createElement('a');
  a.href     = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// ─── Public API ───────────────────────────────────────────────────────────────

/**
 * Downloads a deployable ZIP.
 *
 * Tries to build a static deploy ZIP from the currently loaded DOM assets
 * (works in any environment where the app is running as a compiled build).
 * Falls back to a source-code ZIP (for git-based CI/CD deploys) if the
 * static approach fails — e.g. when running under Vite's dev server.
 */
export async function downloadAllCode(): Promise<void> {
  try {
    await downloadStaticDeploy();
  } catch (err) {
    // Dev server or asset collection failed → fall back to source ZIP
    console.warn('[downloadCode] Static deploy bundle failed, using source ZIP:', err);
    
    // Alert the user so they know they cannot drag and drop this source code to Netlify
    // and must use GitHub instead to trigger the build.
    alert(
      "⚠️ You are downloading the SOURCE CODE.\n\n" +
      "You CANNOT drag and drop this zip directly to Netlify because it requires compilation.\n\n" +
      "To deploy this code to Netlify or Vercel:\n" +
      "1. Create a GitHub repository\n" +
      "2. Upload all extracted files to the repository\n" +
      "3. Import the repository into Netlify/Vercel (it will build automatically)"
    );

    await downloadSourceZip();
  }
}

