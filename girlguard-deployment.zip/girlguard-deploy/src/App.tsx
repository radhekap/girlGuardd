import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import IntersectObserver from '@/components/common/IntersectObserver';
import { Toaster } from '@/components/ui/sonner';

import { routes } from './routes';
import { AuthProvider } from '@/contexts/AuthContext';
import { ThemeProvider } from '@/contexts/ThemeContext';
import { RouteGuard } from '@/components/common/RouteGuard';

const App: React.FC = () => {
  // import.meta.env.BASE_URL is injected by Vite from the `base` config option.
  // • Local / Netlify / Vercel: BASE_URL = "/"  → basename = "/"  (no change)
  // • GitHub Pages project site (VITE_BASE_PATH=/repo-name): BASE_URL = "/repo-name/"
  //   → basename = "/repo-name" so React Router matches routes relative to the sub-path.
  const basename = (import.meta.env.BASE_URL ?? '/').replace(/\/$/, '') || '/';

  return (
    <Router basename={basename}>
      <ThemeProvider>
        <AuthProvider>
          <RouteGuard>
            <IntersectObserver />
            <div className="flex flex-col min-h-screen">
              <main className="flex-grow">
                <Routes>
                  {routes.map((route, index) => (
                    <Route
                      key={index}
                      path={route.path}
                      element={route.element}
                    />
                  ))}
                  <Route path="*" element={<Navigate to="/" replace />} />
                </Routes>
              </main>
            </div>
            <Toaster />
          </RouteGuard>
        </AuthProvider>
      </ThemeProvider>
    </Router>
  );
};

export default App;
