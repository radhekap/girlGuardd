import { ReactNode, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import {
  Shield, BookOpen, Heart, LifeBuoy, Scale,
  FileText, AlertTriangle, TrendingDown, ExternalLink, Info,
  BookMarked, Menu, Gamepad2, ArrowRight, ShieldAlert,
  ChevronLeft, ChevronRight, Download, Loader2,
} from 'lucide-react';
import AccessibilitySettings from '@/components/AccessibilitySettings';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import ThemeSwitcher from '@/components/common/ThemeSwitcher';
import { downloadAllCode } from '@/lib/downloadCode';
import { toast } from 'sonner';

interface PublicLayoutProps {
  children: ReactNode;
}

const navItems = [
  { path: '/public/info',             label: 'Home',               icon: BookOpen },
  { path: '/public/prevention',       label: 'Prevention & Stats', icon: Shield },
  { path: '/public/bullying',         label: 'Online Bullying',    icon: AlertTriangle },
  { path: '/public/digital-threats',  label: 'Digital Threats',    icon: ShieldAlert },
  { path: '/public/comparison',       label: 'Social Comparison',  icon: TrendingDown },
  { path: '/public/social-emotional', label: 'Social & Emotional', icon: Heart },
  { path: '/public/action',           label: 'Action & Healing',   icon: LifeBuoy },
  { path: '/public/games',            label: 'Games & Activities', icon: Gamepad2 },
  { path: '/public/documentation',    label: 'Documentation',      icon: FileText },
  { path: '/public/laws',             label: 'Laws',               icon: Scale },
  { path: '/public/resources',        label: 'Resources',          icon: ExternalLink },
  { path: '/public/about',            label: 'About',              icon: Info },
  { path: '/public/sources',          label: 'Sources',            icon: BookMarked },
];

interface SidebarNavProps {
  onNav: (path: string) => void;
  collapsed: boolean;
  onDownload: () => void;
  downloading: boolean;
}

function SidebarNav({ onNav, collapsed, onDownload, downloading }: SidebarNavProps) {
  const location = useLocation();

  return (
    <div className="flex flex-col h-full overflow-hidden">
      {/* Brand */}
      <div className={[
        'flex items-center border-b border-border shrink-0 transition-all duration-200',
        collapsed ? 'justify-center px-3 py-5' : 'gap-3 px-5 py-5',
      ].join(' ')}>
        <div className="h-7 w-7 rounded-lg flex items-center justify-center shrink-0 bg-primary">
          <Shield className="h-3.5 w-3.5 text-primary-foreground" strokeWidth={2.5} />
        </div>
        {!collapsed && (
          <span className="font-semibold text-sm tracking-tight gradient-text whitespace-nowrap">girlGuard</span>
        )}
      </div>

      {/* Nav links */}
      <nav className="flex-1 overflow-y-auto px-2 py-4 space-y-0.5">
        {navItems.map(({ path, label, icon: Icon }) => {
          const active = location.pathname === path ||
            (path === '/public/info' && location.pathname === '/public');
          return (
            <button
              key={path}
              onClick={() => onNav(path)}
              title={collapsed ? label : undefined}
              className={[
                'w-full flex items-center rounded-lg text-sm text-left transition-colors duration-150',
                collapsed ? 'justify-center px-0 py-2.5' : 'gap-3 px-3 py-2',
                active
                  ? 'bg-muted text-foreground font-medium'
                  : 'text-muted-foreground hover:text-foreground hover:bg-muted/60 font-normal',
              ].join(' ')}>
              <Icon
                className={['h-4 w-4 shrink-0 text-primary', active ? 'opacity-100' : 'opacity-50'].join(' ')}
                strokeWidth={active ? 2 : 1.75}
              />
              {!collapsed && <span className="truncate">{label}</span>}
            </button>
          );
        })}
      </nav>

      {/* Footer — hidden when collapsed */}
      {!collapsed && (
        <div className="px-4 py-5 border-t border-border space-y-2 shrink-0">
          <div className="flex items-center justify-between pb-1">
            <span className="text-[10px] font-semibold tracking-widest uppercase text-muted-foreground">Theme</span>
            <ThemeSwitcher />
          </div>
          <button
            onClick={() => onNav('/login')}
            className="w-full h-9 rounded-lg text-xs font-semibold text-primary-foreground bg-primary hover:opacity-90 transition-opacity">
            Sign In / Create Account
          </button>
          <button
            onClick={() => onNav('/kids')}
            className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm
                       border border-border text-muted-foreground hover:text-foreground hover:bg-muted/50 transition-colors">
            <Shield className="h-3.5 w-3.5 shrink-0 text-primary/70" strokeWidth={1.75} />
            kidsGuard (ages 8–12)
            <ArrowRight className="h-3 w-3 ml-auto opacity-40" />
          </button>
          <button
            onClick={onDownload}
            disabled={downloading}
            className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm
                       border border-border text-muted-foreground hover:text-foreground hover:bg-muted/50 transition-colors disabled:opacity-50">
            {downloading
              ? <Loader2 className="h-3.5 w-3.5 shrink-0 animate-spin" />
              : <Download className="h-3.5 w-3.5 shrink-0 text-primary/70" strokeWidth={1.75} />}
            {downloading ? 'Packing…' : 'Download Code'}
          </button>
        </div>
      )}

      {/* Collapsed footer — theme + kids + download icons */}
      {collapsed && (
        <div className="px-2 py-4 border-t border-border space-y-2 shrink-0 flex flex-col items-center">
          <ThemeSwitcher />
          <button
            onClick={() => onNav('/kids')}
            title="kidsGuard (ages 8–12)"
            className="h-8 w-8 flex items-center justify-center rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted/50 transition-colors">
            <Shield className="h-4 w-4 text-primary/70" strokeWidth={1.75} />
          </button>
          <button
            onClick={onDownload}
            disabled={downloading}
            title="Download all source code"
            className="h-8 w-8 flex items-center justify-center rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted/50 transition-colors disabled:opacity-50">
            {downloading
              ? <Loader2 className="h-4 w-4 animate-spin" />
              : <Download className="h-4 w-4 text-primary/70" strokeWidth={1.75} />}
          </button>
        </div>
      )}
    </div>
  );
}

export default function PublicLayout({ children }: PublicLayoutProps) {
  const navigate = useNavigate();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [collapsed, setCollapsed] = useState(false);
  const [downloading, setDownloading] = useState(false);

  const handleNav = (path: string) => {
    navigate(path);
    setMobileOpen(false);
  };

  const handleDownload = async () => {
    setDownloading(true);
    try {
      await downloadAllCode();
      toast.success('Source code downloaded — ready for GitHub!');
    } catch (err) {
      console.error('Download failed:', err);
      toast.error('Download failed. Please try again.');
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="min-h-screen w-full flex flex-col bg-background">

      {/* ── TOP BAR (mobile only) ───────────────────────────────── */}
      <header className="lg:hidden sticky top-0 z-40 bg-background border-b border-border h-12 flex items-center px-4 gap-3">
        <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
          <SheetTrigger asChild>
            <button
              className="h-8 w-8 flex items-center justify-center rounded-md
                         text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
              aria-label="Open navigation">
              <Menu className="h-4 w-4" />
            </button>
          </SheetTrigger>
          <SheetContent side="left" className="w-56 p-0 glass-sidebar">
            <SidebarNav onNav={handleNav} collapsed={false} onDownload={handleDownload} downloading={downloading} />
          </SheetContent>
        </Sheet>

        <button onClick={() => navigate('/public/info')} className="flex items-center gap-2 shrink-0">
          <div className="h-5 w-5 rounded flex items-center justify-center bg-primary">
            <Shield className="h-3 w-3 text-primary-foreground" strokeWidth={2.5} />
          </div>
          <span className="font-semibold text-sm tracking-tight text-foreground">girlGuard</span>
        </button>

        <div className="ml-auto flex items-center gap-1">
          <button
            onClick={handleDownload}
            disabled={downloading}
            title="Download all source code"
            className="h-8 px-2 flex items-center gap-1.5 rounded-md text-xs font-medium
                       text-muted-foreground hover:text-foreground hover:bg-muted transition-colors disabled:opacity-50">
            {downloading
              ? <Loader2 className="h-3.5 w-3.5 animate-spin" />
              : <Download className="h-3.5 w-3.5" />}
            <span className="hidden sm:inline">Code</span>
          </button>
          <AccessibilitySettings />
        </div>
      </header>

      {/* ── BODY ────────────────────────────────────────────────── */}
      <div className="flex flex-1 min-h-0">

        {/* ── DESKTOP SIDEBAR ──────────────────────────────────── */}
        <aside
          className={[
            'hidden lg:flex flex-col shrink-0 sticky top-0 h-screen glass-sidebar overflow-hidden',
            'transition-[width] duration-200 ease-in-out',
            collapsed ? 'w-14' : 'w-56',
          ].join(' ')}>

          {/* Accessibility + collapse toggle row */}
          <div className={[
            'flex items-center border-b border-border shrink-0 h-11',
            collapsed ? 'justify-center px-2' : 'justify-between px-4',
          ].join(' ')}>
            {!collapsed && <AccessibilitySettings />}
            <button
              onClick={() => setCollapsed(c => !c)}
              aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
              className="h-7 w-7 flex items-center justify-center rounded-md
                         text-muted-foreground hover:text-foreground hover:bg-muted transition-colors shrink-0">
              {collapsed
                ? <ChevronRight className="h-4 w-4" />
                : <ChevronLeft className="h-4 w-4" />}
            </button>
          </div>

          <SidebarNav onNav={(path) => navigate(path)} collapsed={collapsed} onDownload={handleDownload} downloading={downloading} />
        </aside>

        {/* ── MAIN CONTENT ─────────────────────────────────────── */}
        <main className="flex-1 min-w-0 flex flex-col page-bg">
          <div className="blob-mid" aria-hidden="true" />
          <div className="flex-1 min-w-0 overflow-x-hidden px-4 md:px-8 py-6 md:py-8 animate-fade-in">
            {children}
          </div>

          {/* ── FOOTER ──────────────────────────────────────────── */}
          <footer className="border-t border-border mt-auto">
            <div className="px-4 md:px-8 py-5 space-y-3">
              <p className="text-xs text-muted-foreground text-pretty leading-relaxed">
                <strong className="text-foreground/70">Educational &amp; documentation tool only.</strong>{' '}
                Nothing on girlGuard constitutes legal, medical, or professional advice.
                Always consult a qualified professional for guidance specific to your situation.
              </p>
              <div className="flex flex-wrap items-center justify-between gap-x-4 gap-y-1">
                <p className="text-[11px] text-muted-foreground/70">
                  © {new Date().getFullYear()} girlGuard — independent student project
                </p>
                <div className="flex flex-wrap items-center gap-x-4 gap-y-1">
                  {[
                    { label: 'Terms of Use', path: '/terms' },
                    { label: 'Privacy Policy', path: '/privacy' },
                    { label: 'Sources', path: '/public/sources' },
                    { label: 'About', path: '/public/about' },
                  ].map(({ label, path }) => (
                    <button
                      key={path}
                      onClick={() => navigate(path)}
                      className="text-[11px] text-muted-foreground hover:text-foreground underline underline-offset-4 transition-colors">
                      {label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </footer>
        </main>
      </div>
    </div>
  );
}

