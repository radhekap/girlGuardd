import { Button } from '@/components/ui/button';
import { useTheme, type ThemeMode } from '@/contexts/ThemeContext';
import { Palette, Check } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

interface ThemeDef {
  value: ThemeMode;
  label: string;
  description: string;
  swatches: [string, string, string]; // bg, primary, accent
}

const themes: ThemeDef[] = [
  {
    value: 'girlguard',
    label: 'girlGuard',
    description: 'Soft pink · Default',
    swatches: ['hsl(350 100% 98%)', 'hsl(340 100% 70%)', 'hsl(270 100% 92%)'],
  },
  {
    value: 'clay',
    label: 'Clay',
    description: 'Claymorphism · Peach & sage',
    swatches: ['hsl(30 60% 96%)', 'hsl(15 80% 62%)', 'hsl(140 35% 85%)'],
  },
  {
    value: 'orphism',
    label: 'Orphism',
    description: 'Warm colour fields · Gold & teal',
    swatches: ['hsl(45 55% 96%)', 'hsl(35 90% 55%)', 'hsl(175 55% 82%)'],
  },
  {
    value: 'sage',
    label: 'Sage',
    description: 'Earthy green · Natural',
    swatches: ['hsl(130 25% 96%)', 'hsl(150 45% 42%)', 'hsl(50 55% 82%)'],
  },
  {
    value: 'aurora',
    label: 'Aurora',
    description: 'Northern lights · Teal & violet',
    swatches: ['hsl(200 45% 96%)', 'hsl(185 70% 45%)', 'hsl(290 60% 82%)'],
  },
  {
    value: 'rose',
    label: 'Rose',
    description: 'Deep rose · Romantic & soft',
    swatches: ['hsl(350 50% 97%)', 'hsl(345 65% 52%)', 'hsl(310 40% 88%)'],
  },
  {
    value: 'calm',
    label: 'Calm',
    description: 'Soft blue-grey · Peaceful',
    swatches: ['hsl(210 20% 98%)', 'hsl(210 25% 35%)', 'hsl(210 20% 94%)'],
  },
  {
    value: 'comfort',
    label: 'Comfort',
    description: 'Warm amber · Cosy',
    swatches: ['hsl(30 25% 97%)', 'hsl(30 30% 40%)', 'hsl(30 25% 93%)'],
  },
];

export default function ThemeSwitcher() {
  const { mode, setMode } = useTheme();
  const current = themes.find(t => t.value === mode) ?? themes[0];

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="sm" className="gap-2 h-8 px-2.5">
          {/* mini swatch strip */}
          <span className="flex gap-0.5 items-center">
            {current.swatches.map((c, i) => (
              <span key={i} className="h-3 w-3 rounded-full border border-border/40 shrink-0"
                style={{ background: c }} />
            ))}
          </span>
          <Palette className="h-3.5 w-3.5 shrink-0" />
          <span className="hidden md:inline text-xs font-medium">{current.label}</span>
        </Button>
      </DropdownMenuTrigger>

      <DropdownMenuContent align="end" className="w-64 p-2">
        <p className="text-[10px] font-semibold tracking-widest uppercase text-muted-foreground px-2 pb-2">
          Theme
        </p>
        <div className="grid grid-cols-2 gap-1.5">
          {themes.map(theme => {
            const active = mode === theme.value;
            return (
              <button key={theme.value} onClick={() => setMode(theme.value)}
                className={[
                  'flex flex-col gap-2 p-2.5 rounded-lg border text-left transition-colors duration-150',
                  active
                    ? 'border-primary bg-primary/5'
                    : 'border-border hover:border-primary/40 hover:bg-muted/60',
                ].join(' ')}>
                {/* swatch row */}
                <div className="flex items-center gap-1">
                  {theme.swatches.map((c, i) => (
                    <span key={i}
                      className={['rounded-full border border-border/30 shrink-0', i === 1 ? 'h-4 w-4' : 'h-3 w-3'].join(' ')}
                      style={{ background: c }} />
                  ))}
                  {active && <Check className="h-3 w-3 text-primary ml-auto shrink-0" strokeWidth={2.5} />}
                </div>
                <div className="min-w-0">
                  <p className="text-xs font-semibold text-foreground leading-none truncate">{theme.label}</p>
                  <p className="text-[10px] text-muted-foreground leading-snug mt-0.5 text-pretty">{theme.description}</p>
                </div>
              </button>
            );
          })}
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
