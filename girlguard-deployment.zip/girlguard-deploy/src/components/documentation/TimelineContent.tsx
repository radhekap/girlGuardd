import { useState, useEffect } from'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from'@/components/ui/card';
import { Input } from'@/components/ui/input';
import { Label } from'@/components/ui/label';
import { Textarea } from'@/components/ui/textarea';
import { Button } from'@/components/ui/button';
import { storage } from'@/lib/storage';
import type { TimelineEntry } from'@/types/types';
import { Calendar, Trash2 } from'lucide-react';
import { toast } from'sonner';

export default function TimelineContent() {
  const [timeline, setTimeline] = useState<TimelineEntry[]>(() => storage.getTimeline());
  const [newEntry, setNewEntry] = useState({
    date:'',
    time:'',
    platform:'',
    description:'',
  });

  const handleAddEntry = () => {
    if (!newEntry.date || !newEntry.time || !newEntry.platform || !newEntry.description) {
      toast.error('Please fill in all fields');
      return;
    }

    const entry: TimelineEntry = {
      id: crypto.randomUUID(),
      ...newEntry,
      createdAt: new Date().toISOString(),
    };

    const updatedTimeline = [...timeline, entry].sort((a, b) => 
      new Date(`${b.date} ${b.time}`).getTime() - new Date(`${a.date} ${a.time}`).getTime()
    );

    setTimeline(updatedTimeline);
    storage.setTimeline(updatedTimeline);
    setNewEntry({ date:'', time:'', platform:'', description:'' });
    toast.success('Timeline entry added');
  };

  const handleDeleteEntry = (id: string) => {
    const updatedTimeline = timeline.filter(e => e.id !== id);
    setTimeline(updatedTimeline);
    storage.setTimeline(updatedTimeline);
    toast.success('Entry deleted');
  };

  return (
    <div className="space-y-8">
      <div className="space-y-2">
        <h2 className="text-2xl font-light">Timeline</h2>
        <p className="text-muted-foreground">
          Log every incident with dates, times, and details to build a clear pattern.
        </p>
      </div>

      <Card className="card-hover">
        <CardHeader>
          <CardTitle className="text-xl font-light">Add Incident</CardTitle>
          <CardDescription>
            Record each interaction or incident as it happens
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="date">Date</Label>
              <Input
                id="date"
                type="date"
                value={newEntry.date}
                onChange={(e) => setNewEntry(prev => ({ ...prev, date: e.target.value }))}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="time">Time</Label>
              <Input
                id="time"
                type="time"
                value={newEntry.time}
                onChange={(e) => setNewEntry(prev => ({ ...prev, time: e.target.value }))}
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="platform">Platform</Label>
            <Input
              id="platform"
              placeholder="e.g., Instagram, Snapchat, Discord"
              value={newEntry.platform}
              onChange={(e) => setNewEntry(prev => ({ ...prev, platform: e.target.value }))}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="description">What Happened</Label>
            <Textarea
              id="description"
              placeholder="Describe the incident in detail..."
              value={newEntry.description}
              onChange={(e) => setNewEntry(prev => ({ ...prev, description: e.target.value }))}
              rows={4}
            />
          </div>
          <Button onClick={handleAddEntry} className="w-full md:w-auto">
            Save to Timeline
          </Button>
        </CardContent>
      </Card>

      {timeline.length > 0 && (
        <Card className="card-hover">
          <CardHeader>
            <CardTitle className="text-xl font-light">Timeline Entries</CardTitle>
            <CardDescription>
              {timeline.length} incident{timeline.length !== 1 ?'s' :''} recorded
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {timeline.map((entry) => (
              <Card key={entry.id}>
                <CardContent className="p-4">
                  <div className="flex items-start gap-4">
                    <Calendar className="h-5 w-5 text-primary shrink-0 mt-1" />
                    <div className="flex-1 min-w-0 space-y-2">
                      <div className="flex items-start justify-between gap-4">
                        <div>
                          <p className="text-sm font-medium">
                            {new Date(entry.date).toLocaleDateString()} at {entry.time}
                          </p>
                          <p className="text-xs text-muted-foreground">{entry.platform}</p>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDeleteEntry(entry.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                      <p className="text-sm text-muted-foreground whitespace-pre-wrap">
                        {entry.description}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
