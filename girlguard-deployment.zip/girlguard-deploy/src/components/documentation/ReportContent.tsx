import { useState } from'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from'@/components/ui/card';
import { Button } from'@/components/ui/button';
import { Textarea } from'@/components/ui/textarea';
import { storage } from'@/lib/storage';
import { FileText, Printer } from'lucide-react';
import { toast } from'sonner';

export default function ReportContent() {
  const [report, setReport] = useState('');

  const generateReport = () => {
    const identity = storage.getIdentity();
    const evidence = storage.getEvidence();
    const timeline = storage.getTimeline();
    const impact = storage.getImpact();

    let reportText ='=== INCIDENT SUMMARY REPORT ===\n\n';
    reportText += `Generated: ${new Date().toLocaleString()}\n\n`;

    reportText +='--- IDENTITY INFORMATION ---\n';
    if (identity.usernames) reportText += `Usernames/Handles: ${identity.usernames}\n`;
    if (identity.realName) reportText += `Real Name: ${identity.realName}\n`;
    if (identity.otherDetails) reportText += `Other Details: ${identity.otherDetails}\n`;
    reportText +='\n';

    reportText +='--- EVIDENCE FILES ---\n';
    if (evidence.length > 0) {
      evidence.forEach((file: { fileName: string; uploadedAt: string; hash: string }, index: number) => {
        reportText += `${index + 1}. ${file.fileName}\n`;
        reportText += `   Uploaded: ${new Date(file.uploadedAt).toLocaleString()}\n`;
        reportText += `   SHA-256 Hash: ${file.hash}\n\n`;
      });
    } else {
      reportText +='No evidence files uploaded.\n\n';
    }

    reportText +='--- TIMELINE OF INCIDENTS ---\n';
    if (timeline.length > 0) {
      timeline.forEach((entry: { date: string; time: string; platform: string; description: string }, index: number) => {
        reportText += `${index + 1}. ${entry.date} at ${entry.time} - ${entry.platform}\n`;
        reportText += `   ${entry.description}\n\n`;
      });
    } else {
      reportText +='No timeline entries recorded.\n\n';
    }

    reportText +='--- REPORTS FILED ---\n';
    reportText += impact.reportsFiled ||'No reports filed yet.\n';
    reportText +='\n\n';

    reportText +='--- IMPACT STATEMENT ---\n';
    reportText += impact.impactJournal ||'No impact statement recorded.\n';
    reportText +='\n\n';

    reportText +='=== END OF REPORT ===\n';

    setReport(reportText);
    toast.success('Report generated successfully');
  };

  const handlePrint = () => {
    if (!report) {
      toast.error('Please generate a report first');
      return;
    }
    window.print();
  };

  return (
    <div className="space-y-8">
      <div className="space-y-2">
        <h2 className="text-2xl font-light">Generate Report</h2>
        <p className="text-muted-foreground">
          Compile all your documentation into a comprehensive summary for authorities or trusted adults.
        </p>
      </div>

      <Card className="card-hover">
        <CardHeader>
          <CardTitle className="text-xl font-light">Incident Summary</CardTitle>
          <CardDescription>
            This report includes all evidence, timeline entries, and impact information
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex gap-4">
            <Button onClick={generateReport} className="gap-2">
              <FileText className="h-4 w-4" />
              Generate Report
            </Button>
            {report && (
              <Button onClick={handlePrint} variant="secondary" className="gap-2">
                <Printer className="h-4 w-4" />
                Print / Save as PDF
              </Button>
            )}
          </div>

          {report && (
            <div className="space-y-2">
              <Textarea
                value={report}
                readOnly
                rows={20}
                className="font-mono text-sm"
              />
              <p className="text-xs text-muted-foreground">
                You can copy this text or use the Print button to save as PDF
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
