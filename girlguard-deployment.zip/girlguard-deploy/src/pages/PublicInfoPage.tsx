import PublicLayout from'@/components/layouts/PublicLayout';
import {
  Shield, Heart, BookOpen, Scale, LifeBuoy, FileText,
  TrendingUp, ExternalLink, Info, Send, CheckCircle2, ArrowRight, Hash,
  Clock, Activity, Download, HeartHandshake, CheckCircle,
  Lightbulb, Zap, ShieldCheck, Trophy, Star,
  Sparkles, LayoutGrid, Target, ClipboardList, MessagesSquare,
  ChevronDown,
} from'lucide-react';
import { useNavigate } from'react-router-dom';
import AnimatedCounter from'@/components/AnimatedCounter';
import { useState } from'react';
import { Textarea } from'@/components/ui/textarea';
import { Input } from'@/components/ui/input';
import { Label } from'@/components/ui/label';
import { toast } from'sonner';

// ─── PALETTE ──────────────────────────────────────────────────────────────────

const G = {
  pink:'#FF6B9D',
  purple:'#B794F6',
  grad:'linear-gradient(135deg, #FF6B9D 0%, #B794F6 100%)',
  gradSoft:'linear-gradient(135deg, rgba(255,107,157,0.12) 0%, rgba(183,148,246,0.12) 100%)',
};

// ─── SHIELD ORB ───────────────────────────────────────────────────────────────

function ShieldOrb() {
  return (
    <div className="relative flex items-center justify-center select-none" style={{ width: 260, height: 260 }}>
      {/* Pulsing rings */}
      <div className="shield-ring shield-ring-1" />
      <div className="shield-ring shield-ring-2" />
      <div className="shield-ring shield-ring-3" />
      <div className="shield-ring shield-ring-4" />
      {/* Rotating arcs */}
      <div className="shield-arc shield-arc-1" />
      <div className="shield-arc shield-arc-2" />
      {/* Core */}
      <div className="relative z-10 h-28 w-28 rounded-full flex items-center justify-center"
        style={{ background: G.grad, animation: 'coreGlow 4s ease-in-out infinite' }}>
        <Shield className="h-12 w-12 text-white" strokeWidth={1.5} />
      </div>
      {/* Floating word pills */}
      <span className="orb-word orb-word-1">Privacy</span>
      <span className="orb-word orb-word-2">Safety</span>
      <span className="orb-word orb-word-3">Strength</span>
      <span className="orb-word orb-word-4">Respect</span>
      <span className="orb-word orb-word-5">Awareness</span>
    </div>
  );
}

// ─── DATA ─────────────────────────────────────────────────────────────────────

const dailyTips = [
  { emoji:'', tip:'Use a different password for every account — a password manager makes this easy.' },
  { emoji:'', tip: "Before you post a photo, check what's visible in the background — location details can reveal more than you think." },
  { emoji:'', tip: "Set your social media profiles to private. You decide who sees your life." },
  { emoji:'', tip: "If someone online makes you feel uncomfortable, you don't owe them a reply. Block and move on." },
  { emoji:'', tip: "Check before you believe. Screenshots can be edited — verify news on official sites before sharing." },
  { emoji:'', tip: "Never share your location in real time — even with people you think you know online." },
  { emoji:'', tip: "Two-factor authentication (2FA) on your accounts is one of the single most effective safety steps you can take." },
  { emoji:'', tip: "Asking for help isn't weakness — it's the smartest move you can make." },
  { emoji:'', tip: "You don't need to accept every friend request. Curating your circle is self-care." },
  { emoji:'', tip: "Turn off location sharing on apps that don't actually need it — most of them don't." },
];

const quizQuestions = [
  {
    q: "You get a DM from someone you've never met:'You look amazing in your profile pic  Let's be friends!' What's the wisest move?",
    options: [
      "Accept — it's a compliment, seems harmless",
      "Ignore or decline — you don't know this person",
      "Reply and get to know them — what could go wrong?",
    ],
    correct: 1,
    explain: "Compliments from strangers online can be genuine — but they can also be a tactic to build trust before asking for something. You don't owe anyone a response, and protecting your circle is smart, not rude.",
  },
  {
    q: "A quiz online promises to tell you'What kind of girl are you?' It asks for your name, birthday, school, and suburb. Should you fill it in?",
    options: [
      "Yes — it's just a fun quiz!",
      "No — that's way too much personal info for a quiz",
      "Only fill in your first name",
    ],
    correct: 1,
    explain: "Fun quizzes are often data-harvesting tools. Your name, birthday, and suburb together can reveal a lot. Legitimate personality quizzes never need that info.",
  },
  {
    q: "A screenshot is going around of a well-known person supposedly saying something awful. What do you do before resharing?",
    options: [
      "Share it — everyone needs to know!",
      "Like it but don't share",
      "Check a trusted news source first — screenshots can easily be faked",
    ],
    correct: 2,
    explain: "Screenshots are incredibly easy to edit. Always check a reliable source before sharing anything that could damage someone's reputation — including verifying with official accounts or news sites.",
  },
  {
    q: "Someone in an online game asks'where are you from? which school?' and says they might go there too. You should:",
    options: [
      "Tell them — it would be cool if they went to your school!",
      "Only say your general city",
      "Not share your school name — you can't verify who they are",
    ],
    correct: 2,
    explain: "Even'low-risk' details like your school name can help someone narrow down where to find you in real life. It's not paranoid to keep this private — it's sensible.",
  },
  {
    q: "You notice an old photo of you is being shared in a group chat without your permission. Your best first step is:",
    options: [
      "Ignore it and hope it blows over",
      "Screenshot everything, report it on the platform, and tell a trusted adult",
      "Message the person who shared it and ask them to stop privately",
    ],
    correct: 1,
    explain: "Documenting evidence and reporting are the most effective steps. Platforms take image-sharing violations seriously. Telling a trusted adult also means you have support — you shouldn't have to handle this alone.",
  },
];

const privacyItems = [
  { item:'Your full name + suburb',        safe: false, why:'Combined, these can help strangers locate you in real life.' },
  { item:'A selfie at your local café',    safe: false, why:'Photos reveal location — geo tags or identifiable backgrounds can pinpoint where you are.' },
  { item:'Your favourite music artist',    safe: true,  why: "Totally fine! It's a fun fact with no identifying info." },
  { item:'Your school name',               safe: false, why:'Your school name narrows down where to find you physically.' },
  { item:'Your gaming username (only)',    safe: true,  why:'A username alone (without linking to your real name) is generally low-risk.' },
  { item:'"Just got to [venue]" post',     safe: false, why:'Real-time location posts tell anyone exactly where you are, right now.' },
  { item:'Your opinion on a movie',        safe: true,  why:'Sharing opinions and interests is normal and safe — no personal data exposed.' },
  { item:'Your phone number',              safe: false, why:'Only share your number with people you already know and trust in real life.' },
];

const pledgeItems = [
  { id:'a', text: "I'll use strong, unique passwords and turn on 2FA where I can" },
  { id:'b', text: "I'll think before I post — once it's online, it can stay online" },
  { id:'c', text: "I'll keep my accounts private and be selective about who I accept" },
  { id:'d', text: "I'll trust my gut — if something feels off, I'll walk away or ask for help" },
  { id:'e', text: "I'll be kind online — to others and to myself" },
];

const animatedStats = [
  { end: 72,  suffix:'%', label:'of online harassment victims are women',    path:'/public/statistics' },
  { end: 90,  suffix:'%', label:'of image-based abuse targets are female',   path:'/public/statistics' },
  { end: 68,  suffix:'%', label:'of online abuse happens on social media',   path:'/public/prevention' },
  { end: 26,  suffix:'%', label:'of young women report being cyberstalked',  path:'/public/statistics' },
];

const sections = [
  { icon: TrendingUp,    title:'Statistics & Research',        desc:'See the real numbers behind online harassment',               path:'/public/statistics' },
  { icon: Shield,        title:'Prevention & Awareness',       desc:'Practical tips to protect yourself before anything happens',  path:'/public/prevention' },
  { icon: Heart,         title:'Social & Emotional Wellbeing', desc:'How online life affects your mental health and what helps',   path:'/public/social-emotional'},
  { icon: LifeBuoy,      title:'Response & Support',           desc:'What to do right now if something is happening to you',      path:'/public/action' },
  { icon: FileText,      title:'Documentation Resources',      desc:'How to save evidence and build your case',                   path:'/public/documentation' },
  { icon: Scale,         title:'Legal Information',            desc:'Know your rights and what the law says about online abuse',  path:'/public/laws' },
  { icon: ExternalLink,  title:'External Resources',           desc:'Trusted organisations, research, and articles to support you', path:'/public/resources' },
  { icon: Info,          title:'About girlGuard',              desc:'Learn about the creator and mission behind this platform',   path:'/public/about' },
];

const quickHelp = [
  { label: "Someone's harassing me online",      sub:'Mean messages, rumors, or exclusion',      path:'/public/bullying' },
  { label:'Social media is making me feel bad', sub:'Comparison, FOMO, or self-esteem issues',  path:'/public/comparison' },
  { label:'I need help right now',              sub:'Immediate steps and crisis resources',      path:'/public/action' },
  { label:'I want to stay safe online',         sub:'Prevention tips and privacy settings',     path:'/public/prevention' },
  { label:'I need to document something',       sub:'Save evidence and build a proper record',  path:'/public/documentation'},
  { label:'I want to understand the law',       sub: "What's legal, what's not, and your rights", path:'/public/laws' },
];

const docFeatures = [
  { icon: FileText,       title:'Build a solid case',          desc:'Organise screenshots, messages, and dates into a clear incident record.' },
  { icon: Hash,           title:'Prove nothing was altered',   desc:'Cryptographic hashes confirm your evidence is original and untampered.' },
  { icon: Clock,          title:'Track a pattern over time',   desc:'Every log entry is timestamped so you can show escalation clearly.' },
  { icon: Activity,       title:'Record the real impact',      desc:'Capture the emotional, social, and academic effects that courts consider.' },
  { icon: Download,       title:'Generate a report instantly', desc:'Export a professional summary ready to hand to school, police, or a lawyer.' },
  { icon: HeartHandshake, title:'Find help and next steps',    desc:'Access crisis lines, legal guides, and counselling resources in one place.' },
];


// ─── HELPERS ──────────────────────────────────────────────────────────────────

function SectionRule() {
  return <div className="max-w-5xl mx-auto"><div className="border-t border-border" /></div>;
}

// ─── INTERACTIVE: DAILY TIP ROTATOR ──────────────────────────────────────────

function DailyTipCard() {
  const [idx] = useState(() => Math.floor(Math.random() * dailyTips.length));
  const [current, setCurrent] = useState(idx);
  const tip = dailyTips[current];
  const next = () => setCurrent(i => (i + 1) % dailyTips.length);
  return (
    <div className="rounded-xl border border-border bg-card p-5 md:p-6 flex flex-col md:flex-row items-start md:items-center gap-4">
      <div className="h-10 w-10 rounded-lg flex items-center justify-center shrink-0 bg-primary/10">
        <ShieldCheck className="h-5 w-5 text-primary" strokeWidth={1.5} />
      </div>
      <div className="flex-1 min-w-0 space-y-1">
        <div className="flex items-center gap-1.5">
          <Lightbulb className="h-3 w-3 text-primary shrink-0" strokeWidth={2} />
          <p className="text-xs font-semibold tracking-widest uppercase text-muted-foreground">Today's safety tip</p>
        </div>
        <p className="text-sm md:text-base text-foreground leading-relaxed text-pretty">{tip.tip}</p>
      </div>
      <button onClick={next}
        className="h-9 px-4 rounded-lg text-xs font-medium text-muted-foreground border border-border
                   hover:text-foreground hover:bg-muted transition-colors whitespace-nowrap shrink-0">
        Next tip →
      </button>
    </div>
  );
}

// ─── INTERACTIVE: SAFETY QUIZ ────────────────────────────────────────────────

function SafetyQuiz() {
  const [qIdx, setQIdx] = useState(0);
  const [chosen, setChosen] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [done, setDone] = useState(false);
  const q = quizQuestions[qIdx];
  const select = (i: number) => {
    if (chosen !== null) return;
    setChosen(i);
    if (i === q.correct) setScore(s => s + 1);
  };
  const next = () => {
    if (qIdx + 1 >= quizQuestions.length) { setDone(true); return; }
    setQIdx(i => i + 1); setChosen(null);
  };
  const restart = () => { setQIdx(0); setChosen(null); setScore(0); setDone(false); };
  if (done) return (
    <div className="p-6 text-center space-y-4">
      <div className="flex items-center justify-center">
        {score >= 4
          ? <Trophy className="h-10 w-10 text-primary" strokeWidth={1.5} />
          : score >= 2
          ? <Star className="h-10 w-10 text-primary" strokeWidth={1.5} />
          : <ShieldCheck className="h-10 w-10 text-primary" strokeWidth={1.5} />}
      </div>
      <p className="text-lg font-medium text-foreground">{score} / {quizQuestions.length} right</p>
      <p className="text-sm text-muted-foreground text-pretty">{score >= 4 ?'Excellent instincts! You clearly think critically online.' : score >= 2 ?'Good thinking. A few tricky ones — worth a review.' :'Online situations can be tricky. Knowledge is your best protection.'}</p>
      <button onClick={restart}
        className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium text-white"
        style={{ background:'linear-gradient(135deg, #FF6B9D 0%, #B794F6 100%)' }}>
        Try again
      </button>
    </div>
  );
  // quiz options — remove glass class from answer buttons
  return (
    <div className="p-5 md:p-6 space-y-5">
      <div className="flex items-center justify-between text-xs text-muted-foreground">
        <span>Question {qIdx + 1} of {quizQuestions.length}</span>
        <span className="font-medium text-foreground">{score} correct</span>
      </div>
      <div className="h-1 bg-muted rounded-full overflow-hidden">
        <div className="h-full rounded-full transition-all duration-500"
          style={{ width: `${(qIdx / quizQuestions.length) * 100}%`, background: G.grad }} />
      </div>
      <p className="text-sm md:text-base font-medium text-foreground leading-snug text-pretty">{q.q}</p>
      <div className="space-y-2">
        {q.options.map((opt, i) => {
          const isCorrect = i === q.correct;
          const isChosen  = i === chosen;
          return (
            <button key={i} onClick={() => select(i)} disabled={chosen !== null}
              className={[
                'w-full text-left text-sm px-4 py-3 rounded-lg border transition-all duration-150 text-pretty',
                chosen === null ? 'border-border bg-card text-foreground hover:border-primary/40 hover:bg-primary/5' : '',
                chosen !== null && isCorrect ? 'border-green-400/50 bg-green-50 dark:bg-green-950/30 text-green-700 dark:text-green-400 font-medium' : '',
                chosen !== null && isChosen && !isCorrect ? 'border-destructive/40 bg-destructive/5 text-destructive line-through opacity-75' : '',
                chosen !== null && !isCorrect && !isChosen ? 'opacity-40 border-border' : '',
              ].join(' ')}>
              {opt}
            </button>
          );
        })}
      </div>
      {chosen !== null && (
        <div className="space-y-3">
          <div className="rounded-lg border border-border bg-muted/40 p-4 flex items-start gap-2">
            <Lightbulb className="h-4 w-4 text-primary shrink-0 mt-0.5" strokeWidth={1.5} />
            <p className="text-xs text-muted-foreground leading-relaxed text-pretty">{q.explain}</p>
          </div>
          <button onClick={next}
            className="w-full py-2.5 rounded-lg text-sm font-medium text-primary-foreground bg-primary hover:opacity-90 transition-opacity">
            {qIdx + 1 < quizQuestions.length ? 'Next question →' : 'See my score →'}
          </button>
        </div>
      )}
    </div>
  );
}

// ─── INTERACTIVE: PRIVACY CHECK ───────────────────────────────────────────────

function PrivacyCheck() {
  const [revealed, setRevealed] = useState<Record<number, boolean>>({});
  const toggle = (i: number) => setRevealed(r => ({ ...r, [i]: !r[i] }));
  return (
    <div className="space-y-2">
      {privacyItems.map(({ item, safe, why }, i) => (
        <button key={i} onClick={() => toggle(i)}
          className={[
            'w-full text-left rounded-lg border p-4 transition-all duration-200',
            revealed[i]
              ? safe
                ? 'border-green-400/40 bg-green-50 dark:bg-green-950/20'
                : 'border-destructive/30 bg-destructive/5'
              : 'border-border bg-card hover:border-primary/30 hover:bg-primary/5',
          ].join(' ')}>
          <div className="flex items-start justify-between gap-3">
            <span className="text-sm text-foreground text-left">{item}</span>
            {revealed[i] ? (
              safe
                ? <span className="text-xs font-semibold text-green-600 dark:text-green-400 shrink-0">Safe</span>
                : <span className="text-xs font-semibold text-destructive shrink-0">Risky</span>
            ) : (
              <span className="text-xs text-muted-foreground shrink-0">Tap to reveal</span>
            )}
          </div>
          {revealed[i] && <p className="text-xs text-muted-foreground mt-2 text-pretty">{why}</p>}
        </button>
      ))}
    </div>
  );
}

// ─── INTERACTIVE: SAFETY PLEDGE ──────────────────────────────────────────────

function SafetyPledge() {
  const [checked, setChecked] = useState<Record<string, boolean>>({});
  const toggle = (id: string) => setChecked(c => ({ ...c, [id]: !c[id] }));
  const count = Object.values(checked).filter(Boolean).length;
  const done = count === pledgeItems.length;
  return (
    <div className="space-y-4">
      <div className="space-y-2">
        {pledgeItems.map(({ id, text }) => (
          <label key={id} onClick={() => toggle(id)}
            className={[
              'flex items-start gap-3 p-4 rounded-lg border cursor-pointer transition-all duration-150',
              checked[id]
                ? 'border-primary/40 bg-primary/5'
                : 'border-border bg-card hover:border-primary/20 hover:bg-muted/40',
            ].join(' ')}>
            <div className={[
              'mt-0.5 h-4 w-4 rounded border-2 flex items-center justify-center shrink-0 transition-all',
              checked[id] ? 'border-primary bg-primary' : 'border-border',
            ].join(' ')}>
              {checked[id] && <span className="text-[9px] text-white font-bold leading-none">✓</span>}
            </div>
            <span className="text-sm text-foreground leading-relaxed text-pretty">{text}</span>
          </label>
        ))}
      </div>
      {done && (
        <div className="rounded-lg border border-primary/20 bg-primary/5 p-5 text-center space-y-2">
          <p className="text-sm font-medium text-foreground">Pledge complete! You're on your way.</p>
          <p className="text-xs text-muted-foreground text-pretty">These five habits will genuinely make you safer online. Keep them close.</p>
        </div>
      )}
      {!done && (
        <p className="text-xs text-muted-foreground text-center">{count} / {pledgeItems.length} — {pledgeItems.length - count} more to go</p>
      )}
    </div>
  );
}

// ─── MAIN PAGE ────────────────────────────────────────────────────────────────

export default function PublicInfoPage() {
  const navigate = useNavigate();
  const [feedbackName, setFeedbackName] = useState('');
  const [feedbackEmail, setFeedbackEmail] = useState('');
  const [feedbackMessage, setFeedbackMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleFeedbackSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!feedbackMessage.trim()) { toast.error('Please enter your feedback'); return; }
    setIsSubmitting(true);
    setTimeout(() => {
      toast.success('Thank you for your feedback!');
      setFeedbackName(''); setFeedbackEmail(''); setFeedbackMessage('');
      setIsSubmitting(false);
    }, 1000);
  };

  return (
    <PublicLayout>
      <div className="max-w-5xl mx-auto px-2 md:px-4 space-y-0">

        {/* ── HERO ──────────────────────────────────────────────────────── */}
        <section className="relative -mx-2 md:-mx-4 overflow-hidden">
          {/* Gradient mesh background */}
          <div className="hero-mesh" aria-hidden="true" />

          <div className="relative z-10 max-w-5xl mx-auto px-6 md:px-8 py-14 md:py-20
                          flex flex-col md:grid md:grid-cols-5 gap-10 md:gap-8
                          items-center min-h-[64vh] md:min-h-[78vh]">

            {/* ── LEFT: text ── col-span-3 */}
            <div className="md:col-span-3 space-y-7 w-full">

              {/* Badge */}
              <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full
                              border border-border bg-card/70"
                style={{ animation: 'wordReveal 0.6s cubic-bezier(0.22,1,0.36,1) 0.1s both' }}>
                <Shield className="h-3 w-3 text-primary shrink-0" strokeWidth={2} />
                <p className="text-xs font-semibold tracking-widest uppercase text-muted-foreground">
                  Free · Private · Made by a girl
                </p>
              </div>

              {/* Headline — word-by-word reveal */}
              <h1 className="text-4xl md:text-5xl lg:text-[3.4rem] font-light leading-[1.12] tracking-tight">
                {/* Line 1: each word staggered */}
                {['You', 'deserve', 'to', 'feel', 'safe', 'online.'].map((word, i) => (
                  <span key={i}
                    className="word-reveal inline-block mr-[0.25em]"
                    style={{ animationDelay: `${0.25 + i * 0.09}s` }}>
                    {word}
                  </span>
                ))}
                <br className="hidden md:block" />
                {/* Line 2: gradient brand name */}
                <span className="word-reveal inline-block gradient-text font-medium"
                  style={{ animationDelay: '0.92s' }}>
                  Welcome to girlGuard.
                </span>
              </h1>

              {/* Description */}
              <p className="text-base md:text-lg text-muted-foreground leading-relaxed text-pretty max-w-lg"
                style={{ animation: 'wordReveal 0.7s cubic-bezier(0.22,1,0.36,1) 1.1s both' }}>
                Your guide to online safety, privacy, and knowing what to do if things ever go wrong.
                No crisis needed — learning this stuff <em>now</em> is the best thing you can do.
              </p>

              {/* CTAs */}
              <div className="flex flex-col sm:flex-row gap-3"
                style={{ animation: 'wordReveal 0.7s cubic-bezier(0.22,1,0.36,1) 1.25s both' }}>
                <button
                  onClick={() => document.getElementById('everything-you-need')?.scrollIntoView({ behavior: 'smooth' })}
                  className="inline-flex items-center justify-center gap-2 h-12 px-8 rounded-xl
                             font-semibold text-sm text-primary-foreground hover:opacity-90
                             active:scale-[0.98] transition-all duration-150"
                  style={{ background: G.grad }}>
                  Start learning
                  <ArrowRight className="h-4 w-4" />
                </button>
                <button onClick={() => navigate('/public/action')}
                  className="h-12 px-7 rounded-xl text-sm font-medium text-primary
                             border border-primary/50 hover:bg-primary/10
                             active:scale-[0.98] transition-all duration-150">
                  I need help right now
                </button>
              </div>

              {/* kidsGuard pill */}
              <div style={{ animation: 'wordReveal 0.6s cubic-bezier(0.22,1,0.36,1) 1.4s both' }}>
                <button onClick={() => navigate('/kids')}
                  className="inline-flex items-center gap-3 h-11 pl-3 pr-5 rounded-full
                             font-medium text-sm text-white hover:opacity-90
                             active:scale-[0.98] transition-all duration-200"
                  style={{ background: 'linear-gradient(135deg, #4A7FC1 0%, #5BC8C4 100%)' }}>
                  <div className="h-7 w-7 rounded-full bg-white/25 flex items-center justify-center shrink-0">
                    <Shield className="h-3.5 w-3.5 text-white" strokeWidth={2.5} />
                  </div>
                  <div className="text-left">
                    <p className="text-xs font-semibold leading-none">kidsGuard</p>
                    <p className="text-[10px] text-white/80 leading-none mt-0.5">for ages 8–12</p>
                  </div>
                  <ArrowRight className="h-3.5 w-3.5 text-white/80 ml-1" />
                </button>
              </div>
            </div>

            {/* ── RIGHT: animated shield orb ── col-span-2 */}
            <div className="md:col-span-2 flex items-center justify-center w-full"
              style={{ animation: 'wordReveal 1s cubic-bezier(0.22,1,0.36,1) 0.5s both' }}>
              <ShieldOrb />
            </div>
          </div>

          {/* Scroll cue */}
          <div className="relative z-10 flex justify-center pb-8 -mt-4"
            style={{ animation: 'wordReveal 0.6s ease 1.6s both' }}>
            <button
              onClick={() => document.getElementById('everything-you-need')?.scrollIntoView({ behavior: 'smooth' })}
              className="scroll-cue flex flex-col items-center gap-1 text-muted-foreground/50
                         hover:text-muted-foreground transition-colors"
              aria-label="Scroll down">
              <span className="text-[10px] tracking-widest uppercase">Explore</span>
              <ChevronDown className="h-4 w-4" />
            </button>
          </div>

          {/* Bottom divider — thin gradient line */}
          <div className="absolute bottom-0 inset-x-0 h-px"
            style={{ background: 'linear-gradient(90deg, transparent, rgba(255,107,157,0.3) 30%, rgba(183,148,246,0.3) 70%, transparent)' }}
            aria-hidden="true" />
        </section>

        {/* ── HERO STAT STRIP ───────────────────────────────────────────── */}
        <section className="py-5 border-b border-border">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-0">
            {animatedStats.map(({ end, suffix, label }, i) => (
              <div key={label}
                className={[
                  'hero-stat-pill flex flex-col items-center justify-center text-center px-4 py-3',
                  // Mobile 2-col: right border on odd indices (col 1), not on even (col 2)
                  // Desktop 4-col: right border on all except last
                  i % 2 === 0 ? 'border-r border-border' : '',
                  i === animatedStats.length - 1 ? 'md:border-r-0' : 'md:border-r md:border-border',
                  // Mobile: remove right border on items in last column (i%2===1)
                  i % 2 === 1 ? 'border-r-0' : '',
                ].filter(Boolean).join(' ')}
                style={{ animationDelay: `${i * 0.1 + 0.3}s` }}>
                <p className="text-2xl font-light tracking-tight gradient-text">
                  <AnimatedCounter end={end} />{suffix}
                </p>
                <p className="text-[11px] text-muted-foreground leading-snug mt-1 text-balance max-w-[120px]">{label}</p>
              </div>
            ))}
          </div>
        </section>

        {/* ── DAILY SAFETY TIP ──────────────────────────────────────────── */}
        <SectionRule />
        <section className="py-8 animate-fade-in" style={{ animationDelay:'0.5s', animationFillMode:'backwards' }}>
          <DailyTipCard />
        </section>

        {/* ── THREE THINGS EVERY GIRL SHOULD KNOW ──────────────────────── */}
        <SectionRule />
        <section className="py-8 md:py-10 space-y-6 opacity-0 intersect:opacity-100 transition duration-700">
          <div className="space-y-1">
            <div className="flex items-center gap-1.5">
              <Sparkles className="h-3 w-3 text-primary shrink-0" strokeWidth={2} />
              <p className="text-xs font-semibold tracking-widest uppercase text-muted-foreground">Start here</p>
            </div>
            <h2 className="text-xl md:text-2xl font-light tracking-tight text-balance">Three things every girl should know</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {[
              { icon: Shield,   title:'Protect your privacy',      desc:'Settings, passwords, and what to share (and not share) online.',    path:'/public/prevention',       tag:'Prevention' },
              { icon: BookOpen, title:'Recognise warning signs',   desc:'How to spot manipulation, scams, and when something feels off.',    path:'/public/statistics',       tag:'Awareness'  },
              { icon: Heart,    title:'Look after your wellbeing', desc:'How your online life affects your mental health — and what helps.', path:'/public/social-emotional', tag:'Wellbeing'  },
            ].map(({ icon: Icon, title, desc, path, tag }, i) => (
              <button key={path} onClick={() => navigate(path)}
                className="text-left flex flex-col gap-3 p-5 rounded-lg border border-border bg-card
                           hover:border-primary/40 transition-colors duration-150 group h-full
                           opacity-0 intersect:opacity-100"
                style={{ transitionDelay: `${i * 80}ms` }}>
                <div className="flex items-center justify-between w-full">
                  <div className="h-9 w-9 rounded-lg flex items-center justify-center shrink-0 bg-primary/10
                                  group-hover:bg-primary/15 transition-colors">
                    <Icon className="h-4 w-4 text-primary" strokeWidth={2} />
                  </div>
                  <span className="text-xs text-muted-foreground border border-border rounded-full px-2 py-0.5">{tag}</span>
                </div>
                <div className="space-y-1 min-w-0">
                  <p className="text-sm font-medium text-foreground group-hover:text-primary transition-colors">{title}</p>
                  <p className="text-xs text-muted-foreground leading-relaxed text-pretty">{desc}</p>
                </div>
                <p className="text-xs text-primary opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1 mt-auto">
                  Read more <ArrowRight className="h-3 w-3" />
                </p>
              </button>
            ))}
          </div>
        </section>

        {/* ── EVERYTHING YOU NEED ────────────────────────────────────────── */}
        <SectionRule />
        <section id="everything-you-need" className="py-8 md:py-10 space-y-6 opacity-0 intersect:opacity-100 transition duration-700">
          <div className="space-y-1">
            <div className="flex items-center gap-1.5">
              <LayoutGrid className="h-3 w-3 text-primary shrink-0" strokeWidth={2} />
              <p className="text-xs font-semibold tracking-widest uppercase text-muted-foreground">All topics</p>
            </div>
            <h2 className="text-xl md:text-2xl font-light tracking-tight text-balance">Everything you need</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {sections.map(({ icon: Icon, title, desc, path }, i) => (
              <button key={path} onClick={() => navigate(path)}
                className="text-left flex items-start gap-3 p-4 rounded-lg border border-border bg-card
                           hover:border-primary/40 transition-colors duration-150 group h-full
                           opacity-0 intersect:opacity-100"
                style={{ transitionDelay: `${i * 50}ms` }}>
                <div className="h-8 w-8 rounded-md flex items-center justify-center shrink-0 mt-0.5 bg-primary/10
                                group-hover:bg-primary/15 transition-colors">
                  <Icon className="h-3.5 w-3.5 text-primary" strokeWidth={1.75} />
                </div>
                <div className="space-y-0.5 min-w-0">
                  <p className="text-sm font-medium text-foreground group-hover:text-primary transition-colors">{title}</p>
                  <p className="text-xs text-muted-foreground leading-relaxed text-pretty">{desc}</p>
                </div>
              </button>
            ))}
          </div>
        </section>

        {/* ── FIND WHAT YOU NEED RIGHT NOW ─────────────────────────────── */}
        <SectionRule />
        <section className="py-8 md:py-10 space-y-6 opacity-0 intersect:opacity-100 transition duration-700">
          <div className="space-y-1">
            <div className="flex items-center gap-1.5">
              <Zap className="h-3 w-3 text-primary shrink-0" strokeWidth={2} />
              <p className="text-xs font-semibold tracking-widest uppercase text-muted-foreground">Quick help</p>
            </div>
            <h2 className="text-xl md:text-2xl font-light tracking-tight text-balance">Find what you need right now</h2>
            <p className="text-sm text-muted-foreground">Click what matches your situation</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {quickHelp.map(({ label, sub, path }) => (
              <button key={path + label} onClick={() => navigate(path)}
                className="text-left flex items-start justify-between gap-4 p-4 rounded-lg
                           border border-border bg-card hover:border-primary/40
                           transition-colors duration-150 group">
                <div className="space-y-0.5 min-w-0">
                  <p className="text-sm font-medium text-foreground group-hover:text-primary transition-colors">{label}</p>
                  <p className="text-xs text-muted-foreground">{sub}</p>
                </div>
                <ArrowRight className="h-4 w-4 text-muted-foreground shrink-0 mt-0.5
                                       group-hover:text-primary group-hover:translate-x-1 transition-all" />
              </button>
            ))}
          </div>
        </section>

        {/* ── HOW SAFE ARE YOU (quiz) ────────────────────────────────────── */}
        <SectionRule />
        <section className="py-8 md:py-10 space-y-5 opacity-0 intersect:opacity-100 transition duration-700">
          <div className="space-y-1">
            <div className="flex items-center gap-1.5">
              <Target className="h-3 w-3 text-primary shrink-0" strokeWidth={2} />
              <p className="text-xs font-semibold tracking-widest uppercase text-muted-foreground">Interactive</p>
            </div>
            <h2 className="text-xl md:text-2xl font-light tracking-tight text-balance">How safe are you online?</h2>
            <p className="text-sm text-muted-foreground text-pretty max-w-xl">
              Five quick scenarios — real situations teen girls face online. Find out what you'd do and why it matters.
            </p>
          </div>
          <div className="rounded-lg border border-border bg-card overflow-hidden">
            <SafetyQuiz />
          </div>
        </section>

        {/* ── WHAT'S SAFE TO SHARE ──────────────────────────────────────── */}
        <SectionRule />
        <section className="py-8 md:py-10 space-y-5 opacity-0 intersect:opacity-100 transition duration-700">
          <div className="space-y-1">
            <div className="flex items-center gap-1.5">
              <CheckCircle className="h-3 w-3 text-primary shrink-0" strokeWidth={2} />
              <p className="text-xs font-semibold tracking-widest uppercase text-muted-foreground">Activity</p>
            </div>
            <h2 className="text-xl md:text-2xl font-light tracking-tight text-balance">What's safe to share online?</h2>
            <p className="text-sm text-muted-foreground text-pretty max-w-xl">Go through each item and decide. Some answers might surprise you.</p>
          </div>
          <div className="rounded-lg border border-border bg-card p-5">
            <PrivacyCheck />
          </div>
        </section>

        {/* ── SAFETY PLEDGE ─────────────────────────────────────────────── */}
        <SectionRule />
        <section className="py-8 md:py-10 space-y-5 opacity-0 intersect:opacity-100 transition duration-700">
          <div className="space-y-1">
            <div className="flex items-center gap-1.5">
              <Heart className="h-3 w-3 text-primary shrink-0" strokeWidth={2} />
              <p className="text-xs font-semibold tracking-widest uppercase text-muted-foreground">Commit</p>
            </div>
            <h2 className="text-xl md:text-2xl font-light tracking-tight text-balance">The girlGuard safety pledge</h2>
            <p className="text-sm text-muted-foreground text-pretty max-w-xl">Five habits that make a real difference. Tick all five to complete it.</p>
          </div>
          <SafetyPledge />
        </section>

        {/* ── DOCUMENTATION TOOLS CTA ───────────────────────────────────── */}
        <SectionRule />
        <section className="py-8 md:py-10 space-y-5">
          <div className="space-y-1 opacity-0 intersect:opacity-100 transition duration-700">
            <div className="flex items-center gap-1.5">
              <ClipboardList className="h-3 w-3 text-primary shrink-0" strokeWidth={2} />
              <p className="text-xs font-semibold tracking-widest uppercase text-muted-foreground">Documentation tools</p>
            </div>
            <h2 className="text-xl md:text-2xl font-light tracking-tight text-balance">Need to document something?</h2>
            <p className="text-sm text-muted-foreground text-pretty max-w-xl">
              Creating an account gives you secure tools to log incidents, preserve evidence, and generate reports.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {docFeatures.map(({ icon: Icon, title, desc }, i) => (
              <div key={title}
                className="flex gap-3 p-4 rounded-lg border border-border bg-card
                           hover:border-primary/30 transition-colors duration-150 group
                           opacity-0 intersect:opacity-100"
                style={{ transitionDelay: `${i * 60}ms` }}>
                <div className="shrink-0 mt-0.5 h-8 w-8 rounded-md border border-border bg-muted/40
                                flex items-center justify-center group-hover:border-primary/30
                                transition-colors">
                  <Icon className="h-3.5 w-3.5 text-primary" strokeWidth={1.5} />
                </div>
                <div className="space-y-0.5 min-w-0">
                  <p className="text-sm font-medium text-foreground group-hover:text-primary transition-colors">{title}</p>
                  <p className="text-xs text-muted-foreground leading-relaxed text-pretty">{desc}</p>
                </div>
              </div>
            ))}
          </div>
          <div className="flex flex-col sm:flex-row gap-3 pt-1 opacity-0 intersect:opacity-100 transition duration-700">
            <button onClick={() => navigate('/login')}
              className="inline-flex items-center gap-2 h-11 px-7 rounded-lg font-semibold text-sm text-primary-foreground bg-primary hover:opacity-90 transition-opacity">
              Create account — it's free
              <ArrowRight className="h-4 w-4" />
            </button>
            <button onClick={() => navigate('/public/documentation')}
              className="h-11 px-6 rounded-lg text-sm font-medium text-foreground border border-border hover:bg-muted transition-colors">
              Read the documentation guide first
            </button>
          </div>
        </section>

        {/* ── FEEDBACK ──────────────────────────────────────────────────── */}
        <SectionRule />
        <section className="py-8 md:py-10 space-y-5 opacity-0 intersect:opacity-100 transition duration-700">
          <div className="space-y-1">
            <div className="flex items-center gap-1.5">
              <MessagesSquare className="h-3 w-3 text-primary shrink-0" strokeWidth={2} />
              <p className="text-xs font-semibold tracking-widest uppercase text-muted-foreground">Your voice</p>
            </div>
            <h2 className="text-xl md:text-2xl font-light tracking-tight text-balance">Share your feedback</h2>
            <p className="text-sm text-muted-foreground text-pretty max-w-xl">Suggestions, broken links, or your experience — we're listening.</p>
          </div>
          <form onSubmit={handleFeedbackSubmit} className="space-y-4 max-w-2xl">
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label htmlFor="feedback-name" className="text-xs font-normal text-muted-foreground">Name <span className="text-muted-foreground/50">(optional)</span></Label>
                <Input id="feedback-name" type="text" placeholder="Your name"
                  value={feedbackName} onChange={(e) => setFeedbackName(e.target.value)}
                  className="h-9 text-sm" />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="feedback-email" className="text-xs font-normal text-muted-foreground">Email <span className="text-muted-foreground/50">(optional)</span></Label>
                <Input id="feedback-email" type="email" placeholder="your@email.com"
                  value={feedbackEmail} onChange={(e) => setFeedbackEmail(e.target.value)}
                  className="h-9 text-sm" />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="feedback-message" className="text-xs font-normal text-muted-foreground">Your feedback <span className="text-destructive">*</span></Label>
              <Textarea id="feedback-message"
                placeholder="Share your thoughts, suggestions, or experiences..."
                value={feedbackMessage} onChange={(e) => setFeedbackMessage(e.target.value)}
                className="min-h-28 resize-none text-sm" required />
            </div>
            <div className="flex items-center gap-4">
              <button type="submit" disabled={isSubmitting}
                className="inline-flex items-center gap-1.5 h-9 px-6 rounded-lg text-sm font-semibold
                           text-primary-foreground bg-primary hover:opacity-90 transition-opacity disabled:opacity-50">
                <Send className="h-3.5 w-3.5" />
                {isSubmitting ? 'Sending...' : 'Send feedback'}
              </button>
              <p className="text-xs text-muted-foreground">Anonymous unless you provide contact info</p>
            </div>
          </form>
        </section>

        {/* ── BOTTOM CTA ────────────────────────────────────────────────── */}
        <SectionRule />
        <section className="py-10 md:py-14 space-y-6 opacity-0 intersect:opacity-100 transition duration-700">
          <div className="space-y-2 max-w-2xl">
            <h2 className="text-2xl md:text-3xl font-light tracking-tight leading-[1.2] text-balance">
              You deserve to feel safe online.{" "}
              <span className="gradient-text font-medium">Let's start right now.</span>
            </h2>
            <p className="text-sm text-muted-foreground text-pretty">
              No drama. No sign-up required. Just information, activities, and support — built for teen girls.
            </p>
          </div>
          <div className="grid md:grid-cols-2 gap-2 max-w-2xl">
            {[
'No sign-up needed to read guides',
'All resources are completely free',
'Your data stays on your device only',
'No ads, no tracking — ever',
            ].map(item => (
              <div key={item} className="flex items-center gap-2">
                <CheckCircle2 className="h-3.5 w-3.5 text-primary shrink-0" strokeWidth={2} />
                <span className="text-sm text-muted-foreground">{item}</span>
              </div>
            ))}
          </div>
          <div className="flex flex-wrap gap-3 pt-1">
            <button onClick={() => navigate('/login')}
              className="inline-flex items-center gap-2 h-11 px-7 rounded-lg font-semibold text-sm text-primary-foreground bg-primary hover:opacity-90 transition-opacity">
              Create your safe space
              <ArrowRight className="h-4 w-4" />
            </button>
            <button onClick={() => navigate('/public/prevention')}
              className="h-11 px-6 rounded-lg text-sm font-medium text-foreground border border-border hover:bg-muted transition-colors">
              Explore guides first
            </button>
          </div>
        </section>

      </div>
    </PublicLayout>
  );
}
