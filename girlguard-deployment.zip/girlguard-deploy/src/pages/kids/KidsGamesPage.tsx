import { useState, useCallback, useEffect } from 'react';
import { RefreshCw, CheckCircle, XCircle, Lock, Eye, EyeOff } from 'lucide-react';
import { K } from '@/components/layouts/KidsLayout';
import {
  FirewallSnakeGame,
  VirusBusterGame,
  SafeSurferGame,
  CyberMemoryGame,
  PasswordSprintGame,
  EncryptionDecoderGame,
  CyberTowerDefenceGame,
  CyberCrosswordGame,
} from '@/pages/kids/KidsArcadeGames';

// ─── SHARED HELPERS ───────────────────────────────────────────────────────────

function ScoreBadge({ score, total }: { score: number; total: number }) {
  const pct = total > 0 ? Math.round((score / total) * 100) : 0;
  const color = pct >= 80 ? K.green : pct >= 50 ? K.yellow : K.pink;
  return (
    <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-black border"
      style={{ borderColor: color, color, backgroundColor: color + '18' }}>
      {score}/{total}
    </span>
  );
}

function ReplayBtn({ onReplay, color = K.teal }: { onReplay: () => void; color?: string }) {
  return (
    <button onClick={onReplay}
      className="inline-flex items-center gap-2 px-5 py-2.5 rounded-2xl font-black text-white hover:scale-105 transition-all"
      style={{ backgroundColor: color }}>
      <RefreshCw className="h-4 w-4" /> Play Again
    </button>
  );
}

function FinalScreen({ score, total, msg, color, onReplay }: {
  score: number; total: number; msg: string; color: string; onReplay: () => void;
}) {
  const pct = Math.round((score / total) * 100);
  return (
    <div className="text-center space-y-5 py-8 px-4">
      <div className="text-6xl">{pct >= 80 ? '🏆' : pct >= 50 ? '💪' : '🌱'}</div>
      <p className="text-3xl font-black" style={{ color: K.text }}>{score}/{total}</p>
      <p className="font-bold text-base" style={{ color: K.muted }}>{msg}</p>
      <ReplayBtn onReplay={onReplay} color={color} />
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// CYBERSECURITY GAMES
// ═══════════════════════════════════════════════════════════════════════════════

// ─── Game 1: Password Strength ────────────────────────────────────────────────

function getStrength(pw: string): { label: string; score: number; tips: string[] } {
  const tips: string[] = [];
  let score = 0;
  if (pw.length >= 8) score++; else tips.push('Use at least 8 characters');
  if (pw.length >= 12) score++;
  if (/[A-Z]/.test(pw)) score++; else tips.push('Add an uppercase letter (A–Z)');
  if (/[0-9]/.test(pw)) score++; else tips.push('Add a number (0–9)');
  if (/[^A-Za-z0-9]/.test(pw)) score++; else tips.push('Add a special character (!@#$...)');
  if (tips.length === 0) tips.push('Great job — this is a strong password! 🔐');
  const label = score <= 1 ? 'Weak 😬' : score <= 3 ? 'Medium 🤔' : 'Strong 💪';
  return { label, score, tips };
}

const passwordChallenges = [
  { challenge: 'Build a password for your secret diary app', theme: '📔' },
  { challenge: 'Create a super-secure school account password', theme: '🏫' },
  { challenge: 'Make a strong gaming account password', theme: '🎮' },
];

function PasswordStrengthGame() {
  const [pw, setPw]           = useState('');
  const [show, setShow]       = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [round, setRound]     = useState(0);
  const [totalScore, setTotalScore] = useState(0);
  const [done, setDone]       = useState(false);

  const str = getStrength(pw);
  const barColor = str.score <= 1 ? K.pink : str.score <= 3 ? K.yellow : K.green;

  const submit = () => {
    if (!pw) return;
    setSubmitted(true);
    setTotalScore(s => s + str.score);
  };

  const next = () => {
    if (round + 1 >= passwordChallenges.length) { setDone(true); return; }
    setRound(r => r + 1);
    setPw(''); setShow(false); setSubmitted(false);
  };

  const replay = () => { setRound(0); setPw(''); setShow(false); setSubmitted(false); setTotalScore(0); setDone(false); };

  if (done) return (
    <FinalScreen score={Math.round(totalScore / (passwordChallenges.length * 5) * 3)}
      total={3} color={K.teal}
      msg={totalScore >= 12 ? 'Password master! 🔐 You know how to stay safe.' : 'Keep practising — stronger passwords = safer accounts!'}
      onReplay={replay} />
  );

  const ch = passwordChallenges[round];
  return (
    <div className="p-6 space-y-5">
      <div className="flex items-center justify-between text-xs font-bold" style={{ color: K.muted }}>
        <span>Challenge {round + 1}/{passwordChallenges.length}</span>
        <ScoreBadge score={round} total={passwordChallenges.length} />
      </div>

      <div className="rounded-2xl p-4 border" style={{ borderColor: K.teal + '55', backgroundColor: K.teal + '0D' }}>
        <p className="text-2xl mb-1">{ch.theme}</p>
        <p className="font-black text-base" style={{ color: K.text }}>{ch.challenge}</p>
      </div>

      <div className="space-y-2">
        <label className="text-sm font-black" style={{ color: K.text }}>Type your password:</label>
        <div className="flex gap-2">
          <input
            type={show ? 'text' : 'password'}
            value={pw}
            onChange={e => { if (!submitted) setPw(e.target.value); }}
            placeholder="Type here..."
            className="flex-1 rounded-xl border px-4 py-2.5 text-base font-semibold outline-none"
            style={{ borderColor: K.border, color: K.text }}
          />
          <button onClick={() => setShow(s => !s)}
            className="px-3 rounded-xl border transition-all" style={{ borderColor: K.border }}>
            {show ? <EyeOff className="h-4 w-4" style={{ color: K.muted }} /> : <Eye className="h-4 w-4" style={{ color: K.muted }} />}
          </button>
        </div>
      </div>

      {pw.length > 0 && (
        <div className="space-y-2">
          <div className="flex justify-between text-xs font-bold" style={{ color: K.muted }}>
            <span>Strength</span>
            <span style={{ color: barColor }}>{str.label}</span>
          </div>
          <div className="h-2.5 rounded-full overflow-hidden" style={{ backgroundColor: '#F3F4F6' }}>
            <div className="h-full rounded-full transition-all duration-500"
              style={{ width: `${(str.score / 5) * 100}%`, backgroundColor: barColor }} />
          </div>
        </div>
      )}

      {!submitted ? (
        <button disabled={!pw} onClick={submit}
          className="w-full py-3 rounded-2xl font-black text-white hover:scale-[1.02] transition-all disabled:opacity-40"
          style={{ backgroundColor: K.teal }}>
          Check My Password! 🔍
        </button>
      ) : (
        <div className="space-y-3">
          <div className="rounded-2xl p-4 border space-y-2"
            style={{ borderColor: barColor, backgroundColor: barColor + '18' }}>
            <p className="font-black text-sm" style={{ color: K.text }}>
              {str.score >= 4 ? '🎉 Excellent password!' : str.score >= 2 ? '🤔 Getting there...' : '😬 This password is weak.'}
            </p>
            {str.tips.map((t, i) => (
              <p key={i} className="text-xs font-semibold flex items-center gap-1" style={{ color: K.muted }}>
                <span>{str.score >= 4 ? '✅' : '💡'}</span>{t}
              </p>
            ))}
          </div>
          <button onClick={next}
            className="w-full py-3 rounded-2xl font-black text-white hover:scale-[1.02] transition-all"
            style={{ backgroundColor: K.teal }}>
            {round + 1 < passwordChallenges.length ? 'Next Challenge →' : 'See Results 🏆'}
          </button>
        </div>
      )}
    </div>
  );
}

// ─── Game 2: Spot the Phishing Email ─────────────────────────────────────────

const phishingEmails = [
  {
    from: 'security@yourbank-alerts.xyz', subject: 'URGENT: Your account will be closed!',
    body: 'Dear Customer, Your account has been compromised. Click here immediately to verify your details and avoid losing access. This link expires in 24 hours.',
    isPhishing: true,
    redFlags: ['Suspicious sender domain (.xyz)', 'Creates urgent panic ("URGENT")', 'Asks you to click a vague link', 'Threatens account closure'],
  },
  {
    from: 'newsletter@nationalgeographic.com', subject: 'Wild Animals: Our Top 10 Photos This Month',
    body: 'Hi there! This month we captured incredible moments in the wild. Check out our top 10 wildlife photographs — no sign-in needed. Enjoy!',
    isPhishing: false,
    redFlags: ['Trusted sender domain', 'No urgent threats', 'No requests for personal info', 'Friendly, informational tone'],
  },
  {
    from: 'prizes@freegiftcard-winner.net', subject: 'You have WON a $1000 gift card!!',
    body: 'Congratulations!! You were randomly selected to receive a FREE $1000 gift card! Simply verify your address and credit card number to claim your prize before midnight!',
    isPhishing: true,
    redFlags: ['Too good to be true prize offer', 'Suspicious domain (.net not official)', 'Asks for credit card info', 'Fake urgency ("before midnight")'],
  },
  {
    from: 'no-reply@schoolportal.edu', subject: 'Your Spring Term Report Card is Ready',
    body: 'Hello, your Spring Term report card is now available in the student portal. Log in using your existing school credentials at portal.schoolname.edu to view it.',
    isPhishing: false,
    redFlags: ['Official .edu domain', 'Directs to known school portal', 'No unusual requests', 'Uses your existing credentials'],
  },
  {
    from: 'support@paypa1-secure.com', subject: 'Action Required: Verify Your PayPal Account',
    body: 'We noticed unusual activity on your account. Your account has been temporarily limited. Please update your billing info now by clicking below or your account will be permanently suspended.',
    isPhishing: true,
    redFlags: ['Domain uses "1" instead of "l" (paypa1 not paypal)', 'Threatens permanent suspension', 'Asks for billing info via email', 'Not addressed by name'],
  },
  {
    from: 'do-not-reply@spotify.com', subject: 'Your Spotify receipt for this month',
    body: 'Thanks for being a Spotify Premium member. Here is your receipt for this month. Your subscription renews automatically. No action needed.',
    isPhishing: false,
    redFlags: ['Legitimate spotify.com domain', 'Standard billing email', 'No suspicious links or requests', 'Says "no action needed"'],
  },
];

function PhishingGame() {
  const [idx, setIdx]     = useState(0);
  const [choice, setChoice] = useState<boolean | null>(null);
  const [score, setScore] = useState(0);
  const [done, setDone]   = useState(false);

  const em = phishingEmails[idx];

  const guess = (val: boolean) => {
    if (choice !== null) return;
    setChoice(val);
    if (val === em.isPhishing) setScore(s => s + 1);
  };

  const next = () => {
    if (idx + 1 >= phishingEmails.length) { setDone(true); return; }
    setIdx(i => i + 1); setChoice(null);
  };

  const replay = () => { setIdx(0); setChoice(null); setScore(0); setDone(false); };

  if (done) return (
    <FinalScreen score={score} total={phishingEmails.length} color={K.pink}
      msg={score >= 5 ? 'Amazing — you\'re a phishing-detecting superstar! 🕵️' : 'Good effort! The more you practice, the safer you\'ll be.'}
      onReplay={replay} />
  );

  const isCorrect = choice === em.isPhishing;

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between text-xs font-bold" style={{ color: K.muted }}>
        <span>Email {idx + 1}/{phishingEmails.length}</span>
        <ScoreBadge score={score} total={idx} />
      </div>

      <div className="rounded-2xl border overflow-hidden" style={{ borderColor: K.border }}>
        <div className="px-4 py-3 border-b space-y-1" style={{ borderColor: K.border, backgroundColor: K.panel }}>
          <p className="text-xs font-semibold" style={{ color: K.muted }}>
            <span className="font-black" style={{ color: K.text }}>From: </span>{em.from}
          </p>
          <p className="text-xs font-semibold" style={{ color: K.muted }}>
            <span className="font-black" style={{ color: K.text }}>Subject: </span>{em.subject}
          </p>
        </div>
        <div className="px-4 py-4">
          <p className="text-sm font-semibold leading-relaxed" style={{ color: K.text }}>{em.body}</p>
        </div>
      </div>

      <p className="text-sm font-black text-center" style={{ color: K.text }}>Is this a phishing email?</p>

      {choice === null ? (
        <div className="grid grid-cols-2 gap-3">
          <button onClick={() => guess(true)}
            className="py-4 rounded-2xl font-black text-white text-sm hover:scale-105 transition-all"
            style={{ backgroundColor: K.pink }}>
            🎣 YES — Phishing!
          </button>
          <button onClick={() => guess(false)}
            className="py-4 rounded-2xl font-black text-white text-sm hover:scale-105 transition-all"
            style={{ backgroundColor: K.green }}>
            ✅ Safe Email
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          <div className="rounded-2xl p-4 border space-y-2"
            style={{ borderColor: isCorrect ? K.green : K.pink, backgroundColor: (isCorrect ? K.green : K.pink) + '18' }}>
            <p className="font-black text-sm flex items-center gap-2" style={{ color: K.text }}>
              {isCorrect ? <CheckCircle className="h-4 w-4 shrink-0" style={{ color: K.green }} /> : <XCircle className="h-4 w-4 shrink-0" style={{ color: K.pink }} />}
              {isCorrect ? 'Correct! 🎉' : `Not quite — this email is ${em.isPhishing ? 'PHISHING!' : 'actually safe.'}`}
            </p>
            <p className="text-xs font-black" style={{ color: K.muted }}>
              {em.isPhishing ? '🚩 Red flags to notice:' : '✅ Signs it\'s safe:'}
            </p>
            {em.redFlags.map((f, i) => (
              <p key={i} className="text-xs font-semibold flex items-center gap-1" style={{ color: K.muted }}>
                <span>{em.isPhishing ? '⚠️' : '✔️'}</span>{f}
              </p>
            ))}
          </div>
          <button onClick={next}
            className="w-full py-3 rounded-2xl font-black text-white hover:scale-[1.02] transition-all"
            style={{ backgroundColor: K.pink }}>
            {idx + 1 < phishingEmails.length ? 'Next Email →' : 'See My Score! 🏆'}
          </button>
        </div>
      )}
    </div>
  );
}

// ─── Game 3: Virus vs Safe File Sorter ───────────────────────────────────────

interface FileItem { name: string; icon: string; isSafe: boolean; hint: string }

const fileItems: FileItem[] = [
  { name: 'free_robux_hack.exe',     icon: '📦', isSafe: false, hint: 'Executable files (.exe) promising free game currency are almost always malware!' },
  { name: 'my_homework.docx',        icon: '📄', isSafe: true,  hint: 'A regular Word document from a known source is generally safe to open.' },
  { name: 'click_me_free_gift.zip',  icon: '🗜️', isSafe: false, hint: 'Mystery ZIP files with "free gift" in the name are a classic virus trick.' },
  { name: 'family_photo.jpg',        icon: '🖼️', isSafe: true,  hint: 'Standard image files (JPEG/PNG) are safe to open.' },
  { name: 'invoice_urgent.pdf.exe',  icon: '📦', isSafe: false, hint: 'Double extension (.pdf.exe) — this looks like a PDF but is actually a dangerous executable!' },
  { name: 'birthday_invite.pdf',     icon: '📋', isSafe: true,  hint: 'A regular PDF file is generally safe to open.' },
  { name: 'youve_won_prize.bat',     icon: '⚙️', isSafe: false, hint: '.bat files run scripts on your computer and can be used for malicious purposes.' },
  { name: 'class_notes.txt',         icon: '📝', isSafe: true,  hint: 'Plain text files cannot execute code and are safe to open.' },
];

function VirusSorterGame() {
  const [idx, setIdx]     = useState(0);
  const [choice, setChoice] = useState<boolean | null>(null);
  const [score, setScore] = useState(0);
  const [done, setDone]   = useState(false);

  const file = fileItems[idx];

  const sort = (safe: boolean) => {
    if (choice !== null) return;
    setChoice(safe);
    if (safe === file.isSafe) setScore(s => s + 1);
  };

  const next = () => {
    if (idx + 1 >= fileItems.length) { setDone(true); return; }
    setIdx(i => i + 1); setChoice(null);
  };

  const replay = () => { setIdx(0); setChoice(null); setScore(0); setDone(false); };

  if (done) return (
    <FinalScreen score={score} total={fileItems.length} color={K.blue}
      msg={score >= 7 ? 'Incredible — you\'re a virus-spotting expert! 🛡️' : 'Good try! Remember: when in doubt, don\'t click!'}
      onReplay={replay} />
  );

  const isCorrect = choice === file.isSafe;

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between text-xs font-bold" style={{ color: K.muted }}>
        <span>File {idx + 1}/{fileItems.length}</span>
        <ScoreBadge score={score} total={idx} />
      </div>

      <div className="rounded-2xl border p-5 text-center space-y-2" style={{ borderColor: K.border, backgroundColor: K.panel }}>
        <p className="text-5xl">{file.icon}</p>
        <p className="font-black text-base" style={{ color: K.text }}>{file.name}</p>
        <p className="text-xs font-semibold" style={{ color: K.muted }}>
          Is this file safe to open?
        </p>
      </div>

      {choice === null ? (
        <div className="grid grid-cols-2 gap-3">
          <button onClick={() => sort(false)}
            className="py-4 rounded-2xl font-black text-white text-sm hover:scale-105 transition-all"
            style={{ backgroundColor: K.pink }}>
            🦠 VIRUS!
          </button>
          <button onClick={() => sort(true)}
            className="py-4 rounded-2xl font-black text-white text-sm hover:scale-105 transition-all"
            style={{ backgroundColor: K.green }}>
            ✅ Safe File
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          <div className="rounded-2xl p-4 border space-y-2"
            style={{ borderColor: isCorrect ? K.green : K.pink, backgroundColor: (isCorrect ? K.green : K.pink) + '18' }}>
            <p className="font-black text-sm flex items-center gap-2" style={{ color: K.text }}>
              {isCorrect ? <CheckCircle className="h-4 w-4 shrink-0" style={{ color: K.green }} /> : <XCircle className="h-4 w-4 shrink-0" style={{ color: K.pink }} />}
              {isCorrect ? 'Correct! 🎉' : `Actually it's ${file.isSafe ? 'SAFE ✅' : 'a VIRUS 🦠'}`}
            </p>
            <p className="text-xs font-semibold" style={{ color: K.muted }}>💡 {file.hint}</p>
          </div>
          <button onClick={next}
            className="w-full py-3 rounded-2xl font-black text-white hover:scale-[1.02] transition-all"
            style={{ backgroundColor: K.blue }}>
            {idx + 1 < fileItems.length ? 'Next File →' : 'See My Score! 🏆'}
          </button>
        </div>
      )}
    </div>
  );
}

// ─── Game 4: 2FA Explainer ────────────────────────────────────────────────────

const twoFASteps = [
  { step: 1, title: 'Enter Your Password', desc: 'The first lock — your password. Only you should know this!', icon: '🔑', action: 'Enter Password', correct: 'My password is entered ✓', wrong: 'Skip the password', wrongLabel: 'Skip it' },
  { step: 2, title: 'Get a Code on Your Phone', desc: 'The second lock — a one-time code sent to your phone. Changes every 30 seconds!', icon: '📱', action: 'Get my phone code', correct: 'Code received: 482 916 ✓', wrong: 'Make up a code', wrongLabel: 'Guess a code' },
  { step: 3, title: 'Enter the Code', desc: 'Type the code from your phone into the website. The code expires quickly!', icon: '⌨️', action: 'Type the code', correct: 'Code accepted! ✅', wrong: 'Use an old code', wrongLabel: 'Use an old code' },
  { step: 4, title: 'Access Granted!', desc: 'Even if someone stole your password, they can\'t get in without your phone! That\'s 2FA power!', icon: '🔓', action: 'I\'m in!', correct: 'Account secured with 2FA 🔐', wrong: 'Give up', wrongLabel: 'Never mind' },
];

function TwoFAGame() {
  const [step, setStep]   = useState(0);
  const [mistakes, setMistakes] = useState(0);
  const [choice, setChoice] = useState<'correct' | 'wrong' | null>(null);
  const [done, setDone]   = useState(false);

  const s = twoFASteps[step];

  const pick = (which: 'correct' | 'wrong') => {
    if (choice) return;
    setChoice(which);
    if (which === 'wrong') setMistakes(m => m + 1);
  };

  const next = () => {
    if (step + 1 >= twoFASteps.length) { setDone(true); return; }
    setStep(i => i + 1); setChoice(null);
  };

  const replay = () => { setStep(0); setMistakes(0); setChoice(null); setDone(false); };

  if (done) {
    const score = Math.max(0, 4 - mistakes);
    return (
      <FinalScreen score={score} total={4} color={K.teal}
        msg={mistakes === 0 ? 'Perfect! You set up 2FA without a single mistake! 🔐' : 'Almost there — try again with zero mistakes!'}
        onReplay={replay} />
    );
  }

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between text-xs font-bold" style={{ color: K.muted }}>
        <span>Step {step + 1}/{twoFASteps.length}</span>
        <span>Mistakes: {mistakes}</span>
      </div>

      {/* Progress dots */}
      <div className="flex gap-2 justify-center">
        {twoFASteps.map((_, i) => (
          <div key={i} className="h-2.5 w-2.5 rounded-full transition-all"
            style={{ backgroundColor: i < step ? K.green : i === step ? K.teal : K.border }} />
        ))}
      </div>

      <div className="rounded-2xl border p-5 text-center space-y-2"
        style={{ borderColor: K.teal + '55', backgroundColor: K.teal + '0D' }}>
        <p className="text-4xl">{s.icon}</p>
        <p className="font-black text-base" style={{ color: K.text }}>Step {s.step}: {s.title}</p>
        <p className="text-sm font-semibold" style={{ color: K.muted }}>{s.desc}</p>
      </div>

      {choice === null ? (
        <div className="grid grid-cols-2 gap-3">
          <button onClick={() => pick('correct')}
            className="py-4 rounded-2xl font-black text-white text-sm hover:scale-105 transition-all"
            style={{ backgroundColor: K.teal }}>
            ✅ {s.action}
          </button>
          <button onClick={() => pick('wrong')}
            className="py-4 rounded-2xl font-black text-sm border hover:scale-105 transition-all"
            style={{ borderColor: K.border, color: K.muted, backgroundColor: K.surface }}>
            ❌ {s.wrongLabel}
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          <div className="rounded-2xl p-4 border"
            style={{ borderColor: choice === 'correct' ? K.green : K.pink, backgroundColor: (choice === 'correct' ? K.green : K.pink) + '18' }}>
            <p className="font-black text-sm" style={{ color: K.text }}>
              {choice === 'correct' ? `✅ ${s.correct}` : `❌ That's not the right step! ${mistakes > 1 ? 'Keep going!' : 'Try to make no mistakes!'}`}
            </p>
          </div>
          <button onClick={next}
            className="w-full py-3 rounded-2xl font-black text-white hover:scale-[1.02] transition-all"
            style={{ backgroundColor: K.teal }}>
            {step + 1 < twoFASteps.length ? 'Next Step →' : 'Finish 2FA Setup! 🔐'}
          </button>
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// CYBER SAFETY GAMES
// ═══════════════════════════════════════════════════════════════════════════════

// ─── Game 5: Stranger Danger Online Quiz ─────────────────────────────────────

const strangerQs = [
  {
    q: `Someone in an online game says "I'm 12 too — let's share phone numbers so we can play outside school!" What do you do?`,
    opts: ['Share your number — they seem cool!', 'Ignore them completely', 'Tell a parent and do NOT share personal info', `Ask them to prove they're really 12`],
    correct: 2, why: `Online, you can NEVER truly know someone's age or identity. Always check with a parent before sharing anything personal.`,
  },
  {
    q: 'A stranger online gives you a gift card code "just because they like you". How do you feel?',
    opts: ['Happy — free gift!', 'Suspicious — gifts from strangers online are a warning sign 🚩', 'Thankful and share my address to say thanks', 'Ask for more gifts'],
    correct: 1, why: `Gifts from online strangers are a major warning sign — it's a common way to build trust before asking for something in return.`,
  },
  {
    q: `An online friend says "Don't tell your parents about me — they won't understand our friendship." What does this mean?`,
    opts: [`They're shy — it's fine`, 'They might be an adult pretending to be a kid 🚩', 'Parents are annoying anyway', 'They just want privacy'],
    correct: 1, why: `Safe friendships don't need to be secret from parents. "Don't tell adults" is one of the biggest warning signs of grooming.`,
  },
  {
    q: 'You only met someone in a game, but they know your school name and what street you live on. What should you do?',
    opts: [`That's normal — everyone shares stuff online`, 'Keep chatting — they seem nice', 'STOP, block them immediately and tell a trusted adult', 'Ask how they found out'],
    correct: 2, why: `If a stranger online knows personal details you didn't tell them, that's dangerous. Stop all contact and tell an adult immediately.`,
  },
  {
    q: 'What makes someone a "safe" online contact?',
    opts: ['They have a lot of followers', `They're a real-life friend, family member, or known adult your parents approve of`, `They've chatted with you for a long time`, 'They say they go to your school'],
    correct: 1, why: 'A safe online contact is someone you know and trust in real life too, or someone your parents know about.',
  },
];

function StrangerDangerGame() {
  const [idx, setIdx]     = useState(0);
  const [sel, setSel]     = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [done, setDone]   = useState(false);

  const q = strangerQs[idx];
  const choose = (i: number) => { if (sel !== null) return; setSel(i); if (i === q.correct) setScore(s => s + 1); };
  const next   = () => { if (idx + 1 >= strangerQs.length) { setDone(true); return; } setIdx(i => i + 1); setSel(null); };
  const replay = () => { setIdx(0); setSel(null); setScore(0); setDone(false); };

  if (done) return (
    <FinalScreen score={score} total={strangerQs.length} color={K.green}
      msg={score >= 4 ? 'You know how to stay safe from online strangers! 🌟' : 'Keep practising — online stranger safety is super important!'}
      onReplay={replay} />
  );

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between text-xs font-bold" style={{ color: K.muted }}>
        <span>Q {idx + 1}/{strangerQs.length}</span>
        <ScoreBadge score={score} total={idx} />
      </div>

      <div className="rounded-2xl border p-4" style={{ borderColor: K.green + '55', backgroundColor: K.green + '0D' }}>
        <p className="font-black text-sm" style={{ color: K.text }}>💬 {q.q}</p>
      </div>

      <div className="space-y-2">
        {q.opts.map((o, i) => {
          const revealed = sel !== null;
          const isCorrect = i === q.correct;
          const isChosen  = sel === i;
          return (
            <button key={i} onClick={() => choose(i)}
              className="w-full text-left p-3 rounded-2xl border font-bold text-sm transition-all hover:scale-[1.01]"
              style={{
                backgroundColor: !revealed ? K.quizBtn : isCorrect ? K.green + '22' : isChosen ? K.pink + '22' : K.quizBtn,
                borderColor: !revealed ? K.quizBtnBorder : isCorrect ? K.green : isChosen ? K.pink : K.quizBtnBorder,
                color: K.text,
              }}>
              {revealed && isCorrect ? '✅ ' : revealed && isChosen && !isCorrect ? '❌ ' : `${String.fromCharCode(65 + i)}. `}{o}
            </button>
          );
        })}
      </div>

      {sel !== null && (
        <div className="space-y-3">
          <div className="rounded-2xl p-4 border text-sm font-semibold"
            style={{ borderColor: K.border, backgroundColor: K.panel, color: K.muted }}>
            💡 {q.why}
          </div>
          <button onClick={next}
            className="w-full py-3 rounded-2xl font-black text-white hover:scale-[1.02] transition-all"
            style={{ backgroundColor: K.green }}>
            {idx + 1 < strangerQs.length ? 'Next Question →' : 'See My Score! 🏆'}
          </button>
        </div>
      )}
    </div>
  );
}

// ─── Game 6: Oversharing Detector ────────────────────────────────────────────

interface PostItem { content: string; isSafe: boolean; reason: string }

const postItems: PostItem[] = [
  { content: 'Just finished reading Harry Potter! ⚡📚 #books', isSafe: true, reason: 'Sharing your hobbies is fine — no personal information here.' },
  { content: 'Home alone until 8pm tonight! Parents are away. 🏠', isSafe: false, reason: 'Saying you\'re home alone tells strangers you\'re vulnerable and unsupervised.' },
  { content: 'My new dog is SO cute! His name is Biscuit 🐕', isSafe: true, reason: 'Sharing a pet\'s name is generally harmless fun.' },
  { content: 'Today was my birthday! I\'m now 11 years old 🎂 and live on Oak Street!', isSafe: false, reason: 'Your exact age + street name gives strangers too much information to locate you.' },
  { content: 'Just got to school — Day 1 at Riverside Primary! 📚', isSafe: false, reason: 'Sharing your school name publicly lets strangers know exactly where you\'ll be every day.' },
  { content: 'I love playing football on weekends! ⚽', isSafe: true, reason: 'General hobby sharing is fine — no location or personal details included.' },
  { content: 'Here\'s my phone number so we can chat: 07812 345678', isSafe: false, reason: 'NEVER post your phone number publicly — anyone could contact you, including people you don\'t know.' },
  { content: 'Just watched the new Spider-Man movie! 🕷️ Loved it!', isSafe: true, reason: 'Sharing what you watched is harmless — no personal details here.' },
];

function OversharingGame() {
  const [idx, setIdx]     = useState(0);
  const [choice, setChoice] = useState<boolean | null>(null);
  const [score, setScore] = useState(0);
  const [done, setDone]   = useState(false);

  const post = postItems[idx];

  const decide = (safe: boolean) => {
    if (choice !== null) return;
    setChoice(safe);
    if (safe === post.isSafe) setScore(s => s + 1);
  };

  const next   = () => { if (idx + 1 >= postItems.length) { setDone(true); return; } setIdx(i => i + 1); setChoice(null); };
  const replay = () => { setIdx(0); setChoice(null); setScore(0); setDone(false); };

  if (done) return (
    <FinalScreen score={score} total={postItems.length} color={K.yellow}
      msg={score >= 7 ? 'Oversharing expert — you know exactly what to keep private! 🔒' : 'Good try! Knowing what not to share keeps you much safer.'}
      onReplay={replay} />
  );

  const isCorrect = choice === post.isSafe;

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between text-xs font-bold" style={{ color: K.muted }}>
        <span>Post {idx + 1}/{postItems.length}</span>
        <ScoreBadge score={score} total={idx} />
      </div>

      <div className="rounded-2xl border p-5" style={{ borderColor: K.border, backgroundColor: K.panel }}>
        <div className="flex items-center gap-2 mb-3">
          <div className="h-8 w-8 rounded-full bg-gradient-to-br from-pink-300 to-purple-300 flex items-center justify-center text-xs font-black text-white">Me</div>
          <div>
            <p className="text-xs font-black" style={{ color: K.text }}>@my_profile</p>
            <p className="text-xs" style={{ color: K.muted }}>Just now · 🌐 Public</p>
          </div>
        </div>
        <p className="font-semibold text-sm" style={{ color: K.text }}>{post.content}</p>
      </div>

      <p className="text-sm font-black text-center" style={{ color: K.text }}>Is it safe to post this publicly?</p>

      {choice === null ? (
        <div className="grid grid-cols-2 gap-3">
          <button onClick={() => decide(true)}
            className="py-4 rounded-2xl font-black text-white text-sm hover:scale-105 transition-all"
            style={{ backgroundColor: K.green }}>
            ✅ Safe to Post
          </button>
          <button onClick={() => decide(false)}
            className="py-4 rounded-2xl font-black text-white text-sm hover:scale-105 transition-all"
            style={{ backgroundColor: K.pink }}>
            🚫 Don't Post This!
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          <div className="rounded-2xl p-4 border"
            style={{ borderColor: isCorrect ? K.green : K.pink, backgroundColor: (isCorrect ? K.green : K.pink) + '18' }}>
            <p className="font-black text-sm flex items-center gap-2 mb-1" style={{ color: K.text }}>
              {isCorrect ? <CheckCircle className="h-4 w-4 shrink-0" style={{ color: K.green }} /> : <XCircle className="h-4 w-4 shrink-0" style={{ color: K.pink }} />}
              {isCorrect ? 'Correct! 🎉' : `Actually this is ${post.isSafe ? 'safe to post ✅' : 'NOT safe to post 🚫'}`}
            </p>
            <p className="text-xs font-semibold" style={{ color: K.muted }}>💡 {post.reason}</p>
          </div>
          <button onClick={next}
            className="w-full py-3 rounded-2xl font-black text-white hover:scale-[1.02] transition-all"
            style={{ backgroundColor: K.yellow === '#F5D74E' ? K.teal : K.yellow }}>
            {idx + 1 < postItems.length ? 'Next Post →' : 'See My Score! 🏆'}
          </button>
        </div>
      )}
    </div>
  );
}

// ─── Game 7: Digital Footprint Trail ─────────────────────────────────────────

interface FootprintChoice { text: string; impact: string; privacy: number }
interface FootprintScenario { desc: string; options: [FootprintChoice, FootprintChoice] }

const footprintScenarios: FootprintScenario[] = [
  {
    desc: 'You want to leave a review for a cool game app.',
    options: [
      { text: '🙈 Skip the review', impact: 'Smart — no trace left!', privacy: 10 },
      { text: '📝 Write a review with your real name', impact: 'Your name is now permanently linked to this app in search engines!', privacy: -20 },
    ],
  },
  {
    desc: 'You created a username for a new website.',
    options: [
      { text: '🎭 Use a nickname like "StarGamer99"', impact: 'Good — a nickname keeps your real identity private.', privacy: 10 },
      { text: '👤 Use your full real name', impact: 'Your real name is now searchable on that site!', privacy: -15 },
    ],
  },
  {
    desc: 'A website asks for your birthday to sign up.',
    options: [
      { text: '🛑 Ask a parent first — you\'re under 13', impact: 'Smart — many sites are not legal for under-13s (COPPA/GDPR).', privacy: 10 },
      { text: '✍️ Enter your real birthday', impact: 'Your exact birthdate is now stored by this website!', privacy: -10 },
    ],
  },
  {
    desc: 'You\'re tagging a selfie on social media.',
    options: [
      { text: '🌐 Post it public so everyone sees it', impact: 'Anyone in the world can now see this photo and your location data if GPS is on!', privacy: -25 },
      { text: '🔒 Post it for friends-only', impact: 'Much safer — only approved people can see your photo.', privacy: 10 },
    ],
  },
];

function DigitalFootprintGame() {
  const [idx, setIdx]       = useState(0);
  const [privacy, setPrivacy] = useState(50);
  const [choices, setChoices] = useState<string[]>([]);
  const [chosen, setChosen] = useState<number | null>(null);
  const [done, setDone]     = useState(false);

  const scenario = footprintScenarios[idx];

  const pick = (i: number) => {
    if (chosen !== null) return;
    const opt = scenario.options[i];
    setChosen(i);
    setPrivacy(p => Math.min(100, Math.max(0, p + opt.privacy)));
    setChoices(c => [...c, opt.text]);
  };

  const next = () => {
    if (idx + 1 >= footprintScenarios.length) { setDone(true); return; }
    setIdx(i => i + 1); setChosen(null);
  };

  const replay = () => { setIdx(0); setPrivacy(50); setChoices([]); setChosen(null); setDone(false); };

  if (done) {
    const score = Math.round(privacy / 100 * 4);
    return (
      <div className="p-6 space-y-4 text-center">
        <p className="text-5xl">{privacy >= 70 ? '🔒' : privacy >= 40 ? '🔓' : '⚠️'}</p>
        <p className="font-black text-xl" style={{ color: K.text }}>Your Privacy Score: {privacy}/100</p>
        <div className="h-3 rounded-full overflow-hidden" style={{ backgroundColor: '#F3F4F6' }}>
          <div className="h-full rounded-full transition-all" style={{ width: `${privacy}%`, backgroundColor: privacy >= 70 ? K.green : privacy >= 40 ? K.yellow : K.pink }} />
        </div>
        <p className="font-bold text-sm" style={{ color: K.muted }}>
          {privacy >= 70 ? 'Excellent! You leave a small, safe digital footprint.' : privacy >= 40 ? 'Moderate — some choices exposed more than needed.' : 'Your digital footprint is quite large — try to be more private next time!'}
        </p>
        <div className="space-y-2 text-left">
          <p className="text-xs font-black" style={{ color: K.muted }}>Your choices:</p>
          {choices.map((c, i) => (
            <p key={i} className="text-xs font-semibold flex gap-2" style={{ color: K.text }}>
              <span className="shrink-0">·</span>{c}
            </p>
          ))}
        </div>
        <ReplayBtn onReplay={replay} color={K.teal} />
      </div>
    );
  }

  const chosen_opt = chosen !== null ? scenario.options[chosen] : null;

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between text-xs font-bold" style={{ color: K.muted }}>
        <span>Choice {idx + 1}/{footprintScenarios.length}</span>
        <span>Privacy: {privacy}/100</span>
      </div>

      <div className="h-2.5 rounded-full overflow-hidden" style={{ backgroundColor: '#F3F4F6' }}>
        <div className="h-full rounded-full transition-all duration-500"
          style={{ width: `${privacy}%`, backgroundColor: privacy >= 70 ? K.green : privacy >= 40 ? K.yellow : K.pink }} />
      </div>

      <div className="rounded-2xl border p-4" style={{ borderColor: K.blue + '55', backgroundColor: K.blue + '0D' }}>
        <p className="font-black text-sm" style={{ color: K.text }}>👣 {scenario.desc}</p>
      </div>

      {chosen === null ? (
        <div className="space-y-2">
          {scenario.options.map((opt, i) => (
            <button key={i} onClick={() => pick(i)}
              className="w-full text-left p-4 rounded-2xl border font-bold text-sm hover:scale-[1.01] transition-all"
              style={{ backgroundColor: K.surface, borderColor: K.border, color: K.text }}>
              {opt.text}
            </button>
          ))}
        </div>
      ) : (
        <div className="space-y-3">
          <div className="rounded-2xl p-4 border"
            style={{ borderColor: chosen_opt!.privacy >= 0 ? K.green : K.pink, backgroundColor: (chosen_opt!.privacy >= 0 ? K.green : K.pink) + '18' }}>
            <p className="font-black text-sm" style={{ color: K.text }}>
              {chosen_opt!.privacy >= 0 ? '✅ Good choice!' : '⚠️ This left a bigger footprint.'}
            </p>
            <p className="text-xs font-semibold mt-1" style={{ color: K.muted }}>👣 {chosen_opt!.impact}</p>
          </div>
          <button onClick={next}
            className="w-full py-3 rounded-2xl font-black text-white hover:scale-[1.02] transition-all"
            style={{ backgroundColor: K.blue }}>
            {idx + 1 < footprintScenarios.length ? 'Next Choice →' : 'See My Footprint! 👣'}
          </button>
        </div>
      )}
    </div>
  );
}

// ─── Game 8: Privacy Settings Simulator ──────────────────────────────────────

interface PrivacySetting { id: string; label: string; description: string; correctValue: boolean; explanation: string }

const privacySettings: PrivacySetting[] = [
  { id: 'profile_public', label: 'Profile Visibility: Public', description: 'Anyone on the internet can see your full profile, photos and posts.', correctValue: false, explanation: 'Your profile should be private, especially if you\'re under 18. Only approved friends should see it.' },
  { id: 'location', label: 'Share My Location in Posts', description: 'Automatically adds your exact location to every photo and post you share.', correctValue: false, explanation: 'Location sharing tells people exactly where you are — including your home and school! Always turn this OFF.' },
  { id: 'dms_anyone', label: 'Anyone Can Send Me Messages', description: 'Strangers can send you private messages without following you first.', correctValue: false, explanation: 'Strangers sending DMs can be dangerous. Set this to "Friends Only" to stay safer.' },
  { id: '2fa_on', label: 'Two-Factor Authentication: ON', description: 'Requires a code from your phone every time you log in.', correctValue: true, explanation: '2FA is a great security feature! It means even if someone knows your password, they can\'t log in without your phone.' },
  { id: 'activity_status', label: 'Show When I\'m Online', description: 'Everyone can see when you\'re actively using the app.', correctValue: false, explanation: 'Showing your online status lets strangers know exactly when you\'re active and available.' },
  { id: 'tag_approval', label: 'Approve Tags Before They Appear', description: 'You must approve any photo or post someone tags you in before it shows on your profile.', correctValue: true, explanation: 'Approving tags gives you control over what appears on your profile — always a good idea!' },
];

function PrivacySimulatorGame() {
  const [settings, setSettings] = useState<Record<string, boolean>>(() =>
    Object.fromEntries(privacySettings.map(s => [s.id, !s.correctValue]))
  );
  const [checked, setChecked]   = useState(false);

  const toggle = (id: string) => {
    if (checked) return;
    setSettings(s => ({ ...s, [id]: !s[id] }));
  };

  const replay = () => {
    setSettings(Object.fromEntries(privacySettings.map(s => [s.id, !s.correctValue])));
    setChecked(false);
  };

  const score = checked ? privacySettings.filter(s => settings[s.id] === s.correctValue).length : 0;

  return (
    <div className="p-6 space-y-4">
      <div className="rounded-2xl border p-4" style={{ borderColor: K.blue + '55', backgroundColor: K.blue + '0D' }}>
        <p className="font-black text-sm" style={{ color: K.text }}>⚙️ Set up these privacy settings correctly — then tap "Check Settings"!</p>
      </div>

      <div className="space-y-3">
        {privacySettings.map(s => {
          const isOn = settings[s.id];
          const isCorrect = checked ? settings[s.id] === s.correctValue : null;
          const borderColor = !checked ? K.border : isCorrect ? K.green : K.pink;
          return (
            <div key={s.id} className="rounded-2xl border p-4 space-y-2"
              style={{ borderColor, backgroundColor: !checked ? K.quizBtn : (isCorrect ? K.green : K.pink) + '0D' }}>
              <div className="flex items-center justify-between gap-3">
                <div className="flex-1 min-w-0">
                  <p className="font-black text-sm" style={{ color: K.text }}>{s.label}</p>
                  <p className="text-xs font-semibold mt-0.5" style={{ color: K.muted }}>{s.description}</p>
                </div>
                <button onClick={() => toggle(s.id)}
                  className="shrink-0 h-7 px-3 rounded-full font-black text-xs text-white transition-all hover:scale-105"
                  style={{ backgroundColor: isOn ? K.green : K.pink }}>
                  {isOn ? 'ON' : 'OFF'}
                </button>
              </div>
              {checked && (
                <p className="text-xs font-semibold" style={{ color: K.muted }}>
                  {isCorrect ? '✅' : '❌'} {s.explanation}
                </p>
              )}
            </div>
          );
        })}
      </div>

      {!checked ? (
        <button onClick={() => setChecked(true)}
          className="w-full py-3 rounded-2xl font-black text-white hover:scale-[1.02] transition-all"
          style={{ backgroundColor: K.blue }}>
          Check My Settings 🔍
        </button>
      ) : (
        <div className="space-y-3">
          <div className="rounded-2xl border p-4 text-center"
            style={{ borderColor: score >= 5 ? K.green : K.yellow, backgroundColor: (score >= 5 ? K.green : K.yellow) + '18' }}>
            <p className="font-black text-lg" style={{ color: K.text }}>{score}/{privacySettings.length} correct!</p>
            <p className="text-sm font-semibold mt-1" style={{ color: K.muted }}>
              {score === 6 ? 'Perfect privacy setup! 🔐' : score >= 4 ? 'Almost there — review the red ones!' : 'Check the explanations and try again!'}
            </p>
          </div>
          <ReplayBtn onReplay={replay} color={K.blue} />
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// DIGITAL LITERACY GAMES
// ═══════════════════════════════════════════════════════════════════════════════

// ─── Game 9: Fake News vs Real News ──────────────────────────────────────────

const newsItems = [
  {
    headline: 'Scientists Discover New Species of Deep-Sea Fish With Bioluminescent Patterns',
    source: 'National Geographic',
    date: 'March 2024',
    isFake: false,
    signals: ['Credible source (National Geographic)', 'Specific, factual language', 'No exaggerated claims', 'Plausible scientific topic'],
  },
  {
    headline: 'SHOCKING: Eating Broccoli Once a Week CURES ALL Diseases Doctors Don\'t Want You to Know!!',
    source: 'HealthTruthsBlog.net',
    date: 'Unknown',
    isFake: true,
    signals: ['ALL CAPS in headline = emotional manipulation', '"Doctors don\'t want you to know" = conspiracy language', 'No credible medical source cited', 'Extreme claim with no evidence'],
  },
  {
    headline: 'Global Sea Levels Have Risen 3.6 Inches Since 1993, New NASA Data Shows',
    source: 'NASA Climate',
    date: 'January 2024',
    isFake: false,
    signals: ['NASA is a trusted, government source', 'Specific statistic (3.6 inches)', 'Specific date range given (since 1993)', 'Cites data/evidence'],
  },
  {
    headline: 'Teenager Earns $10,000 Per Day Playing Video Games From Home — Here\'s How YOU Can Too!',
    source: 'QuickMoneyOnline.info',
    date: 'Not listed',
    isFake: true,
    signals: ['Unrealistic financial claim', 'Suspicious .info domain', 'Designed to make you click (clickbait)', 'No verifiable source or details'],
  },
  {
    headline: 'New Study Finds Regular Exercise Improves Sleep Quality in Teenagers',
    source: 'British Medical Journal',
    date: 'February 2024',
    isFake: false,
    signals: ['BMJ is a highly respected medical journal', 'Modest, believable claim', 'Cites a study', 'No exaggerated language'],
  },
  {
    headline: 'BREAKING: Mobile Phone Signal Proven To Make People Invisible If Used at Midnight!!',
    source: 'WeirdFactsDaily.co',
    date: 'Yesterday',
    isFake: true,
    signals: ['Scientifically impossible claim', 'No credible source', 'Vague date ("yesterday")', 'Multiple exclamation marks = emotional manipulation'],
  },
];

function FakeNewsGame() {
  const [idx, setIdx]     = useState(0);
  const [choice, setChoice] = useState<boolean | null>(null);
  const [score, setScore] = useState(0);
  const [done, setDone]   = useState(false);

  const news = newsItems[idx];
  const decide = (isFake: boolean) => {
    if (choice !== null) return;
    setChoice(isFake);
    if (isFake === news.isFake) setScore(s => s + 1);
  };

  const next   = () => { if (idx + 1 >= newsItems.length) { setDone(true); return; } setIdx(i => i + 1); setChoice(null); };
  const replay = () => { setIdx(0); setChoice(null); setScore(0); setDone(false); };

  if (done) return (
    <FinalScreen score={score} total={newsItems.length} color={K.green}
      msg={score >= 5 ? 'News detective extraordinaire — you can spot fake news! 🕵️' : 'Good effort! Always check the source before believing a headline.'}
      onReplay={replay} />
  );

  const isCorrect = choice === news.isFake;

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between text-xs font-bold" style={{ color: K.muted }}>
        <span>Article {idx + 1}/{newsItems.length}</span>
        <ScoreBadge score={score} total={idx} />
      </div>

      <div className="rounded-2xl border overflow-hidden" style={{ borderColor: K.border }}>
        <div className="px-4 py-3 border-b" style={{ borderColor: K.border, backgroundColor: K.panel }}>
          <p className="text-xs font-black" style={{ color: K.muted }}>📰 {news.source} · {news.date}</p>
        </div>
        <div className="px-4 py-4">
          <p className="font-black text-base leading-snug" style={{ color: K.text }}>{news.headline}</p>
        </div>
      </div>

      <p className="text-sm font-black text-center" style={{ color: K.text }}>Is this real news or fake news?</p>

      {choice === null ? (
        <div className="grid grid-cols-2 gap-3">
          <button onClick={() => decide(false)}
            className="py-4 rounded-2xl font-black text-white text-sm hover:scale-105 transition-all"
            style={{ backgroundColor: K.green }}>
            📰 Real News
          </button>
          <button onClick={() => decide(true)}
            className="py-4 rounded-2xl font-black text-white text-sm hover:scale-105 transition-all"
            style={{ backgroundColor: K.pink }}>
            🚫 Fake News!
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          <div className="rounded-2xl p-4 border space-y-2"
            style={{ borderColor: isCorrect ? K.green : K.pink, backgroundColor: (isCorrect ? K.green : K.pink) + '18' }}>
            <p className="font-black text-sm flex items-center gap-2" style={{ color: K.text }}>
              {isCorrect ? <CheckCircle className="h-4 w-4 shrink-0" style={{ color: K.green }} /> : <XCircle className="h-4 w-4 shrink-0" style={{ color: K.pink }} />}
              {isCorrect ? 'Correct! 🎉' : `Not quite — this is ${news.isFake ? 'FAKE NEWS! 🚫' : 'actually REAL news ✅'}`}
            </p>
            <p className="text-xs font-black" style={{ color: K.muted }}>
              {news.isFake ? '🚩 Warning signals:' : '✅ Credibility signals:'}
            </p>
            {news.signals.map((s, i) => (
              <p key={i} className="text-xs font-semibold flex items-center gap-1" style={{ color: K.muted }}>
                <span>{news.isFake ? '⚠️' : '✔️'}</span>{s}
              </p>
            ))}
          </div>
          <button onClick={next}
            className="w-full py-3 rounded-2xl font-black text-white hover:scale-[1.02] transition-all"
            style={{ backgroundColor: K.green }}>
            {idx + 1 < newsItems.length ? 'Next Article →' : 'See My Score! 🏆'}
          </button>
        </div>
      )}
    </div>
  );
}

// ─── Game 10: Reliable Website Checker ───────────────────────────────────────

const websites = [
  {
    url: 'https://www.who.int/health-topics/influenza', domain: 'who.int',
    title: 'Influenza (Seasonal) — World Health Organization',
    details: ['Official .int domain (international organisations)', 'Published by WHO (UN health agency)', 'HTTPS secure connection', 'Clear authorship and date'],
    isTrustworthy: true,
  },
  {
    url: 'https://healthfacts-freecures.net/flu-remedies', domain: 'healthfacts-freecures.net',
    title: 'FLU MIRACLE CURES Doctors Are Hiding! 100% Natural',
    details: ['Suspicious .net domain, not official medical', '"Miracle cure" language = red flag', 'No identified author or date', 'Designed to sell something'],
    isTrustworthy: false,
  },
  {
    url: 'https://www.bbc.co.uk/news/science', domain: 'bbc.co.uk',
    title: 'Science & Environment — BBC News',
    details: ['BBC is a major, trusted news organisation', 'HTTPS secure', 'Identified editorial team', 'Clearly dated articles with sources'],
    isTrustworthy: true,
  },
  {
    url: 'http://freepizza-claim-now.info/winner', domain: 'freepizza-claim-now.info',
    title: 'YOU ARE TODAY\'S WINNER — Claim Your Free Pizza Now!!!',
    details: ['HTTP (not HTTPS) = insecure', '.info domain = unverified', 'Unbelievable prize claim', 'Urgent pressure language ("claim NOW!")'],
    isTrustworthy: false,
  },
  {
    url: 'https://www.nasa.gov/solar-system', domain: 'nasa.gov',
    title: 'Solar System Exploration — NASA',
    details: ['.gov domain = US government', 'NASA is a globally trusted science agency', 'HTTPS secure connection', 'Clear published dates and author credits'],
    isTrustworthy: true,
  },
];

function WebsiteCheckerGame() {
  const [idx, setIdx]     = useState(0);
  const [choice, setChoice] = useState<boolean | null>(null);
  const [score, setScore] = useState(0);
  const [done, setDone]   = useState(false);

  const site = websites[idx];
  const decide = (trust: boolean) => {
    if (choice !== null) return;
    setChoice(trust);
    if (trust === site.isTrustworthy) setScore(s => s + 1);
  };

  const next   = () => { if (idx + 1 >= websites.length) { setDone(true); return; } setIdx(i => i + 1); setChoice(null); };
  const replay = () => { setIdx(0); setChoice(null); setScore(0); setDone(false); };

  if (done) return (
    <FinalScreen score={score} total={websites.length} color={K.blue}
      msg={score >= 4 ? 'Brilliant! You can tell reliable websites from dodgy ones! 🌐' : 'Keep practising — learning to spot trustworthy sites keeps you safe online!'}
      onReplay={replay} />
  );

  const isCorrect = choice === site.isTrustworthy;

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between text-xs font-bold" style={{ color: K.muted }}>
        <span>Website {idx + 1}/{websites.length}</span>
        <ScoreBadge score={score} total={idx} />
      </div>

      <div className="rounded-2xl border overflow-hidden" style={{ borderColor: K.border }}>
        <div className="px-3 py-2 flex items-center gap-2 border-b" style={{ borderColor: K.border, backgroundColor: K.panel }}>
          <Lock className="h-3 w-3" style={{ color: K.muted }} />
          <p className="text-xs font-semibold truncate" style={{ color: K.muted }}>{site.url}</p>
        </div>
        <div className="px-4 py-4">
          <p className="font-black text-sm" style={{ color: K.text }}>{site.title}</p>
          <p className="text-xs mt-1 font-semibold" style={{ color: K.muted }}>{site.domain}</p>
        </div>
      </div>

      <p className="text-sm font-black text-center" style={{ color: K.text }}>Is this a trustworthy website?</p>

      {choice === null ? (
        <div className="grid grid-cols-2 gap-3">
          <button onClick={() => decide(true)}
            className="py-4 rounded-2xl font-black text-white text-sm hover:scale-105 transition-all"
            style={{ backgroundColor: K.green }}>
            ✅ Trustworthy
          </button>
          <button onClick={() => decide(false)}
            className="py-4 rounded-2xl font-black text-white text-sm hover:scale-105 transition-all"
            style={{ backgroundColor: K.pink }}>
            ⚠️ Not Trustworthy
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          <div className="rounded-2xl p-4 border space-y-2"
            style={{ borderColor: isCorrect ? K.green : K.pink, backgroundColor: (isCorrect ? K.green : K.pink) + '18' }}>
            <p className="font-black text-sm flex items-center gap-2" style={{ color: K.text }}>
              {isCorrect ? <CheckCircle className="h-4 w-4 shrink-0" style={{ color: K.green }} /> : <XCircle className="h-4 w-4 shrink-0" style={{ color: K.pink }} />}
              {isCorrect ? 'Correct! 🎉' : `Actually it IS ${site.isTrustworthy ? 'trustworthy ✅' : 'NOT trustworthy ⚠️'}`}
            </p>
            {site.details.map((d, i) => (
              <p key={i} className="text-xs font-semibold flex items-center gap-1" style={{ color: K.muted }}>
                <span>{site.isTrustworthy ? '✔️' : '⚠️'}</span>{d}
              </p>
            ))}
          </div>
          <button onClick={next}
            className="w-full py-3 rounded-2xl font-black text-white hover:scale-[1.02] transition-all"
            style={{ backgroundColor: K.blue }}>
            {idx + 1 < websites.length ? 'Next Website →' : 'See My Score! 🏆'}
          </button>
        </div>
      )}
    </div>
  );
}

// ─── Game 11: Screen Time Balance Challenge ───────────────────────────────────

interface TimeActivity { label: string; emoji: string; category: 'screen' | 'offline'; recommended: number }

const activities: TimeActivity[] = [
  { label: 'Social media scrolling', emoji: '📱', category: 'screen',  recommended: 30  },
  { label: 'Outdoor play / exercise', emoji: '⚽', category: 'offline', recommended: 60  },
  { label: 'Playing video games',    emoji: '🎮', category: 'screen',  recommended: 45  },
  { label: 'Reading a book',         emoji: '📚', category: 'offline', recommended: 30  },
  { label: 'Watching YouTube/TV',    emoji: '📺', category: 'screen',  recommended: 45  },
  { label: 'Talking with family',    emoji: '👨‍👩‍👧', category: 'offline', recommended: 30  },
  { label: 'Homework on computer',   emoji: '💻', category: 'screen',  recommended: 30  },
  { label: 'Hobby (art/music etc.)', emoji: '🎨', category: 'offline', recommended: 30  },
];

function ScreenTimeGame() {
  const [allocations, setAllocations] = useState<Record<string, number>>(
    () => Object.fromEntries(activities.map(a => [a.label, 0]))
  );
  const [submitted, setSubmitted] = useState(false);
  const [replay, setReplay] = useState(0);

  const totalMinutes = Object.values(allocations).reduce((a, b) => a + b, 0);
  const screenMinutes = activities.filter(a => a.category === 'screen').reduce((sum, a) => sum + (allocations[a.label] || 0), 0);
  const offlineMinutes = activities.filter(a => a.category === 'offline').reduce((sum, a) => sum + (allocations[a.label] || 0), 0);

  const setTime = (label: string, val: number) => {
    if (submitted) return;
    setAllocations(prev => ({ ...prev, [label]: Math.max(0, Math.min(120, val)) }));
  };

  const doReplay = () => {
    setAllocations(Object.fromEntries(activities.map(a => [a.label, 0])));
    setSubmitted(false);
    setReplay(r => r + 1);
  };

  const score = activities.filter(a => {
    const diff = Math.abs((allocations[a.label] || 0) - a.recommended);
    return diff <= 15;
  }).length;

  return (
    <div className="p-6 space-y-4">
      <div className="rounded-2xl border p-4 text-center" style={{ borderColor: K.green + '55', backgroundColor: K.green + '0D' }}>
        <p className="font-black text-sm" style={{ color: K.text }}>
          ⏱️ You have 4 free hours (240 mins) today. Allocate your time!
        </p>
        <p className="text-xs font-semibold mt-1" style={{ color: K.muted }}>
          Used: {totalMinutes} / 240 mins
          {totalMinutes > 240 && <span style={{ color: K.pink }}> — over budget!</span>}
        </p>
        <div className="h-2.5 rounded-full overflow-hidden mt-2" style={{ backgroundColor: '#F3F4F6' }}>
          <div className="h-full rounded-full transition-all"
            style={{ width: `${Math.min(100, (totalMinutes / 240) * 100)}%`, backgroundColor: totalMinutes > 240 ? K.pink : K.green }} />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
        {activities.map(act => (
          <div key={act.label} className="flex items-center gap-3 p-3 rounded-2xl border"
            style={{ borderColor: K.border, backgroundColor: act.category === 'screen' ? K.blue + '0D' : K.green + '0D' }}>
            <span className="text-2xl shrink-0">{act.emoji}</span>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-black" style={{ color: K.text }}>{act.label}</p>
              <p className="text-xs" style={{ color: K.muted }}>{act.category === 'screen' ? '📱 Screen' : '🌿 Offline'}</p>
            </div>
            <div className="flex items-center gap-1 shrink-0">
              <button onClick={() => setTime(act.label, (allocations[act.label] || 0) - 15)}
                className="h-6 w-6 rounded-lg text-xs font-black flex items-center justify-center border hover:scale-110 transition-all"
                style={{ borderColor: K.border, color: K.muted }}>−</button>
              <span className="text-xs font-black w-10 text-center" style={{ color: K.text }}>
                {allocations[act.label] || 0}m
              </span>
              <button onClick={() => setTime(act.label, (allocations[act.label] || 0) + 15)}
                className="h-6 w-6 rounded-lg text-xs font-black flex items-center justify-center border hover:scale-110 transition-all"
                style={{ borderColor: K.border, color: K.muted }}>+</button>
            </div>
          </div>
        ))}
      </div>

      {!submitted ? (
        <button disabled={totalMinutes === 0} onClick={() => setSubmitted(true)}
          className="w-full py-3 rounded-2xl font-black text-white hover:scale-[1.02] transition-all disabled:opacity-40"
          style={{ backgroundColor: K.green }}>
          Check My Balance! ⚖️
        </button>
      ) : (
        <div className="space-y-3">
          <div className="rounded-2xl border p-4 space-y-3" style={{ borderColor: K.border, backgroundColor: K.panel }}>
            <p className="font-black text-base text-center" style={{ color: K.text }}>
              {score >= 6 ? '🌟 Great balance!' : score >= 4 ? '🤔 Getting there!' : '📱 Too much screen time!'}
            </p>
            <div className="grid grid-cols-2 gap-2 text-center text-xs">
              <div className="rounded-xl p-2" style={{ backgroundColor: K.blue + '15' }}>
                <p className="font-black" style={{ color: K.blue }}>📱 Screen</p>
                <p className="font-bold" style={{ color: K.text }}>{screenMinutes} mins</p>
                <p className="text-xs" style={{ color: K.muted }}>rec: ≤ 120</p>
              </div>
              <div className="rounded-xl p-2" style={{ backgroundColor: K.green + '15' }}>
                <p className="font-black" style={{ color: K.green }}>🌿 Offline</p>
                <p className="font-bold" style={{ color: K.text }}>{offlineMinutes} mins</p>
                <p className="text-xs" style={{ color: K.muted }}>rec: ≥ 120</p>
              </div>
            </div>
            <p className="text-xs font-semibold text-center" style={{ color: K.muted }}>
              {score}/{activities.length} activities close to recommended time
            </p>
          </div>
          <ReplayBtn onReplay={doReplay} color={K.green} />
        </div>
      )}
    </div>
  );
}

// ─── Game 12: Emoji / Text Tone Interpreter ───────────────────────────────────

const toneMessages = [
  {
    message: 'Oh wow, GREAT job... 🙄',
    opts: ['Genuinely complimenting you', 'Being sarcastic and mean 😬', 'Joking in a friendly way', 'Very excited for you'],
    correct: 1, why: 'The eye-roll emoji 🙄 + "GREAT job..." with ellipsis = classic sarcasm. The meaning is the opposite of the words.',
  },
  {
    message: 'haha ok see ya 😊👋',
    opts: ['Angry and upset', 'Friendly and casual goodbye', 'Scared and nervous', 'Very serious'],
    correct: 1, why: '"haha" + friendly emojis = light, casual and friendly. Context and emojis together tell the true tone.',
  },
  {
    message: 'Whatever. Do what you want. I don\'t care.',
    opts: ['Happy and relaxed', 'Curious and interested', 'Upset or dismissive — passive aggressive 😤', 'Being supportive'],
    correct: 2, why: '"Whatever" + "I don\'t care" without any emojis = classic passive-aggressive / dismissive tone. The person probably DOES care.',
  },
  {
    message: 'omg omg omg you won?!?! 🎉🎉🎉 i\'m literally screaming rn!!!',
    opts: ['Angry and jealous', 'Bored and uninterested', 'Hugely excited and celebrating for you 🎊', 'Confused and surprised'],
    correct: 2, why: 'Triple emojis + repeated "omg" + exclamation marks + "literally screaming" = extreme positive excitement and happiness for you!',
  },
  {
    message: 'ok',
    opts: ['Totally fine with everything', 'Possibly annoyed or giving a cold reply 😶', 'Very enthusiastic', 'Being funny'],
    correct: 1, why: 'Just "ok" with no emojis or context can feel cold or dismissive. Without warmth signals, it often means the person is annoyed or not happy.',
  },
  {
    message: 'No worries at all! Take your time 😊✨',
    opts: ['Secretly frustrated and annoyed', 'Genuinely kind and relaxed ✅', 'Upset and crying', 'Sarcastic'],
    correct: 1, why: 'Warm emojis (😊✨) + encouraging words = genuinely kind tone. Positive emojis are a strong signal of warm intent.',
  },
];

function EmojiToneGame() {
  const [idx, setIdx]     = useState(0);
  const [sel, setSel]     = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [done, setDone]   = useState(false);

  const msg = toneMessages[idx];
  const choose = (i: number) => { if (sel !== null) return; setSel(i); if (i === msg.correct) setScore(s => s + 1); };
  const next   = () => { if (idx + 1 >= toneMessages.length) { setDone(true); return; } setIdx(i => i + 1); setSel(null); };
  const replay = () => { setIdx(0); setSel(null); setScore(0); setDone(false); };

  if (done) return (
    <FinalScreen score={score} total={toneMessages.length} color={K.pink}
      msg={score >= 5 ? 'Emoji master — you read tone like a pro! 💬' : 'Great practice! Tone can be tricky online — always ask if unsure.'}
      onReplay={replay} />
  );

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between text-xs font-bold" style={{ color: K.muted }}>
        <span>Message {idx + 1}/{toneMessages.length}</span>
        <ScoreBadge score={score} total={idx} />
      </div>

      <div className="rounded-2xl border p-5 text-center" style={{ borderColor: K.border, backgroundColor: K.panel }}>
        <div className="inline-block rounded-2xl px-4 py-3 text-base font-semibold"
          style={{ backgroundColor: K.surface, border: `1px solid ${K.border}`, color: K.text }}>
          {msg.message}
        </div>
      </div>

      <p className="text-sm font-black text-center" style={{ color: K.text }}>What is the TRUE tone of this message?</p>

      <div className="space-y-2">
        {msg.opts.map((o, i) => {
          const revealed = sel !== null;
          const isCorrect = i === msg.correct;
          const isChosen  = sel === i;
          return (
            <button key={i} onClick={() => choose(i)}
              className="w-full text-left p-3 rounded-2xl border font-bold text-sm transition-all hover:scale-[1.01]"
              style={{
                backgroundColor: !revealed ? K.quizBtn : isCorrect ? K.green + '22' : isChosen ? K.pink + '22' : K.quizBtn,
                borderColor: !revealed ? K.quizBtnBorder : isCorrect ? K.green : isChosen ? K.pink : K.quizBtnBorder,
                color: K.text,
              }}>
              {revealed && isCorrect ? '✅ ' : revealed && isChosen && !isCorrect ? '❌ ' : `${String.fromCharCode(65 + i)}. `}{o}
            </button>
          );
        })}
      </div>

      {sel !== null && (
        <div className="space-y-3">
          <div className="rounded-2xl p-4 border text-sm font-semibold"
            style={{ borderColor: K.border, backgroundColor: K.panel, color: K.muted }}>
            💡 {msg.why}
          </div>
          <button onClick={next}
            className="w-full py-3 rounded-2xl font-black text-white hover:scale-[1.02] transition-all"
            style={{ backgroundColor: K.pink }}>
            {idx + 1 < toneMessages.length ? 'Next Message →' : 'See My Score! 🏆'}
          </button>
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// MAIN PAGE
// ═══════════════════════════════════════════════════════════════════════════════

// ─── Game 13: Safety Word Scramble ───────────────────────────────────────────

const SCRAMBLE_WORDS = [
  { word: 'PASSWORD',  hint: 'Keep this secret — never share it!',              category: 'Security'  },
  { word: 'FIREWALL',  hint: 'Software that protects your device from attacks',  category: 'Security'  },
  { word: 'PHISHING',  hint: 'Fake messages trying to steal your information',   category: 'Scams'     },
  { word: 'PRIVACY',   hint: 'Keeping personal information safe and hidden',     category: 'Safety'    },
  { word: 'MALWARE',   hint: 'Harmful software designed to damage your device',  category: 'Security'  },
  { word: 'STRANGER',  hint: 'Someone online you do not know in real life',      category: 'Safety'    },
  { word: 'BLOCKING',  hint: 'Stopping someone from contacting you online',      category: 'Safety'    },
  { word: 'BACKUP',    hint: 'Saving a copy of your files in a safe place',      category: 'Security'  },
  { word: 'VIRUS',     hint: 'A harmful program that spreads between devices',   category: 'Security'  },
  { word: 'CONSENT',   hint: 'Asking permission before sharing someone\'s info', category: 'Safety'    },
];

function scramble(word: string): string {
  const arr = word.split('');
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr.join('') === word ? scramble(word) : arr.join('');
}

function WordScrambleGame() {
  const [idx, setIdx]         = useState(0);
  const [input, setInput]     = useState('');
  const [score, setScore]     = useState(0);
  const [feedback, setFeedback] = useState<'correct' | 'wrong' | null>(null);
  const [showHint, setShowHint] = useState(false);
  const [done, setDone]       = useState(false);
  const [scrambled, setScrambled] = useState(() => scramble(SCRAMBLE_WORDS[0].word));

  const current = SCRAMBLE_WORDS[idx];

  const nextWord = (correct: boolean) => {
    const nextIdx = idx + 1;
    if (nextIdx >= SCRAMBLE_WORDS.length) { setDone(true); return; }
    setIdx(nextIdx);
    setScrambled(scramble(SCRAMBLE_WORDS[nextIdx].word));
    setInput('');
    setFeedback(null);
    setShowHint(false);
    if (correct) setScore(s => s + 1);
  };

  const check = () => {
    const correct = input.trim().toUpperCase() === current.word;
    setFeedback(correct ? 'correct' : 'wrong');
    if (correct) setScore(s => s + 1);
    setTimeout(() => nextWord(false), 1200);
  };

  const skip = () => nextWord(false);

  const reset = () => {
    setIdx(0); setInput(''); setScore(0); setFeedback(null);
    setShowHint(false); setDone(false);
    setScrambled(scramble(SCRAMBLE_WORDS[0].word));
  };

  if (done) return (
    <FinalScreen score={score} total={SCRAMBLE_WORDS.length}
      msg={score >= 8 ? 'Amazing! You know your cybersecurity vocabulary!' : 'Great job — keep practising those words!'}
      color={K.teal} onReplay={reset} />
  );

  return (
    <div className="p-6 space-y-5">
      <div className="flex items-center justify-between">
        <ScoreBadge score={score} total={SCRAMBLE_WORDS.length} />
        <span className="text-xs font-bold" style={{ color: K.muted }}>{idx + 1} / {SCRAMBLE_WORDS.length}</span>
      </div>
      <div className="rounded-2xl p-5 text-center space-y-3" style={{ backgroundColor: K.teal + '12', border: `2px solid ${K.teal}33` }}>
        <p className="text-xs font-black uppercase tracking-wider" style={{ color: K.teal }}>Unscramble this word</p>
        <p className="text-3xl font-black tracking-[0.25em]" style={{ color: K.text }}>{scrambled}</p>
        <span className="inline-block text-xs px-3 py-1 rounded-full font-bold border"
          style={{ borderColor: K.teal + '44', color: K.teal, backgroundColor: K.teal + '12' }}>
          {current.category}
        </span>
      </div>
      {showHint && (
        <div className="rounded-xl p-3 text-sm font-semibold" style={{ backgroundColor: K.yellow + '22', border: `1px solid ${K.yellow}` }}>
          💡 Hint: {current.hint}
        </div>
      )}
      {feedback && (
        <div className={`rounded-xl p-3 text-center font-black text-sm ${feedback === 'correct' ? 'kids-star-pop' : 'kids-shake'}`}
          style={{ backgroundColor: feedback === 'correct' ? K.green + '22' : K.pink + '22',
                   border: `2px solid ${feedback === 'correct' ? K.green : K.pink}` }}>
          {feedback === 'correct' ? '🎉 Correct! Amazing!' : `❌ The answer was: ${current.word}`}
        </div>
      )}
      <input value={input} onChange={e => setInput(e.target.value.toUpperCase())}
        onKeyDown={e => e.key === 'Enter' && input.trim() && check()}
        placeholder="Type your answer..."
        className="w-full px-4 py-3 rounded-2xl border font-black text-lg text-center tracking-widest outline-none transition-all"
        style={{ borderColor: K.teal, backgroundColor: K.surface, color: K.text }} />
      <div className="flex gap-3">
        <button onClick={() => setShowHint(true)} disabled={showHint}
          className="flex-1 py-2.5 rounded-2xl font-black text-sm border transition-all hover:scale-[1.02] disabled:opacity-40"
          style={{ borderColor: K.yellow, color: K.text, backgroundColor: K.yellow + '22' }}>
          💡 Hint
        </button>
        <button onClick={check} disabled={!input.trim()}
          className="flex-1 py-2.5 rounded-2xl font-black text-sm text-white transition-all hover:scale-[1.02] disabled:opacity-40"
          style={{ backgroundColor: K.teal }}>
          Check ✓
        </button>
        <button onClick={skip}
          className="flex-1 py-2.5 rounded-2xl font-black text-sm border transition-all hover:scale-[1.02]"
          style={{ borderColor: K.border, color: K.muted }}>
          Skip →
        </button>
      </div>
    </div>
  );
}

// ─── Game 14: Safe or Unsafe? Tap Game ───────────────────────────────────────

const TAP_SCENARIOS = [
  { text: 'A new friend in a game asks for your home address',                       safe: false, reason: 'Never share your address with strangers online!' },
  { text: 'You use a strong password with letters, numbers and symbols',             safe: true,  reason: 'Strong passwords keep your accounts secure.' },
  { text: 'A pop-up says you won a prize and asks for your phone number',            safe: false, reason: 'This is a scam! Real prizes don\'t need your number.' },
  { text: 'You tell a trusted adult when something upsets you online',               safe: true,  reason: 'Telling a trusted adult is always the right thing to do.' },
  { text: 'Someone you only know online asks to meet in person',                     safe: false, reason: 'Online strangers are still strangers in real life.' },
  { text: 'You log out of your account on a shared school computer',                 safe: true,  reason: 'Always log out on shared devices to protect your account.' },
  { text: 'You share your full name and school on a public profile',                 safe: false, reason: 'This gives strangers too much information about you.' },
  { text: 'You block someone who keeps sending nasty messages',                      safe: true,  reason: 'Blocking is a great tool to stop harassment.' },
  { text: 'You download a free game from an unknown website',                        safe: false, reason: 'Unknown downloads can contain viruses or malware.' },
  { text: 'You ask a parent before making a new online account',                     safe: true,  reason: 'Involving a trusted adult keeps you safer online.' },
  { text: 'Your online friend says "don\'t tell your parents about our chats"',      safe: false, reason: 'Safe adults never ask kids to keep secrets from parents.' },
  { text: 'You report a mean comment on a game rather than replying angrily',       safe: true,  reason: 'Reporting and not engaging is the safest response.' },
];

function TapSafeGame() {
  const [idx, setIdx]       = useState(0);
  const [score, setScore]   = useState(0);
  const [answer, setAnswer] = useState<boolean | null>(null);
  const [done, setDone]     = useState(false);
  const [timeLeft, setTimeLeft] = useState(25);
  const [timerActive, setTimerActive] = useState(true);

  useEffect(() => {
    if (!timerActive || answer !== null) return;
    if (timeLeft <= 0) { handleAnswer(false); return; }
    const t = setTimeout(() => setTimeLeft(s => s - 1), 1000);
    return () => clearTimeout(t);
  }, [timeLeft, timerActive, answer]);

  const handleAnswer = (userSafe: boolean) => {
    setTimerActive(false);
    const correct = userSafe === TAP_SCENARIOS[idx].safe;
    if (correct) setScore(s => s + 1);
    setAnswer(userSafe);
    setTimeout(() => {
      const next = idx + 1;
      if (next >= TAP_SCENARIOS.length) { setDone(true); return; }
      setIdx(next); setAnswer(null); setTimeLeft(25); setTimerActive(true);
    }, 1400);
  };

  const reset = () => {
    setIdx(0); setScore(0); setAnswer(null); setDone(false);
    setTimeLeft(25); setTimerActive(true);
  };

  if (done) return (
    <FinalScreen score={score} total={TAP_SCENARIOS.length}
      msg={score >= 10 ? 'Incredible! You\'re a real safety expert!' : 'Good effort — every round makes you smarter!'}
      color={K.green} onReplay={reset} />
  );

  const sc = TAP_SCENARIOS[idx];
  const timerPct = (timeLeft / 25) * 100;
  const timerColor = timeLeft > 10 ? K.green : timeLeft > 5 ? K.yellow : K.pink;

  return (
    <div className="p-6 space-y-5">
      <div className="flex items-center justify-between">
        <ScoreBadge score={score} total={TAP_SCENARIOS.length} />
        <div className="flex items-center gap-2">
          <div className="h-2 w-24 rounded-full overflow-hidden bg-slate-100">
            <div className="h-full rounded-full transition-all duration-1000"
              style={{ width: `${timerPct}%`, backgroundColor: timerColor }} />
          </div>
          <span className="text-sm font-black w-6 text-right" style={{ color: timerColor }}>{timeLeft}</span>
        </div>
      </div>

      <div className="rounded-2xl p-5 text-center min-h-[80px] flex items-center justify-center"
        style={{ backgroundColor: K.quizBtn, border: `1px solid ${K.border}` }}>
        <p className="font-bold text-base leading-snug" style={{ color: K.text }}>{sc.text}</p>
      </div>

      {answer !== null && (
        <div className={`rounded-xl p-3 text-sm font-semibold text-center ${answer === sc.safe ? 'kids-star-pop' : 'kids-shake'}`}
          style={{
            backgroundColor: answer === sc.safe ? K.green + '22' : K.pink + '22',
            border: `2px solid ${answer === sc.safe ? K.green : K.pink}`,
          }}>
          {answer === sc.safe ? '✅ Correct! ' : '❌ '}{sc.reason}
        </div>
      )}

      <div className="grid grid-cols-2 gap-4">
        <button onClick={() => handleAnswer(true)} disabled={answer !== null}
          className="py-5 rounded-2xl font-black text-xl text-white transition-all hover:scale-[1.04] active:scale-[0.96] disabled:opacity-50"
          style={{ backgroundColor: K.green }}>
          ✅ SAFE
        </button>
        <button onClick={() => handleAnswer(false)} disabled={answer !== null}
          className="py-5 rounded-2xl font-black text-xl text-white transition-all hover:scale-[1.04] active:scale-[0.96] disabled:opacity-50"
          style={{ backgroundColor: K.pink }}>
          ❌ UNSAFE
        </button>
      </div>
    </div>
  );
}

// ─── Game 15: Emoji Safety Mood Check ────────────────────────────────────────

const MOOD_OPTIONS = [
  { emoji: '😊', label: 'Happy',   response: "That's wonderful! You deserve to feel happy and safe online. Keep doing what you're doing — you've got great online habits!" },
  { emoji: '😐', label: 'Okay',    response: "It's totally fine to feel just okay sometimes. If anything online is bothering you, it's always good to talk to a trusted adult." },
  { emoji: '😔', label: 'Sad',     response: "I'm sorry you're feeling sad. Remember: your feelings are real and they matter. You don't have to deal with online stuff alone — talk to someone you trust." },
  { emoji: '😰', label: 'Worried', response: "Feeling worried online is a sign that something might not be right. Trust your instincts! Tell a trusted adult what's making you worried — that's being really brave." },
  { emoji: '😤', label: 'Annoyed', response: "Something online has probably upset you — and that's understandable! The best move is to step away, take a few deep breaths, and talk to someone you trust about it." },
  { emoji: '😱', label: 'Scared',  response: "If something online is scaring you, tell a trusted adult RIGHT AWAY. You are never in trouble for reporting something that scares you. You are being incredibly brave." },
  { emoji: '🤩', label: 'Excited', response: "Wow, great energy! Just remember to stay safe while having fun — check with a trusted adult before trying anything new online." },
  { emoji: '😴', label: 'Tired',   response: "Screens can make us tired! Try taking a break from devices. Go outside, drink some water, and come back when you're refreshed." },
];

function MoodCheckGame() {
  const [selected, setSelected] = useState<number | null>(null);
  const [reset, setReset]       = useState(false);

  if (reset) return <MoodCheckGame />;

  return (
    <div className="p-6 space-y-5">
      <div className="text-center space-y-2">
        <p className="font-black text-lg" style={{ color: K.text }}>How does being online make you feel today?</p>
        <p className="text-sm font-semibold" style={{ color: K.muted }}>Tap the emoji that best matches your feelings</p>
      </div>

      <div className="grid grid-cols-4 gap-3">
        {MOOD_OPTIONS.map((m, i) => (
          <button key={i} onClick={() => setSelected(i)}
            className="flex flex-col items-center gap-1.5 p-3 rounded-2xl border transition-all hover:scale-[1.06]"
            style={{
              borderColor: selected === i ? K.teal : K.quizBtnBorder,
              backgroundColor: selected === i ? K.teal + '18' : K.quizBtn,
            }}>
            <span className={`text-3xl ${selected === i ? 'kids-star-pop' : ''}`}>{m.emoji}</span>
            <span className="text-xs font-black" style={{ color: selected === i ? K.teal : K.muted }}>{m.label}</span>
          </button>
        ))}
      </div>

      {selected !== null && (
        <div className="kids-slide-up rounded-2xl p-5 space-y-3"
          style={{ backgroundColor: K.teal + '12', border: `2px solid ${K.teal}44` }}>
          <div className="flex items-start gap-3">
            <span className="text-3xl shrink-0">{MOOD_OPTIONS[selected].emoji}</span>
            <p className="font-semibold text-sm leading-relaxed" style={{ color: K.text }}>
              {MOOD_OPTIONS[selected].response}
            </p>
          </div>
          <div className="flex gap-2">
            <button onClick={() => setReset(true)}
              className="flex-1 py-2 rounded-xl font-black text-sm border transition-all hover:scale-[1.02]"
              style={{ borderColor: K.teal, color: K.teal, backgroundColor: K.surface }}>
              Choose again
            </button>
          </div>
        </div>
      )}

      <div className="rounded-xl p-4 border text-sm font-semibold text-center"
        style={{ borderColor: K.pink + '44', backgroundColor: K.pink + '0A', color: K.muted }}>
        💚 Remember: Whatever you feel is valid. If you ever feel scared or unsafe, tell a trusted adult right away.
      </div>
    </div>
  );
}

// ─── Game 16: Build Your Digital Shield ──────────────────────────────────────

const SHIELD_HABITS = [
  { id: 'pw',      emoji: '🔑', text: 'I use a strong, unique password',                     piece: 'Left panel'    },
  { id: 'share',   emoji: '🤫', text: 'I never share personal info with strangers',           piece: 'Right panel'   },
  { id: 'adult',   emoji: '👨‍👧', text: 'I tell a trusted adult when something feels wrong',   piece: 'Top section'   },
  { id: 'think',   emoji: '🤔', text: 'I think before I post or share anything online',       piece: 'Bottom section' },
  { id: 'kind',    emoji: '💬', text: 'I am kind and respectful to others online',             piece: 'Center core'   },
  { id: 'logout',  emoji: '🚪', text: 'I log out of my accounts on shared computers',         piece: 'Shield border' },
  { id: 'report',  emoji: '🚨', text: 'I know how to block and report bad behaviour',          piece: 'Shield crest'  },
];

const SHIELD_COLORS = ['#5BC8C4', '#4A7FC1', '#5BCB8A', '#E8416E', '#F5D74E', '#A78BFA', '#F97316'];

function BuildShieldGame() {
  const [checked, setChecked] = useState<Set<string>>(new Set());
  const [celebrated, setCelebrated] = useState(false);
  const [showConfetti, setShowConfetti] = useState(false);

  const toggle = (id: string) => {
    const n = new Set(checked);
    if (n.has(id)) { n.delete(id); } else {
      n.add(id);
      if (n.size === SHIELD_HABITS.length && !celebrated) {
        setCelebrated(true); setShowConfetti(true);
        setTimeout(() => setShowConfetti(false), 1800);
      }
    }
    setChecked(n);
  };

  const pct = Math.round((checked.size / SHIELD_HABITS.length) * 100);

  return (
    <div className="p-6 space-y-5 relative overflow-hidden">
      {showConfetti && (
        <div className="pointer-events-none absolute inset-0 overflow-hidden z-20">
          {Array.from({ length: 24 }, (_, i) => (
            <div key={i} className="kids-confetti-piece"
              style={{ left: `${4 + i * 4}%`, top: '-16px', width: 10, height: 10,
                backgroundColor: SHIELD_COLORS[i % SHIELD_COLORS.length],
                borderRadius: i % 2 === 0 ? '50%' : '2px',
                animationDelay: `${i * 0.05}s` }} />
          ))}
        </div>
      )}

      {/* Shield visual */}
      <div className="flex flex-col items-center gap-3">
        <div className="relative w-36 h-40 flex items-center justify-center">
          {/* Shield shape */}
          <svg viewBox="0 0 120 140" className="absolute inset-0 w-full h-full">
            <path d="M60 5 L110 25 L110 75 Q110 120 60 135 Q10 120 10 75 L10 25 Z"
              fill={`url(#shieldGrad)`}
              stroke={checked.size === SHIELD_HABITS.length ? K.yellow : K.border}
              strokeWidth={checked.size === SHIELD_HABITS.length ? 3 : 2} />
            <defs>
              <linearGradient id="shieldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor={checked.size > 0 ? K.teal : K.border} />
                <stop offset="100%" stopColor={checked.size > 3 ? K.blue : checked.size > 0 ? K.teal + '99' : K.border} />
              </linearGradient>
            </defs>
          </svg>
          {/* Shield fill segments */}
          <div className="relative z-10 flex flex-col items-center gap-1">
            {Array.from({ length: Math.min(checked.size, SHIELD_HABITS.length) }, (_, i) => (
              <span key={i} className="text-lg kids-spin-in" style={{ animationDelay: `${i * 0.1}s` }}>
                {SHIELD_HABITS[i]?.emoji}
              </span>
            ))}
            {checked.size === 0 && <span className="text-2xl opacity-30">🛡️</span>}
          </div>
        </div>

        {/* Progress bar */}
        <div className="w-full space-y-1">
          <div className="flex justify-between text-xs font-bold" style={{ color: K.muted }}>
            <span>Shield strength</span>
            <span style={{ color: pct === 100 ? K.green : K.teal }}>{pct}%</span>
          </div>
          <div className="h-3 rounded-full overflow-hidden" style={{ backgroundColor: K.border }}>
            <div className="h-full rounded-full transition-all duration-500"
              style={{ width: `${pct}%`, backgroundColor: pct === 100 ? K.green : K.teal }} />
          </div>
        </div>
      </div>

      {celebrated && (
        <div className="kids-star-pop rounded-2xl p-4 text-center"
          style={{ backgroundColor: K.yellow + '33', border: `2px solid ${K.yellow}` }}>
          <p className="text-2xl">🏆✨🛡️</p>
          <p className="font-black text-sm mt-1" style={{ color: K.text }}>Your Digital Shield is FULLY POWERED! You&apos;re a Safety Champion!</p>
        </div>
      )}

      {/* Habit checklist */}
      <div className="space-y-2">
        {SHIELD_HABITS.map((h, i) => {
          const on = checked.has(h.id);
          return (
            <button key={h.id} onClick={() => toggle(h.id)}
              className="w-full flex items-center gap-3 p-3.5 rounded-2xl border text-left transition-all hover:scale-[1.01]"
              style={{ backgroundColor: on ? SHIELD_COLORS[i] + '14' : K.quizBtn,
                       borderColor: on ? SHIELD_COLORS[i] : K.border }}>
              <span className={`shrink-0 w-7 h-7 rounded-xl border flex items-center justify-center font-black
                transition-all ${on ? 'kids-star-pop' : ''}`}
                style={{ borderColor: on ? SHIELD_COLORS[i] : K.border,
                         backgroundColor: on ? SHIELD_COLORS[i] : 'transparent',
                         color: K.surface, fontSize: 13 }}>
                {on ? '✓' : ''}
              </span>
              <span className="text-lg shrink-0">{h.emoji}</span>
              <span className="font-bold text-sm" style={{ color: K.text }}>{h.text}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

// ─── Game 17: True or False Safety Quiz ──────────────────────────────────────

const TRUE_FALSE_QS = [
  { q: 'You should use the same password for all your accounts because it\'s easier to remember.',       ans: false, exp: 'Use a DIFFERENT password for every account. If one gets stolen, the others stay safe.' },
  { q: 'If someone is mean to you online, it counts as bullying even if they don\'t see you in person.', ans: true,  exp: 'Online bullying is just as real and serious as in-person bullying.' },
  { q: 'It is safe to share your home address with someone you only know from an online game.',          ans: false, exp: 'Never share your address, even with online friends — they are still strangers.' },
  { q: 'Logging out of your account on a shared computer helps protect your privacy.',                   ans: true,  exp: 'Always log out on shared devices so others cannot access your account.' },
  { q: 'A message saying "You\'ve won a free iPhone — click here!" is probably real.',                   ans: false, exp: 'Congratulations scams are very common. If it sounds too good to be true, it isn\'t real.' },
  { q: 'Adults can use screen time too — it\'s not just something kids have to manage.',                 ans: true,  exp: 'Screen time balance is important for everyone, not just children!' },
  { q: 'Putting a password on your device can help protect your personal information.',                  ans: true,  exp: 'A device password or PIN stops others accessing your information if it\'s lost.' },
  { q: 'Once you delete something from social media, it is completely gone forever.',                    ans: false, exp: 'Digital content can be saved, screenshotted, or cached — once shared it can be very hard to remove.' },
  { q: 'It is okay to share embarrassing photos of classmates online as a joke.',                        ans: false, exp: 'Sharing embarrassing photos without permission is hurtful and can count as cyberbullying.' },
  { q: 'Telling a trusted adult about something scary online is the brave thing to do.',                 ans: true,  exp: 'Absolutely! Asking for help is always the right and brave choice.' },
];

function TrueFalseGame() {
  const [idx, setIdx]       = useState(0);
  const [score, setScore]   = useState(0);
  const [answer, setAnswer] = useState<boolean | null>(null);
  const [done, setDone]     = useState(false);

  const handleAnswer = (val: boolean) => {
    const correct = val === TRUE_FALSE_QS[idx].ans;
    if (correct) setScore(s => s + 1);
    setAnswer(val);
    setTimeout(() => {
      const next = idx + 1;
      if (next >= TRUE_FALSE_QS.length) { setDone(true); return; }
      setIdx(next); setAnswer(null);
    }, 1500);
  };

  const reset = () => { setIdx(0); setScore(0); setAnswer(null); setDone(false); };

  if (done) return (
    <FinalScreen score={score} total={TRUE_FALSE_QS.length}
      msg={score >= 8 ? 'Outstanding! You really know your online safety facts!' : 'Well done — every question makes you smarter and safer!'}
      color={K.blue} onReplay={reset} />
  );

  const q = TRUE_FALSE_QS[idx];
  return (
    <div className="p-6 space-y-5">
      <div className="flex items-center justify-between">
        <ScoreBadge score={score} total={TRUE_FALSE_QS.length} />
        <span className="text-xs font-bold" style={{ color: K.muted }}>Q{idx + 1} of {TRUE_FALSE_QS.length}</span>
      </div>

      <div className="rounded-2xl p-5 min-h-[80px] flex items-center justify-center text-center"
        style={{ backgroundColor: K.blue + '0D', border: `2px solid ${K.blue}33` }}>
        <p className="font-bold text-base leading-snug" style={{ color: K.text }}>{q.q}</p>
      </div>

      {answer !== null && (
        <div className={`rounded-xl p-4 space-y-1 ${answer === q.ans ? 'kids-star-pop' : 'kids-shake'}`}
          style={{
            backgroundColor: answer === q.ans ? K.green + '18' : K.pink + '18',
            border: `2px solid ${answer === q.ans ? K.green : K.pink}`,
          }}>
          <p className="font-black text-sm" style={{ color: answer === q.ans ? K.green : K.pink }}>
            {answer === q.ans ? '✅ Correct!' : `❌ Actually, it's ${q.ans ? 'TRUE' : 'FALSE'}!`}
          </p>
          <p className="text-sm font-semibold" style={{ color: K.text }}>{q.exp}</p>
        </div>
      )}

      <div className="grid grid-cols-2 gap-4">
        <button onClick={() => handleAnswer(true)} disabled={answer !== null}
          className="py-5 rounded-2xl font-black text-xl text-white transition-all hover:scale-[1.04] disabled:opacity-50"
          style={{ backgroundColor: K.green }}>
          ✅ TRUE
        </button>
        <button onClick={() => handleAnswer(false)} disabled={answer !== null}
          className="py-5 rounded-2xl font-black text-xl text-white transition-all hover:scale-[1.04] disabled:opacity-50"
          style={{ backgroundColor: K.pink }}>
          ❌ FALSE
        </button>
      </div>
    </div>
  );
}

// ─── Game 18: Secret Code Creator (Caesar Cipher) ────────────────────────────

const CIPHER_MESSAGES = [
  'STAY SAFE ONLINE',
  'NEVER SHARE PASSWORDS',
  'BLOCK AND REPORT',
  'THINK BEFORE YOU POST',
  'ASK FOR HELP',
];

function shiftChar(c: string, shift: number): string {
  if (c >= 'A' && c <= 'Z') {
    return String.fromCharCode(((c.charCodeAt(0) - 65 + shift) % 26 + 26) % 26 + 65);
  }
  return c;
}

function applyShift(text: string, shift: number): string {
  return text.toUpperCase().split('').map(c => shiftChar(c, shift)).join('');
}

function SecretCodeGame() {
  const [mode, setMode]         = useState<'encode' | 'decode'>('encode');
  const [shift, setShift]       = useState(3);
  const [userText, setUserText] = useState('');
  const [preset, setPreset]     = useState(0);
  const [decoded, setDecoded]   = useState('');
  const [decodeInput, setDecodeInput] = useState('');
  const [decodeCorrect, setDecodeCorrect] = useState<boolean | null>(null);

  const encoded = applyShift(userText || CIPHER_MESSAGES[preset], shift);

  const checkDecode = () => {
    const expected = CIPHER_MESSAGES[preset];
    const clean = decodeInput.trim().toUpperCase().replace(/[^A-Z ]/g, '');
    setDecoded(clean);
    setDecodeCorrect(clean === expected);
  };

  return (
    <div className="p-6 space-y-5">
      {/* Mode tabs */}
      <div className="grid grid-cols-2 gap-2 p-1 rounded-2xl" style={{ backgroundColor: '#F1F5F9' }}>
        {(['encode', 'decode'] as const).map(m => (
          <button key={m} onClick={() => setMode(m)}
            className="py-2 rounded-xl font-black text-sm transition-all"
            style={{
              backgroundColor: mode === m ? K.surface : 'transparent',
              color: mode === m ? K.teal : K.muted,
              boxShadow: mode === m ? '0 1px 4px rgba(0,0,0,0.08)' : 'none',
            }}>
            {m === 'encode' ? '🔒 Encode' : '🔓 Decode'}
          </button>
        ))}
      </div>

      {/* Shift selector */}
      <div className="flex items-center gap-3 p-4 rounded-2xl" style={{ backgroundColor: K.teal + '10', border: `2px solid ${K.teal}33` }}>
        <span className="text-sm font-black" style={{ color: K.teal }}>Shift:</span>
        <input type="range" min={1} max={25} value={shift}
          onChange={e => setShift(Number(e.target.value))}
          className="flex-1 accent-current" style={{ accentColor: K.teal }} />
        <span className="font-black text-xl w-8 text-center" style={{ color: K.teal }}>{shift}</span>
      </div>

      {mode === 'encode' ? (
        <>
          <div>
            <p className="text-xs font-black mb-2 uppercase tracking-wider" style={{ color: K.muted }}>Or pick a safety phrase:</p>
            <div className="flex flex-wrap gap-2">
              {CIPHER_MESSAGES.map((m, i) => (
                <button key={i} onClick={() => { setPreset(i); setUserText(''); }}
                  className="text-xs px-3 py-1.5 rounded-xl font-bold border transition-all hover:scale-[1.03]"
                  style={{
                    borderColor: preset === i && !userText ? K.teal : K.quizBtnBorder,
                    backgroundColor: preset === i && !userText ? K.teal + '14' : K.quizBtn,
                    color: K.text,
                  }}>
                  {m}
                </button>
              ))}
            </div>
          </div>
          <div>
            <p className="text-xs font-black mb-1 uppercase tracking-wider" style={{ color: K.muted }}>Or type your own message:</p>
            <input value={userText} onChange={e => setUserText(e.target.value)}
              placeholder="Type a message..."
              className="w-full px-4 py-2.5 rounded-2xl border font-bold outline-none"
              style={{ borderColor: K.teal + '66', color: K.text }} />
          </div>
          <div className="rounded-2xl p-4 space-y-2" style={{ backgroundColor: K.blue + '0D', border: `2px solid ${K.blue}33` }}>
            <p className="text-xs font-black uppercase tracking-wider" style={{ color: K.blue }}>Original message:</p>
            <p className="font-black text-base tracking-widest" style={{ color: K.text }}>{(userText || CIPHER_MESSAGES[preset]).toUpperCase()}</p>
            <p className="text-xs font-black uppercase tracking-wider mt-3" style={{ color: K.teal }}>🔒 Encoded (shift {shift}):</p>
            <p className="font-black text-base tracking-widest kids-rainbow" style={{ color: K.teal }}>{encoded}</p>
          </div>
          <div className="text-xs font-semibold text-center rounded-xl p-3"
            style={{ backgroundColor: K.yellow + '22', border: `1px solid ${K.yellow}`, color: K.text }}>
            💡 A Caesar cipher shifts each letter by {shift} places in the alphabet. A → {applyShift('A', shift)}, B → {applyShift('B', shift)}, etc.
          </div>
        </>
      ) : (
        <>
          <div className="rounded-2xl p-4 space-y-1" style={{ backgroundColor: K.pink + '0D', border: `2px solid ${K.pink}33` }}>
            <p className="text-xs font-black uppercase tracking-wider" style={{ color: K.pink }}>Decode this message (shift {shift}):</p>
            <p className="font-black text-xl tracking-widest" style={{ color: K.text }}>
              {applyShift(CIPHER_MESSAGES[preset], shift)}
            </p>
          </div>
          <div className="flex gap-2">
            {CIPHER_MESSAGES.map((_, i) => (
              <button key={i} onClick={() => { setPreset(i); setDecodeInput(''); setDecoded(''); setDecodeCorrect(null); }}
                className="flex-1 py-2 rounded-xl font-black text-xs border transition-all"
                style={{ borderColor: preset === i ? K.pink : K.quizBtnBorder, backgroundColor: preset === i ? K.pink + '14' : K.quizBtn, color: K.text }}>
                #{i + 1}
              </button>
            ))}
          </div>
          <input value={decodeInput} onChange={e => { setDecodeInput(e.target.value); setDecodeCorrect(null); }}
            onKeyDown={e => e.key === 'Enter' && checkDecode()}
            placeholder="Type the decoded message..."
            className="w-full px-4 py-3 rounded-2xl border font-bold outline-none tracking-wider text-center uppercase"
            style={{ borderColor: K.pink + '66', color: K.text }} />
          {decodeCorrect !== null && (
            <div className={`rounded-xl p-3 text-center font-black text-sm ${decodeCorrect ? 'kids-star-pop' : 'kids-shake'}`}
              style={{ backgroundColor: decodeCorrect ? K.green + '22' : K.pink + '22',
                       border: `2px solid ${decodeCorrect ? K.green : K.pink}` }}>
              {decodeCorrect ? `🎉 Brilliant! The message was: ${CIPHER_MESSAGES[preset]}` : `❌ Not quite — keep trying! (Answer: ${CIPHER_MESSAGES[preset]})`}
            </div>
          )}
          <button onClick={checkDecode} disabled={!decodeInput.trim()}
            className="w-full py-3 rounded-2xl font-black text-white transition-all hover:scale-[1.02] disabled:opacity-40"
            style={{ backgroundColor: K.pink }}>
            🔓 Check Decoding
          </button>
        </>
      )}
    </div>
  );
}

// ─── Game 19: Safety Superhero Name Generator ─────────────────────────────────

const HERO_FIRST  = ['Cyber', 'Digital', 'Shield', 'Firewall', 'Pixel', 'Quantum', 'Binary', 'Techno', 'Neon', 'Turbo'];
const HERO_MIDDLE = ['Guard', 'Blaze', 'Storm', 'Nova', 'Spark', 'Force', 'Wave', 'Bolt', 'Flash', 'Star'];
const HERO_LAST   = ['Protector', 'Champion', 'Defender', 'Guardian', 'Warrior', 'Knight', 'Hero', 'Legend', 'Ranger', 'Commander'];
const HERO_POWERS = [
  'detect phishing emails in milliseconds',
  'build unbreakable passwords instantly',
  'spot fake news with X-ray vision',
  'block cyber threats with a force field',
  'encrypt messages with a single thought',
  'restore deleted files with a snap',
  'identify online strangers with super senses',
  'report cyberbullies at the speed of light',
];
const HERO_COLORS_BG = [K.teal, K.blue, K.pink, K.green, '#A78BFA', '#F97316'];

function HeroNameGame() {
  const [name, setName]   = useState('');
  const [colour, setColour] = useState(K.teal);
  const [power, setPower] = useState('');
  const [generated, setGenerated] = useState(false);

  const generate = () => {
    const r = (arr: string[]) => arr[Math.floor(Math.random() * arr.length)];
    setName(`${r(HERO_FIRST)} ${r(HERO_MIDDLE)} ${r(HERO_LAST)}`);
    setColour(HERO_COLORS_BG[Math.floor(Math.random() * HERO_COLORS_BG.length)]);
    setPower(HERO_POWERS[Math.floor(Math.random() * HERO_POWERS.length)]);
    setGenerated(true);
  };

  return (
    <div className="p-6 space-y-5">
      {generated ? (
        <div className="kids-spin-in space-y-4">
          <div className="rounded-2xl p-6 text-center space-y-3 text-white"
            style={{ background: `linear-gradient(135deg, ${colour} 0%, ${colour}CC 100%)` }}>
            <p className="text-5xl">🦸</p>
            <p className="font-black text-xs uppercase tracking-widest opacity-80">Your Safety Superhero Name is:</p>
            <p className="font-black text-2xl md:text-3xl text-balance">{name}</p>
            <p className="text-sm font-bold opacity-90">Superpower: {power}</p>
          </div>
          <p className="text-center text-sm font-bold" style={{ color: K.muted }}>
            Now that you have your hero name, go show the world what a safety superhero can do! 💪
          </p>
          <button onClick={generate}
            className="w-full py-3 rounded-2xl font-black text-white transition-all hover:scale-[1.02]"
            style={{ backgroundColor: colour }}>
            🎲 Generate Another Name!
          </button>
        </div>
      ) : (
        <div className="space-y-5">
          <div className="text-center space-y-2">
            <p className="text-5xl kids-bounce inline-block">🦸</p>
            <p className="font-black text-xl" style={{ color: K.text }}>Create Your Safety Superhero!</p>
            <p className="text-sm font-semibold text-pretty" style={{ color: K.muted }}>
              Every great online safety hero needs an epic name. Yours is waiting to be revealed!
            </p>
          </div>
          <div className="rounded-2xl p-5 space-y-3" style={{ backgroundColor: K.blue + '0D', border: `2px solid ${K.blue}22` }}>
            <p className="font-bold text-sm" style={{ color: K.text }}>Your name will be built from:</p>
            {[
              ['🔷', 'A powerful prefix', 'Cyber, Shield, Digital...'],
              ['⚡', 'An action word', 'Guard, Blaze, Storm...'],
              ['🏆', 'A heroic title', 'Protector, Champion, Knight...'],
            ].map(([emoji, label, examples]) => (
              <div key={label} className="flex items-center gap-3">
                <span className="text-xl">{emoji}</span>
                <div>
                  <p className="font-black text-sm" style={{ color: K.text }}>{label}</p>
                  <p className="text-xs font-semibold" style={{ color: K.muted }}>{examples}</p>
                </div>
              </div>
            ))}
          </div>
          <button onClick={generate}
            className="w-full py-4 rounded-2xl font-black text-white text-lg transition-all hover:scale-[1.03] kids-pulse-glow"
            style={{ backgroundColor: K.pink }}>
            🦸 Reveal My Hero Name!
          </button>
        </div>
      )}
    </div>
  );
}

// ─── Game 20: Safety Vocab Memory Match ──────────────────────────────────────

const VOCAB_PAIRS = [
  { id: 'pw',      emoji: '🔑', word: 'Password',   def: 'A secret word that unlocks your account' },
  { id: 'fw',      emoji: '🧱', word: 'Firewall',   def: 'Software that blocks unwanted connections' },
  { id: 'ph',      emoji: '🎣', word: 'Phishing',   def: 'Trick emails or messages to steal your info' },
  { id: 'pr',      emoji: '👁️', word: 'Privacy',    def: 'Keeping personal info hidden from others' },
  { id: 'ml',      emoji: '🦠', word: 'Malware',    def: 'Harmful software that damages your device' },
  { id: 'en',      emoji: '🔒', word: 'Encryption', def: 'Scrambling data so only you can read it' },
  { id: 'vp',      emoji: '🌐', word: 'VPN',        def: 'A tool that hides your internet location' },
  { id: 'cb',      emoji: '😤', word: 'Cyberbully', def: 'Someone who uses the internet to hurt others' },
];

interface MemCard { uid: string; id: string; type: 'word' | 'def'; emoji: string; text: string }

function buildVocabDeck(): MemCard[] {
  const cards: MemCard[] = VOCAB_PAIRS.flatMap(p => [
    { uid: `${p.id}-w`, id: p.id, type: 'word', emoji: p.emoji, text: p.word },
    { uid: `${p.id}-d`, id: p.id, type: 'def',  emoji: '❓',    text: p.def  },
  ]);
  for (let i = cards.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [cards[i], cards[j]] = [cards[j], cards[i]];
  }
  return cards;
}

function VocabMemoryGame() {
  const [deck, setDeck]       = useState<MemCard[]>(() => buildVocabDeck());
  const [flipped, setFlipped] = useState<string[]>([]);
  const [matched, setMatched] = useState<Set<string>>(new Set());
  const [moves, setMoves]     = useState(0);
  const [locked, setLocked]   = useState(false);

  const flip = (uid: string) => {
    if (locked || flipped.includes(uid) || matched.has(deck.find(c => c.uid === uid)!.id)) return;
    const next = [...flipped, uid];
    setFlipped(next);
    if (next.length === 2) {
      setMoves(m => m + 1);
      setLocked(true);
      const [a, b] = next.map(u => deck.find(c => c.uid === u)!);
      if (a.id === b.id) {
        setTimeout(() => {
          setMatched(s => new Set([...s, a.id]));
          setFlipped([]); setLocked(false);
        }, 600);
      } else {
        setTimeout(() => { setFlipped([]); setLocked(false); }, 1000);
      }
    }
  };

  const reset = () => { setDeck(buildVocabDeck()); setFlipped([]); setMatched(new Set()); setMoves(0); setLocked(false); };
  const done = matched.size === VOCAB_PAIRS.length;

  return (
    <div className="p-4 space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-xs font-black px-3 py-1 rounded-full border"
            style={{ borderColor: K.yellow, color: K.text, backgroundColor: K.yellow + '22' }}>
            Moves: {moves}
          </span>
          <span className="text-xs font-black px-3 py-1 rounded-full border"
            style={{ borderColor: K.green, color: K.text, backgroundColor: K.green + '22' }}>
            {matched.size}/{VOCAB_PAIRS.length} matched
          </span>
        </div>
        <ReplayBtn onReplay={reset} color={K.yellow} />
      </div>

      {done && (
        <div className="kids-star-pop rounded-2xl p-4 text-center"
          style={{ backgroundColor: K.green + '22', border: `2px solid ${K.green}` }}>
          <p className="text-3xl">🏆</p>
          <p className="font-black text-base mt-1" style={{ color: K.text }}>All pairs matched in {moves} moves! Outstanding!</p>
        </div>
      )}

      <div className="grid grid-cols-4 gap-2">
        {deck.map(card => {
          const isFlipped = flipped.includes(card.uid);
          const isMatched = matched.has(card.id);
          const show = isFlipped || isMatched;
          return (
            <button key={card.uid} onClick={() => flip(card.uid)}
              className="rounded-2xl border p-2 min-h-[64px] flex flex-col items-center justify-center gap-1 text-center transition-all hover:scale-[1.03]"
              style={{
                borderColor: isMatched ? K.green : isFlipped ? K.teal : K.border,
                backgroundColor: isMatched ? K.green + '18' : isFlipped ? K.teal + '12' : K.quizBtn,
              }}>
              {show ? (
                <>
                  <span className="text-lg">{card.emoji}</span>
                  <span className="text-[9px] font-black leading-tight" style={{ color: K.text }}>{card.text}</span>
                </>
              ) : (
                <span className="text-xl opacity-50">🛡️</span>
              )}
            </button>
          );
        })}
      </div>

      <p className="text-xs font-semibold text-center" style={{ color: K.muted }}>
        Match each safety word with its definition!
      </p>
    </div>
  );
}

// ─── Game 21: Safety Story Builder ───────────────────────────────────────────

interface StoryNode {
  id: string;
  text: string;
  emoji: string;
  choices?: { label: string; nextId: string; isGood: boolean }[];
  outcome?: { type: 'good' | 'bad' | 'ok'; message: string };
}

const STORY_TREE: StoryNode[] = [
  {
    id: 'start',
    emoji: '📱',
    text: 'You\'re playing your favourite online game when a message pops up from a username you don\'t recognise: "Hey! I\'m 11 too — wanna be friends? I can give you free gems if you tell me your name and school!"',
    choices: [
      { label: '💬 Tell them your name and school to get the gems', nextId: 'share_info',  isGood: false },
      { label: '🚫 Ignore the message and carry on playing',        nextId: 'ignore',      isGood: true  },
      { label: '👨‍👧 Tell a trusted adult about the message',          nextId: 'tell_adult1', isGood: true  },
    ],
  },
  {
    id: 'share_info', emoji: '😰',
    text: 'You shared your name and school. The stranger now sends more messages asking for your home address and wants to meet up. You feel really uncomfortable.',
    choices: [
      { label: '🏠 Share your address too', nextId: 'share_address', isGood: false },
      { label: '🚫 Block the stranger and tell a trusted adult', nextId: 'block_and_tell', isGood: true },
    ],
  },
  {
    id: 'share_address', emoji: '🚨',
    text: 'This is very dangerous! Sharing your address with strangers online puts you at serious risk.',
    outcome: { type: 'bad', message: 'Never share your address online. If this happens in real life, tell a trusted adult IMMEDIATELY. You won\'t be in trouble — the stranger is doing something wrong, not you.' },
  },
  {
    id: 'block_and_tell', emoji: '✅',
    text: 'You blocked the stranger and told your parent. Great choices!',
    outcome: { type: 'ok', message: 'Sharing some info was a mistake, but blocking and telling an adult was the RIGHT move. Next time, don\'t share any info with online strangers — not even your name!' },
  },
  {
    id: 'ignore', emoji: '🤔',
    text: 'You ignored the message. The stranger sends another one: "Why aren\'t you answering? I\'ll give you 1000 gems if you just tell me your school name, it\'s not a big deal!"',
    choices: [
      { label: '💬 It\'s just my school name — I\'ll tell them',   nextId: 'school_name',  isGood: false },
      { label: '🚫 Block the stranger',                             nextId: 'just_block',   isGood: true  },
      { label: '👨‍👧 Report the message to a trusted adult',          nextId: 'tell_adult2',  isGood: true  },
    ],
  },
  {
    id: 'school_name', emoji: '😬',
    text: 'The stranger now knows where you go to school. They keep messaging and it is making you feel uncomfortable.',
    choices: [
      { label: '🚫 Block and tell a trusted adult now', nextId: 'good_ending', isGood: true },
      { label: '💬 Keep chatting to be polite',         nextId: 'bad_ending2', isGood: false },
    ],
  },
  {
    id: 'just_block', emoji: '💪',
    text: 'You blocked the stranger without sharing anything.',
    outcome: { type: 'good', message: 'Excellent! Blocking strangers who ask for personal information is exactly the right thing to do. You trusted your instincts and kept yourself safe!' },
  },
  {
    id: 'tell_adult1', emoji: '🌟',
    text: 'You told a trusted adult right away. They helped you block the stranger and report the account.',
    outcome: { type: 'good', message: 'Perfect response! Telling a trusted adult immediately was exactly the right thing to do. You\'re a true Safety Superhero! 🦸' },
  },
  {
    id: 'tell_adult2', emoji: '🌟',
    text: 'A trusted adult helped you report and block the account. The game company was alerted too.',
    outcome: { type: 'good', message: 'Brilliant! Reporting the message means you might have protected other kids too. That\'s what being a Safety Superhero is all about! 🦸' },
  },
  {
    id: 'good_ending', emoji: '✅',
    text: 'You blocked the stranger and told a trusted adult. They helped you feel better.',
    outcome: { type: 'ok', message: 'You made a great recovery! Remember: it\'s NEVER too late to block, report, and tell a trusted adult. You were very brave.' },
  },
  {
    id: 'bad_ending2', emoji: '🚨',
    text: 'Continuing to chat with this stranger is not safe. This person is not who they say they are.',
    outcome: { type: 'bad', message: 'Polite does not mean unsafe. You are always allowed to stop talking to someone online who makes you uncomfortable. Tell a trusted adult right away!' },
  },
];

function StoryBuilderGame() {
  const [nodeId, setNodeId]   = useState('start');
  const [history, setHistory] = useState<string[]>([]);
  const [reset, setReset]     = useState(false);

  if (reset) return <StoryBuilderGame />;

  const node = STORY_TREE.find(n => n.id === nodeId)!;

  const choose = (nextId: string) => {
    setHistory(h => [...h, nodeId]);
    setNodeId(nextId);
  };

  const back = () => {
    if (!history.length) return;
    setNodeId(history[history.length - 1]);
    setHistory(h => h.slice(0, -1));
  };

  const outcomeColors = { good: K.green, ok: K.yellow, bad: K.pink };

  return (
    <div className="p-6 space-y-5">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-xl">{node.emoji}</span>
          <span className="text-xs font-black uppercase tracking-wider" style={{ color: K.muted }}>
            {node.outcome ? `Outcome` : `Scene ${history.length + 1}`}
          </span>
        </div>
        {history.length > 0 && (
          <button onClick={back}
            className="text-xs font-black px-3 py-1.5 rounded-xl border transition-all hover:scale-105"
            style={{ borderColor: K.border, color: K.muted }}>
            ← Back
          </button>
        )}
      </div>

      <div className="rounded-2xl p-5 leading-relaxed"
        style={{
          backgroundColor: node.outcome ? outcomeColors[node.outcome.type] + '12' : K.blue + '0D',
          border: `2px solid ${node.outcome ? outcomeColors[node.outcome.type] + '44' : K.blue + '22'}`,
        }}>
        <p className="font-semibold text-sm" style={{ color: K.text }}>{node.text}</p>
      </div>

      {node.outcome ? (
        <div className="space-y-3">
          <div className="rounded-2xl p-4 space-y-2"
            style={{ backgroundColor: outcomeColors[node.outcome.type] + '18',
                     border: `2px solid ${outcomeColors[node.outcome.type]}` }}>
            <p className="font-black text-sm"
              style={{ color: outcomeColors[node.outcome.type] }}>
              {node.outcome.type === 'good' ? '🌟 Great choices!' : node.outcome.type === 'ok' ? '💡 Good recovery!' : '⚠️ Important lesson:'}
            </p>
            <p className="text-sm font-semibold" style={{ color: K.text }}>{node.outcome.message}</p>
          </div>
          <button onClick={() => setReset(true)}
            className="w-full py-3 rounded-2xl font-black text-white transition-all hover:scale-[1.02]"
            style={{ backgroundColor: K.blue }}>
            🔄 Play Again with Different Choices
          </button>
        </div>
      ) : (
        <div className="space-y-2">
          <p className="text-xs font-black uppercase tracking-wider" style={{ color: K.muted }}>What would you do?</p>
          {node.choices?.map((c, i) => (
            <button key={i} onClick={() => choose(c.nextId)}
              className="w-full text-left p-4 rounded-2xl border font-bold text-sm transition-all hover:scale-[1.01]"
              style={{ borderColor: K.border, backgroundColor: K.surface, color: K.text }}>
              {c.label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── TYPE DEFINITIONS ────────────────────────────────────────────────────────


type GameId =
  | 'password' | 'phishing' | 'virussort' | 'twofa'
  | 'stranger' | 'overshare' | 'footprint' | 'privacy'
  | 'fakenews' | 'website' | 'screentime' | 'tone'
  | 'snake' | 'virusbuster' | 'surfer' | 'memory' | 'sprint' | 'decoder' | 'tower' | 'crossword'
  | 'scramble' | 'tapgame' | 'moodcheck' | 'shield' | 'trufalse' | 'cipher' | 'superhero' | 'storybuild' | 'vocabmem';

interface GameDef {
  id: GameId;
  emoji: string;
  title: string;
  tagline: string;
  category: 'cybersec' | 'safety' | 'literacy' | 'arcade' | 'activities';
  color: string;
}

const GAMES: GameDef[] = [
  // Cybersecurity
  { id: 'password',  emoji: '🔑', title: 'Password Strength',       tagline: 'Build unbreakable passwords',        category: 'cybersec',   color: K.teal   },
  { id: 'phishing',  emoji: '🎣', title: 'Spot the Phishing Email', tagline: 'Real email vs scam email',           category: 'cybersec',   color: K.pink   },
  { id: 'virussort', emoji: '🦠', title: 'Virus vs Safe File',      tagline: 'Sort the files — stay safe',        category: 'cybersec',   color: K.blue   },
  { id: 'twofa',     emoji: '🔐', title: '2FA: Double Lock',        tagline: 'Simulate two-factor auth',           category: 'cybersec',   color: K.teal   },
  // Cyber Safety
  { id: 'stranger',  emoji: '🚨', title: 'Stranger Danger Quiz',    tagline: 'Safe vs unsafe online contacts',    category: 'safety',     color: K.green  },
  { id: 'overshare', emoji: '📢', title: 'Oversharing Detector',    tagline: "What's safe to post online?",       category: 'safety',     color: K.yellow },
  { id: 'footprint', emoji: '👣', title: 'Digital Footprint Trail', tagline: 'See what you leave behind online',  category: 'safety',     color: K.blue   },
  { id: 'privacy',   emoji: '⚙️', title: 'Privacy Settings Sim',   tagline: 'Set up your account safely',         category: 'safety',     color: K.teal   },
  // Digital Literacy
  { id: 'fakenews',  emoji: '🗞️', title: 'Fake News Detector',      tagline: 'Real or fake headline?',            category: 'literacy',   color: K.green  },
  { id: 'website',   emoji: '🌐', title: 'Website Trustworthiness', tagline: 'Can you trust this site?',          category: 'literacy',   color: K.blue   },
  { id: 'screentime',emoji: '⏱️', title: 'Screen Time Balance',     tagline: 'Balance your digital day',          category: 'literacy',   color: K.green  },
  { id: 'tone',      emoji: '💬', title: 'Emoji Tone Interpreter',  tagline: 'What does this message really mean?',category: 'literacy',  color: K.pink   },
  // Arcade
  { id: 'snake',       emoji: '🐍', title: 'Firewall Snake',        tagline: 'Eat data packets, dodge viruses!',    category: 'arcade',   color: K.teal   },
  { id: 'virusbuster', emoji: '🔨', title: 'Virus Buster',          tagline: 'Whack the viruses before they escape',category: 'arcade',   color: K.pink   },
  { id: 'surfer',      emoji: '🏄', title: 'Safe Surfer',           tagline: 'Catch shields, dodge threats!',       category: 'arcade',   color: K.blue   },
  { id: 'memory',      emoji: '🃏', title: 'Cyber Memory Match',    tagline: 'Flip cards and find the pairs',       category: 'arcade',   color: K.yellow },
  { id: 'sprint',      emoji: '⌨️', title: 'Password Sprint',       tagline: 'Type cybersec phrases at top speed!', category: 'arcade',  color: K.green  },
  { id: 'decoder',     emoji: '🔓', title: 'Encryption Decoder',    tagline: 'Break the Caesar cipher!',            category: 'arcade',   color: K.teal   },
  { id: 'tower',       emoji: '🏰', title: 'Cyber Tower Defence',   tagline: 'Tap threats, protect your network!',  category: 'arcade',   color: K.pink   },
  { id: 'crossword',   emoji: '✏️', title: 'Cyber Crossword',       tagline: 'Fill the cybersec vocabulary grid!',  category: 'arcade',   color: K.blue   },
  // NEW: Interactive Activities
  { id: 'scramble',   emoji: '🔤', title: 'Word Scramble',          tagline: 'Unscramble safety vocab words!',      category: 'activities', color: K.teal   },
  { id: 'tapgame',    emoji: '👆', title: 'Safe or Unsafe?',        tagline: 'Tap fast — is this scenario safe?',   category: 'activities', color: K.green  },
  { id: 'moodcheck',  emoji: '😊', title: 'Emoji Mood Check',       tagline: 'How does online life make you feel?', category: 'activities', color: K.yellow },
  { id: 'shield',     emoji: '🛡️', title: 'Build Your Shield',      tagline: 'Check good habits, power up your shield!', category: 'activities', color: K.blue },
  { id: 'trufalse',   emoji: '❓', title: 'True or False Quiz',     tagline: 'Bust safety myths — 10 questions!',   category: 'activities', color: K.pink   },
  { id: 'cipher',     emoji: '🔒', title: 'Secret Code Creator',    tagline: 'Encode and decode secret messages!',  category: 'activities', color: K.teal   },
  { id: 'superhero',  emoji: '🦸', title: 'Safety Superhero Name',  tagline: 'Generate your hero identity!',        category: 'activities', color: K.pink   },
  { id: 'storybuild', emoji: '📖', title: 'Safety Story Builder',   tagline: 'Choose your own adventure online!',   category: 'activities', color: K.blue   },
  { id: 'vocabmem',   emoji: '🃏', title: 'Safety Vocab Match',     tagline: 'Match words to definitions!',         category: 'activities', color: K.green  },
];

const CATEGORIES = [
  { id: 'cybersec',   emoji: '🔒', label: 'Cybersecurity',    color: K.teal,   desc: 'Passwords, phishing, viruses & 2FA' },
  { id: 'safety',     emoji: '🛡️', label: 'Cyber Safety',     color: K.green,  desc: 'Strangers, sharing, footprints & privacy' },
  { id: 'literacy',   emoji: '📖', label: 'Digital Literacy',  color: K.blue,   desc: 'Fake news, websites & screen time' },
  { id: 'arcade',     emoji: '🕹️', label: 'Arcade Games',     color: K.yellow, desc: 'Snake, Buster, Surfer, Memory, Sprint, Decoder, Tower & Crossword' },
  { id: 'activities', emoji: '✨', label: 'New Activities',    color: K.pink,   desc: 'Scramble, Tap Game, Mood Check, Shield, Quiz, Cipher, Hero & Story!' },
] as const;

function GamePanel({ gameId, onBack }: { gameId: GameId; onBack: () => void }) {
  const def = GAMES.find(g => g.id === gameId)!;

  const renderGame = useCallback(() => {
    switch (gameId) {
      case 'password':   return <PasswordStrengthGame />;
      case 'phishing':   return <PhishingGame />;
      case 'virussort':  return <VirusSorterGame />;
      case 'twofa':      return <TwoFAGame />;
      case 'stranger':   return <StrangerDangerGame />;
      case 'overshare':  return <OversharingGame />;
      case 'footprint':  return <DigitalFootprintGame />;
      case 'privacy':    return <PrivacySimulatorGame />;
      case 'fakenews':   return <FakeNewsGame />;
      case 'website':    return <WebsiteCheckerGame />;
      case 'screentime': return <ScreenTimeGame />;
      case 'tone':       return <EmojiToneGame />;
      case 'snake':       return <FirewallSnakeGame />;
      case 'virusbuster': return <VirusBusterGame />;
      case 'surfer':      return <SafeSurferGame />;
      case 'memory':      return <CyberMemoryGame />;
      case 'sprint':      return <PasswordSprintGame />;
      case 'decoder':     return <EncryptionDecoderGame />;
      case 'tower':       return <CyberTowerDefenceGame />;
      case 'crossword':   return <CyberCrosswordGame />;
      // New activities
      case 'scramble':   return <WordScrambleGame />;
      case 'tapgame':    return <TapSafeGame />;
      case 'moodcheck':  return <MoodCheckGame />;
      case 'shield':     return <BuildShieldGame />;
      case 'trufalse':   return <TrueFalseGame />;
      case 'cipher':     return <SecretCodeGame />;
      case 'superhero':  return <HeroNameGame />;
      case 'storybuild': return <StoryBuilderGame />;
      case 'vocabmem':   return <VocabMemoryGame />;
    }
  }, [gameId]);

  return (
    <div className="space-y-4">
      <button onClick={onBack}
        className="flex items-center gap-2 text-sm font-black hover:scale-105 transition-all"
        style={{ color: K.muted }}>
        ← Back to Games
      </button>

      <div className="rounded-2xl border overflow-hidden " style={{ borderColor: def.color }}>
        <div className="px-6 py-4 flex items-center gap-3"
          style={{ backgroundColor: def.color + '18', borderBottom: `1px solid ${def.color}44` }}>
          <span className="text-4xl">{def.emoji}</span>
          <div>
            <h2 className="font-black text-xl" style={{ color: K.text }}>{def.title}</h2>
            <p className="text-sm font-semibold" style={{ color: K.muted }}>{def.tagline}</p>
          </div>
        </div>
        {renderGame()}
      </div>
    </div>
  );
}

type ActiveCat = 'cybersec' | 'safety' | 'literacy' | 'arcade' | 'activities';

export default function KidsGamesPage() {
  const [activeGame, setActiveGame] = useState<GameId | null>(null);
  const [activeCat, setActiveCat]   = useState<ActiveCat>('activities');

  if (activeGame) {
    return (
      <div className="max-w-3xl mx-auto">
        <GamePanel gameId={activeGame} onBack={() => setActiveGame(null)} />
      </div>
    );
  }

  const catGames = GAMES.filter(g => g.category === activeCat);
  const catDef   = CATEGORIES.find(c => c.id === activeCat)!;

  return (
    <div className="space-y-8 max-w-4xl mx-auto">
      {/* Hero */}
      <div className="text-center space-y-3 py-2">
        <div className="text-6xl inline-block kids-bounce">🎮</div>
        <h1 className="text-3xl md:text-5xl font-black text-balance" style={{ color: K.text }}>
          Games Hub
        </h1>
        <p className="text-sm md:text-base font-semibold text-pretty max-w-2xl mx-auto" style={{ color: K.muted }}>
          29 interactive games across 5 categories — from fast tap challenges and story adventures to full arcade games!
        </p>
        <div className="flex flex-wrap justify-center gap-2 text-sm font-black">
          {[
            ['✨', '9 new activities', K.pink  ],
            ['🕹️', '8 arcade games',   K.yellow],
            ['🏆', 'Score tracking',   K.teal  ],
            ['🔄', 'Unlimited replay', K.green ],
          ].map(([emoji, label, color]) => (
            <span key={label as string} className="px-3 py-1.5 rounded-full border"
              style={{ borderColor: (color as string) + '55', color: K.muted, backgroundColor: (color as string) + '0C' }}>
              {emoji} {label}
            </span>
          ))}
        </div>
      </div>

      {/* Category tabs */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
        {CATEGORIES.map(cat => (
          <button key={cat.id} onClick={() => setActiveCat(cat.id)}
            className="rounded-xl border p-3 md:p-4 text-left transition-all hover:scale-[1.02]"
            style={{
              borderColor: activeCat === cat.id ? cat.color + '88' : K.border,
              backgroundColor: activeCat === cat.id ? cat.color + '12' : K.surface,
            }}>
            <p className="text-2xl mb-1">{cat.emoji}</p>
            <p className="font-black text-sm" style={{ color: K.text }}>{cat.label}</p>
            <p className="text-xs font-semibold mt-0.5 hidden md:block leading-tight" style={{ color: K.muted }}>{cat.desc}</p>
          </button>
        ))}
      </div>

      {/* Games grid */}
      <div className="space-y-4">
        <div className="flex items-center gap-3">
          <span className="text-2xl">{catDef.emoji}</span>
          <div>
            <h2 className="font-black text-lg" style={{ color: K.text }}>{catDef.label}</h2>
            <p className="text-sm font-semibold" style={{ color: K.muted }}>{catDef.desc}</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {catGames.map(game => (
            <button key={game.id} onClick={() => setActiveGame(game.id)}
              className="text-left p-5 rounded-2xl border transition-all hover:scale-[1.02] kids-card-hover h-full"
              style={{ borderColor: game.color + '44', backgroundColor: game.color + '08' }}>
              <div className="flex items-start justify-between gap-2 mb-2">
                <span className="text-3xl">{game.emoji}</span>
                <span className="text-xs font-black rounded-full px-3 py-1 border shrink-0"
                  style={{ borderColor: game.color + '55', color: game.color, backgroundColor: game.color + '0C' }}>
                  Play →
                </span>
              </div>
              <p className="font-black text-sm md:text-base" style={{ color: K.text }}>{game.title}</p>
              <p className="text-sm font-semibold mt-1" style={{ color: K.muted }}>{game.tagline}</p>
            </button>
          ))}
        </div>
      </div>

      {/* All games index */}
      <div className="rounded-2xl border p-6 space-y-4" style={{ borderColor: K.border, backgroundColor: K.panel }}>
        <h2 className="font-black text-base text-center" style={{ color: K.text }}>🗂️ All 29 Games — Quick Launch</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
          {GAMES.map(game => (
            <button key={game.id} onClick={() => { setActiveCat(game.category as ActiveCat); setActiveGame(game.id); }}
              className="flex items-center gap-2 p-3 rounded-xl border text-left hover:scale-[1.01] transition-all"
              style={{ borderColor: game.color + '33', backgroundColor: game.color + '08' }}>
              <span className="text-lg shrink-0">{game.emoji}</span>
              <span className="font-bold text-xs min-w-0" style={{ color: K.text }}>{game.title}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
