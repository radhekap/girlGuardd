import { useState, useEffect, useCallback } from 'react';
import { CheckCircle, XCircle, RefreshCw, Star, Lock, AlertTriangle, Trophy, Newspaper, Palette } from 'lucide-react';
import { K } from '@/components/layouts/KidsLayout';

// ─── DATA ────────────────────────────────────────────────────────────────────

const safetyTopics = [
  { emoji: '🔐', label: 'Passwords',     color: K.teal  },
  { emoji: '🎣', label: 'Scams',         color: K.pink  },
  { emoji: '📰', label: 'Fake News',     color: K.blue  },
  { emoji: '🕵️', label: 'Privacy',       color: K.green },
  { emoji: '💬', label: 'Strangers',     color: K.yellow},
  { emoji: '📸', label: 'Sharing Photos',color: K.teal  },
];

const quizQuestions = [
  {
    q: 'Someone online says they\'ll give you FREE robux if you share your password. What should you do?',
    options: ['Share your password — free robux!', 'Ignore it and never share your password', 'Ask your friend if they think it\'s okay'],
    correct: 1,
    explain: 'Never share your password with ANYONE online — not even if they promise you something. Real games never ask for your password like this. It\'s a scam!',
  },
  {
    q: 'You see a news headline that says "BREAKING: School Cancelled Forever!!" What\'s the best thing to do?',
    options: ['Share it immediately with all your friends', 'Check with a trusted adult or official website first', 'Believe it because it says BREAKING'],
    correct: 1,
    explain: 'Fake news loves exciting words like "BREAKING!!". Always check with a trusted adult or official source before believing or sharing something.',
  },
  {
    q: 'A stranger in an online game asks for your real name, school, and where you live. You should:',
    options: ['Tell them — they seem really nice!', 'Only tell them your first name', 'Not share ANY personal info and tell a trusted adult'],
    correct: 2,
    explain: 'Never share your full name, school, address, or phone number with people you only know online. Real friends don\'t need this info to play games with you.',
  },
  {
    q: 'You get a message: "You WON a prize! Click this link NOW to claim it!" What is this?',
    options: ['A real prize — lucky you!', 'Probably a scam — don\'t click it!', 'A message from your school'],
    correct: 1,
    explain: 'This is a classic scam called "phishing." If you didn\'t enter a contest, you can\'t win one! Never click unknown links. Tell a grown-up instead.',
  },
  {
    q: 'Someone online says "keep our friendship a secret from your parents." This means:',
    options: ['They just want a special friendship', 'Something is wrong — safe people don\'t ask for secrets from grown-ups', 'It\'s totally normal to have secret friends'],
    correct: 1,
    explain: 'Safe adults never ask kids to keep secrets from their parents or guardians. If someone asks this, tell a trusted adult right away.',
  },
  {
    q: 'What makes a STRONG password?',
    options: ['Your name + birthday (e.g. emma2013)', 'A mix of letters, numbers & symbols (e.g. Sunny!Dog#7)', 'The word "password" — it\'s easy to remember'],
    correct: 1,
    explain: 'A strong password uses a mix of uppercase, lowercase, numbers, and symbols. Never use your name, birthday, or "password" as a password!',
  },
];

const scamOrSafeMessages = [
  { msg: '🎮 "Send me your Minecraft login and I\'ll give you diamonds!"', isScam: true,  explain: 'SCAM! Real games never need your login details. This person wants to steal your account.' },
  { msg: '📧 "Hi! It\'s your teacher Ms. Smith. Homework is due Friday 📚"', isScam: false, explain: 'This sounds like a normal message from a real teacher about homework.' },
  { msg: '💸 "You are the 1,000,000th visitor! Click HERE to claim $500 gift card!"', isScam: true, explain: 'SCAM! This is a fake prize trick. There\'s no gift card — they want your info.' },
  { msg: '🔔 "Hey, it\'s mum — can you check if your homework is done?"', isScam: false, explain: 'This sounds like a normal message from a family member.' },
  { msg: '😮 "I have embarrassing photos of you. Pay me or I\'ll share them."', isScam: true, explain: 'SCAM + DANGER! This is called sextortion. Never pay. Tell a trusted adult immediately.' },
  { msg: '🎟️ "Your account was locked. Verify by clicking here and entering your password."', isScam: true, explain: 'SCAM! This is phishing. Real companies never ask for passwords by message. Check with an adult.' },
];

const shareOrNotItems = [
  { item: '📛 Your full name',         safe: false, why: 'Your full name can help strangers find you in real life.' },
  { item: '🏠 Your home address',      safe: false, why: 'Never share where you live with people online!' },
  { item: '📸 A photo of your pet',    safe: true,  why: 'Generally okay! Just be careful about backgrounds that show your location.' },
  { item: '🏫 Your school name',       safe: false, why: 'Your school name can help strangers find you.' },
  { item: '🎨 Your favourite colour',  safe: true,  why: 'That\'s totally fine to share — it\'s just a fun fact about you!' },
  { item: '📱 Your phone number',      safe: false, why: 'Only share your phone number with real-life friends and family you trust.' },
  { item: '🎮 Your favourite game',    safe: true,  why: 'Sharing your favourite game is fine and a great way to connect!' },
  { item: '📍 Where you are right now',safe: false, why: 'Never tell strangers your location! It could be dangerous.' },
];

const fakeNewsClues = [
  { clue: '🚨 Uses ALL CAPS or lots of !!!!', isFakeSign: true },
  { clue: '✅ Written by a named journalist', isFakeSign: false },
  { clue: '😱 Makes you feel shocked or angry', isFakeSign: true },
  { clue: '🔗 From a real news site you know', isFakeSign: false },
  { clue: '🕵️ Hard to find anywhere else', isFakeSign: true },
  { clue: '📅 Has a real date and author', isFakeSign: false },
  { clue: '🤑 Asks you to share to win a prize', isFakeSign: true },
  { clue: '🌐 Multiple trusted sites confirm it', isFakeSign: false },
];

const passwordTips = [
  { tip: 'Use at least 8 characters', icon: '📏' },
  { tip: 'Mix uppercase AND lowercase letters', icon: '🔤' },
  { tip: 'Add numbers somewhere', icon: '🔢' },
  { tip: 'Use a special character like ! @ # $', icon: '✨' },
  { tip: 'Never use your name or birthday', icon: '🚫' },
  { tip: 'Don\'t use "password" or "1234"', icon: '❌' },
  { tip: 'Keep it secret — don\'t share with friends', icon: '🤫' },
  { tip: 'Use a different password for each account', icon: '🔑' },
];

// ─── MINI COMPONENTS ─────────────────────────────────────────────────────────

function SectionBadge({ emoji, label, color }: { emoji: string; label: string; color: string }) {
  return (
    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full font-bold text-sm" style={{ backgroundColor: color + '33', color: K.text }}>
      {emoji} {label}
    </span>
  );
}

function Card({ children, color, className = '' }: { children: React.ReactNode; color: string; className?: string }) {
  return (
    <div className={`rounded-2xl border ${className}`} style={{ borderColor: color + '44', backgroundColor: color + '0C' }}>
      {children}
    </div>
  );
}

// ─── GAME 1: Safety Quiz ─────────────────────────────────────────────────────

function SafetyQuiz({ onBadge }: { onBadge: () => void }) {
  const [idx, setIdx] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [done, setDone] = useState(false);
  const [badgeGiven, setBadgeGiven] = useState(false);

  const q = quizQuestions[idx];

  const choose = (i: number) => {
    if (selected !== null) return;
    setSelected(i);
    if (i === q.correct) setScore(s => s + 1);
  };

  const next = () => {
    if (idx + 1 >= quizQuestions.length) { setDone(true); return; }
    setIdx(i => i + 1);
    setSelected(null);
  };

  const restart = () => { setIdx(0); setSelected(null); setScore(0); setDone(false); };

  if (done) {
    const pct = Math.round((score / quizQuestions.length) * 100);
    if (pct >= 60 && !badgeGiven) { onBadge(); setBadgeGiven(true); }
    return (
      <div className="text-center space-y-4 p-6">
        <div className="text-6xl">{pct >= 80 ? '🏆' : pct >= 50 ? '⭐' : '💪'}</div>
        <p className="text-2xl font-black" style={{ color: K.text }}>
          You got {score}/{quizQuestions.length}!
        </p>
        <p className="font-bold" style={{ color: K.blue }}>
          {pct >= 80 ? 'Amazing! You\'re a real internet safety expert! 🎉' : pct >= 50 ? 'Great effort! Keep learning — you\'re doing well! 😊' : 'Good try! Review the tips and try again — you\'ve got this! 💪'}
        </p>
        <button
          onClick={restart}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-2xl font-black text-white transition-all hover:scale-105"
          style={{ backgroundColor: K.teal }}
        >
          <RefreshCw className="h-4 w-4" /> Play Again
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-4 p-6">
      <div className="flex items-center justify-between">
        <span className="text-sm font-bold" style={{ color: K.muted }}>Question {idx + 1} of {quizQuestions.length}</span>
        <span className="font-black text-sm px-3 py-1 rounded-full" style={{ backgroundColor: K.yellow, color: K.text }}>⭐ {score} pts</span>
      </div>
      {/* progress bar */}
      <div className="h-3 rounded-full overflow-hidden" style={{ backgroundColor: K.teal + '30' }}>
        <div className="h-full rounded-full transition-all duration-500" style={{ width: `${((idx) / quizQuestions.length) * 100}%`, backgroundColor: K.teal }} />
      </div>
      <p className="text-base font-black leading-snug" style={{ color: K.text }}>{q.q}</p>
      <div className="space-y-2">
        {q.options.map((opt, i) => {
          let bg = K.quizBtn, border = K.quizBtnBorder, textCol = K.text;
          if (selected !== null) {
            if (i === q.correct) { bg = K.green + '33'; border = K.green; }
            else if (i === selected && i !== q.correct) { bg = K.pink + '22'; border = K.pink; textCol = K.pink; }
          }
          return (
            <button
              key={i}
              onClick={() => choose(i)}
              className="w-full text-left px-4 py-3 rounded-2xl border font-bold text-sm transition-all hover:scale-[1.01]"
              style={{ backgroundColor: bg, borderColor: border, color: textCol }}
            >
              {selected !== null && i === q.correct && <CheckCircle className="inline h-4 w-4 mr-2" style={{ color: K.green }} />}
              {selected !== null && i === selected && i !== q.correct && <XCircle className="inline h-4 w-4 mr-2" style={{ color: K.pink }} />}
              {opt}
            </button>
          );
        })}
      </div>
      {selected !== null && (
        <div className="rounded-2xl p-3 text-sm font-semibold" style={{ backgroundColor: K.blue + '18', color: K.blue }}>
          💡 {q.explain}
        </div>
      )}
      {selected !== null && (
        <button
          onClick={next}
          className="w-full py-3 rounded-2xl font-black text-white transition-all hover:scale-[1.02]"
          style={{ backgroundColor: K.blue }}
        >
          {idx + 1 < quizQuestions.length ? 'Next Question →' : 'See My Score! 🏆'}
        </button>
      )}
    </div>
  );
}

// ─── GAME 2: Scam Detector ───────────────────────────────────────────────────

function ScamDetector({ onBadge }: { onBadge: () => void }) {
  const [idx, setIdx] = useState(0);
  const [revealed, setRevealed] = useState(false);
  const [score, setScore] = useState(0);
  const [done, setDone] = useState(false);
  const [choice, setChoice] = useState<boolean | null>(null);
  const [badgeGiven, setBadgeGiven] = useState(false);

  const item = scamOrSafeMessages[idx];

  const guess = (isScam: boolean) => {
    if (revealed) return;
    setChoice(isScam);
    setRevealed(true);
    if (isScam === item.isScam) setScore(s => s + 1);
  };

  const next = () => {
    if (idx + 1 >= scamOrSafeMessages.length) { setDone(true); return; }
    setIdx(i => i + 1);
    setRevealed(false);
    setChoice(null);
  };

  if (done) {
    if (score >= 4 && !badgeGiven) { onBadge(); setBadgeGiven(true); }
    return (
      <div className="text-center space-y-4 p-6">
        <div className="text-6xl">{score >= 5 ? '🕵️' : '🔍'}</div>
        <p className="text-2xl font-black" style={{ color: K.text }}>Scam Detective Score: {score}/{scamOrSafeMessages.length}</p>
        <p className="font-bold" style={{ color: K.pink }}>
          {score >= 5 ? 'You\'re a Scam Detector Master! 🏆' : 'Good try! Keep practising to spot scams faster 💪'}
        </p>
        <button onClick={() => { setIdx(0); setRevealed(false); setScore(0); setDone(false); setChoice(null); }}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-2xl font-black text-white hover:scale-105 transition-all"
          style={{ backgroundColor: K.pink }}>
          <RefreshCw className="h-4 w-4" /> Try Again
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-4 p-6">
      <div className="flex justify-between items-center">
        <span className="text-sm font-bold" style={{ color: K.muted }}>Message {idx + 1} of {scamOrSafeMessages.length}</span>
        <span className="font-black text-sm px-3 py-1 rounded-full" style={{ backgroundColor: K.pink + '22', color: K.pink }}>🕵️ {score} caught</span>
      </div>
      <div className="rounded-2xl p-5 border text-base font-bold leading-relaxed" style={{ backgroundColor: K.surface, borderColor: K.quizBtnBorder, color: K.text }}>
        {item.msg}
      </div>
      {!revealed ? (
        <div className="grid grid-cols-2 gap-3">
          <button onClick={() => guess(true)}
            className="py-4 rounded-2xl font-black text-white text-lg hover:scale-105 transition-all"
            style={{ backgroundColor: K.pink }}>
            🚨 SCAM!
          </button>
          <button onClick={() => guess(false)}
            className="py-4 rounded-2xl font-black text-white text-lg hover:scale-105 transition-all"
            style={{ backgroundColor: K.green }}>
            ✅ Safe
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          <div className="flex items-center gap-2 rounded-2xl px-4 py-3 font-black text-white"
            style={{ backgroundColor: item.isScam ? K.pink : K.green }}>
            {item.isScam ? <AlertTriangle className="h-5 w-5" /> : <CheckCircle className="h-5 w-5" />}
            {item.isScam ? '🚨 That was a SCAM!' : '✅ That was Safe!'}
            {choice === item.isScam ? ' — You got it! 🎉' : ' — Nice try, keep going!'}
          </div>
          <p className="text-sm font-semibold rounded-2xl p-3" style={{ backgroundColor: K.blue + '18', color: K.blue }}>{item.explain}</p>
          <button onClick={next}
            className="w-full py-3 rounded-2xl font-black text-white hover:scale-[1.02] transition-all"
            style={{ backgroundColor: K.blue }}>
            {idx + 1 < scamOrSafeMessages.length ? 'Next Message →' : 'See My Score! 🏆'}
          </button>
        </div>
      )}
    </div>
  );
}

// ─── GAME 3: Share or Not? ────────────────────────────────────────────────────

function ShareOrNot({ onBadge }: { onBadge: () => void }) {
  const [answers, setAnswers] = useState<Record<number, boolean>>({});
  const [revealed, setRevealed] = useState(false);
  const [badgeGiven, setBadgeGiven] = useState(false);

  const choose = (i: number, val: boolean) => {
    if (revealed) return;
    setAnswers(a => ({ ...a, [i]: val }));
  };

  const correctCount = shareOrNotItems.filter((item, i) => answers[i] === item.safe).length;

  const handleReveal = () => {
    setRevealed(true);
    if (correctCount >= 6 && !badgeGiven) { onBadge(); setBadgeGiven(true); }
  };

  return (
    <div className="space-y-4 p-4">
      <p className="font-bold text-sm text-center" style={{ color: K.muted }}>
        For each item, decide: is it okay to share online with someone you just met?
      </p>
      <div className="space-y-3">
        {shareOrNotItems.map((item, i) => {
          const chosen = answers[i];
          const correct_answer = item.safe;
          const isCorrect = revealed && chosen === correct_answer;
          const isWrong = revealed && chosen !== undefined && chosen !== correct_answer;
          return (
            <div key={i} className="rounded-2xl border overflow-hidden" style={{ borderColor: revealed ? (isCorrect ? K.green : isWrong ? K.pink : K.quizBtnBorder) : K.quizBtnBorder }}>
              <div className="flex items-center justify-between gap-3 p-3 flex-wrap" style={{ backgroundColor: K.surface }}>
                <span className="font-bold text-sm" style={{ color: K.text }}>{item.item}</span>
                <div className="flex gap-2 shrink-0">
                  <button
                    onClick={() => choose(i, true)}
                    className="px-3 py-1.5 rounded-xl font-bold text-sm transition-all"
                    style={{ backgroundColor: chosen === true ? K.green : K.green + '14', color: chosen === true ? K.surface : K.green }}
                  >✅ Share</button>
                  <button
                    onClick={() => choose(i, false)}
                    className="px-3 py-1.5 rounded-xl font-bold text-sm transition-all"
                    style={{ backgroundColor: chosen === false ? K.pink : K.pink + '14', color: chosen === false ? K.surface : K.pink }}
                  >🚫 Don't Share</button>
                </div>
              </div>
              {revealed && (
                <div className="px-3 py-2 text-xs font-semibold" style={{ backgroundColor: isCorrect ? K.green + '22' : K.pink + '18', color: isCorrect ? '#1A6B45' : K.pink }}>
                  {isCorrect ? '✅ Correct! ' : '❌ Oops! '}{item.why}
                </div>
              )}
            </div>
          );
        })}
      </div>
      {!revealed ? (
        <button
          disabled={Object.keys(answers).length < shareOrNotItems.length}
          onClick={handleReveal}
          className="w-full py-3 rounded-2xl font-black text-white transition-all hover:scale-[1.02] disabled:opacity-40"
          style={{ backgroundColor: K.teal }}
        >
          {Object.keys(answers).length < shareOrNotItems.length
            ? `Answer all ${shareOrNotItems.length - Object.keys(answers).length} more to check!`
            : 'Check My Answers! 🔍'}
        </button>
      ) : (
        <div className="text-center space-y-2 pt-2">
          <p className="text-xl font-black" style={{ color: K.text }}>You got {correctCount}/{shareOrNotItems.length} right! {correctCount >= 6 ? '🏆' : '💪'}</p>
          <button onClick={() => { setAnswers({}); setRevealed(false); }}
            className="inline-flex items-center gap-2 px-5 py-2 rounded-2xl font-black text-white hover:scale-105 transition-all"
            style={{ backgroundColor: K.teal }}>
            <RefreshCw className="h-4 w-4" /> Try Again
          </button>
        </div>
      )}
    </div>
  );
}

// ─── GAME 4: Fake News Section (Clue Checker + Headlines Game) ───────────────

const newsHeadlines = [
  { headline: '🌡️ "Scientists Confirm: Drinking Water Before Bed Cures All Diseases!"', real: false, explain: 'FAKE! No single thing cures all diseases. Watch out for miracle cure claims — they\'re almost always made up.' },
  { headline: '🐋 "Blue Whales Are the Largest Animals Ever to Live on Earth"', real: true, explain: 'TRUE! Blue whales are real giants — up to 30 metres long. This is a well-known scientific fact.' },
  { headline: '📱 "Government Will Shut Down the Internet on Saturday to \'Fix It\'"', real: false, explain: 'FAKE! No government can shut down the internet, and it doesn\'t need "fixing" like that. This is meant to scare you.' },
  { headline: '🏆 "Australia Wins Gold in Swimming at Olympic Games"', real: true, explain: 'TRUE! Australia has a strong history in Olympic swimming — this type of headline is very plausible and checkable.' },
  { headline: '🧠 "Scientists Find Humans Only Use 10% of Their Brains"', real: false, explain: 'FAKE! This is one of the most popular myths. Brain scans show we use virtually all of our brain.' },
  { headline: '🌍 "Global Average Temperature Rose Again Last Year, Say Climate Scientists"', real: true, explain: 'TRUE! Climate scientists worldwide confirm rising temperatures. This is backed by data from many independent sources.' },
  { headline: '🍕 "Eating Pizza Every Day Makes You Smarter, Study Shows"', real: false, explain: 'FAKE! No serious study says this. Headlines that say something weird will make you smarter are almost always wrong.' },
  { headline: '🦎 "Komodo Dragons Have Venom in Their Bite, Scientists Discovered"', real: true, explain: 'TRUE! Scientists found komodo dragons do have venom. It was a real discovery published in scientific journals.' },
];

function FakeNewsDetector({ onBadge }: { onBadge: () => void }) {
  const [checked, setChecked] = useState<Record<number, boolean>>({});
  const [badgeGiven, setBadgeGiven] = useState(false);

  const toggle = (i: number) => {
    setChecked(c => ({ ...c, [i]: !c[i] }));
    if (!badgeGiven) { onBadge(); setBadgeGiven(true); }
  };

  const redFlags = Object.entries(checked).filter(([i, v]) => v && fakeNewsClues[+i].isFakeSign).length;
  const goodSigns = Object.entries(checked).filter(([i, v]) => v && !fakeNewsClues[+i].isFakeSign).length;

  const verdict = () => {
    if (redFlags >= 3) return { emoji: '🚨', msg: 'Lots of red flags! This could be fake news. Check with a grown-up!', color: K.pink };
    if (goodSigns >= 3) return { emoji: '✅', msg: 'Many good signs! This might be reliable, but still double-check.', color: K.green };
    return { emoji: '🤔', msg: 'Keep checking more clues to be sure!', color: K.yellow };
  };
  const v = verdict();

  return (
    <div className="space-y-4 p-4">
      <p className="font-bold text-sm text-center" style={{ color: K.muted }}>
        Tick the things you notice about a news story or message to see if it might be fake:
      </p>
      <div className="grid md:grid-cols-2 gap-2">
        {fakeNewsClues.map((clue, i) => {
          const isChecked = !!checked[i];
          return (
            <button key={i} onClick={() => toggle(i)}
              className="flex items-center gap-2 p-3 rounded-2xl border text-left transition-all hover:scale-[1.02] font-semibold text-sm"
              style={{
                backgroundColor: isChecked ? (clue.isFakeSign ? K.pink + '22' : K.green + '22') : K.quizBtn,
                borderColor: isChecked ? (clue.isFakeSign ? K.pink : K.green) : K.quizBtnBorder,
                color: K.text,
              }}>
              <span className="shrink-0 w-5 h-5 rounded-md border flex items-center justify-center text-xs"
                style={{ borderColor: isChecked ? (clue.isFakeSign ? K.pink : K.green) : K.quizBtnBorder, backgroundColor: isChecked ? (clue.isFakeSign ? K.pink : K.green) : 'transparent', color: K.surface }}>
                {isChecked ? '✓' : ''}
              </span>
              {clue.clue}
            </button>
          );
        })}
      </div>
      {Object.keys(checked).length > 0 && (
        <div className="rounded-2xl p-4 text-center space-y-1 font-bold" style={{ backgroundColor: v.color + '22', border: `1px solid ${v.color}` }}>
          <p className="text-2xl">{v.emoji}</p>
          <p style={{ color: K.text }}>{v.msg}</p>
          {(redFlags > 0 || goodSigns > 0) && (
            <p className="text-sm font-semibold" style={{ color: K.muted }}>
              🚩 {redFlags} red flag{redFlags !== 1 ? 's' : ''} · ✅ {goodSigns} good sign{goodSigns !== 1 ? 's' : ''}
            </p>
          )}
        </div>
      )}
    </div>
  );
}

function NewsHeadlineGame({ onBadge }: { onBadge: () => void }) {
  const [idx, setIdx] = useState(0);
  const [revealed, setRevealed] = useState(false);
  const [choice, setChoice] = useState<boolean | null>(null);
  const [score, setScore] = useState(0);
  const [done, setDone] = useState(false);
  const [badgeGiven, setBadgeGiven] = useState(false);

  const item = newsHeadlines[idx];

  const guess = (isReal: boolean) => {
    if (revealed) return;
    setChoice(isReal);
    setRevealed(true);
    if (isReal === item.real) setScore(s => s + 1);
  };

  const next = () => {
    if (idx + 1 >= newsHeadlines.length) {
      setDone(true);
      if (!badgeGiven) { onBadge(); setBadgeGiven(true); }
      return;
    }
    setIdx(i => i + 1);
    setRevealed(false);
    setChoice(null);
  };

  const restart = () => { setIdx(0); setRevealed(false); setChoice(null); setScore(0); setDone(false); };

  if (done) {
    const pct = Math.round((score / newsHeadlines.length) * 100);
    return (
      <div className="text-center space-y-4 p-6">
        <div className="text-6xl">{pct >= 75 ? '🗞️🏆' : '🗞️'}</div>
        <p className="text-2xl font-black" style={{ color: K.text }}>News Detective Score: {score}/{newsHeadlines.length}!</p>
        <p className="font-bold" style={{ color: K.green }}>
          {pct >= 75 ? 'Incredible! You can spot fake news like a pro! 🌟' : pct >= 50 ? 'Good job! Keep practising your fake-news radar 👍' : 'Nice try! Fake news can fool anyone — keep learning! 💪'}
        </p>
        <button onClick={restart}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-2xl font-black text-white hover:scale-105 transition-all"
          style={{ backgroundColor: K.green }}>
          <RefreshCw className="h-4 w-4" /> Play Again
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-4 p-5">
      <div className="flex justify-between items-center">
        <span className="text-sm font-bold" style={{ color: K.muted }}>Headline {idx + 1} of {newsHeadlines.length}</span>
        <span className="font-black text-sm px-3 py-1 rounded-full" style={{ backgroundColor: K.green + '33', color: K.green }}>📰 {score} correct</span>
      </div>
      <div className="h-2.5 rounded-full overflow-hidden" style={{ backgroundColor: K.border }}>
        <div className="h-full rounded-full transition-all duration-500" style={{ width: `${(idx / newsHeadlines.length) * 100}%`, backgroundColor: K.green }} />
      </div>
      {/* Comic-style headline card */}
      <div className="rounded-2xl p-5 border text-center" style={{ backgroundColor: '#FFFDF0', borderColor: K.yellow }}>
        <Newspaper className="h-6 w-6 mx-auto mb-2" style={{ color: K.yellow }} />
        <p className="text-base md:text-lg font-black leading-snug" style={{ color: K.text }}>{item.headline}</p>
      </div>
      {!revealed ? (
        <div className="grid grid-cols-2 gap-3">
          <button onClick={() => guess(true)}
            className="py-5 rounded-2xl font-black text-white text-base hover:scale-105 transition-all flex flex-col items-center gap-1"
            style={{ backgroundColor: K.green }}>
            <span className="text-3xl">✅</span>
            <span>REAL!</span>
          </button>
          <button onClick={() => guess(false)}
            className="py-5 rounded-2xl font-black text-white text-base hover:scale-105 transition-all flex flex-col items-center gap-1"
            style={{ backgroundColor: K.pink }}>
            <span className="text-3xl">❌</span>
            <span>FAKE!</span>
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          <div className="flex items-center gap-2 rounded-2xl px-4 py-3 font-black text-white text-sm"
            style={{ backgroundColor: item.real ? K.green : K.pink }}>
            {item.real ? <CheckCircle className="h-5 w-5 shrink-0" /> : <XCircle className="h-5 w-5 shrink-0" />}
            {item.real ? '✅ That\'s REAL!' : '❌ That\'s FAKE!'}
            {choice === item.real ? ' — Nailed it! 🎉' : ' — Tricky one! Keep going 💪'}
          </div>
          <p className="text-sm font-semibold rounded-2xl p-3" style={{ backgroundColor: K.blue + '18', color: K.blue }}>💡 {item.explain}</p>
          <button onClick={next}
            className="w-full py-3 rounded-2xl font-black text-white hover:scale-[1.02] transition-all"
            style={{ backgroundColor: K.blue }}>
            {idx + 1 < newsHeadlines.length ? 'Next Headline →' : 'See My Score! 🏆'}
          </button>
        </div>
      )}
    </div>
  );
}

function FakeNewsTab({ onBadge }: { onBadge: (id: string) => void }) {
  const [sub, setSub] = useState<'checker' | 'headlines'>('headlines');
  return (
    <div>
      <div className="flex gap-2 p-3 border-b-2" style={{ borderColor: K.green + '44' }}>
        {([['headlines', '🗞️ Real or Fake?'], ['checker', '🔍 Clue Checker']] as const).map(([id, label]) => (
          <button key={id} onClick={() => setSub(id)}
            className="px-4 py-2 rounded-xl font-black text-sm transition-all hover:scale-105"
            style={{ backgroundColor: sub === id ? K.green : K.green + '14', color: sub === id ? K.surface : K.text }}>
            {label}
          </button>
        ))}
      </div>
      {sub === 'checker'  && <FakeNewsDetector onBadge={() => onBadge('fakenews-checker')} />}
      {sub === 'headlines' && <NewsHeadlineGame onBadge={() => onBadge('fakenews-headlines')} />}
    </div>
  );
}

// ─── GAME 5: Password Builder ─────────────────────────────────────────────────

function PasswordBuilder({ onBadge }: { onBadge: () => void }) {
  const [pw, setPw] = useState('');
  const [badgeGiven, setBadgeGiven] = useState(false);

  const hasUpper   = /[A-Z]/.test(pw);
  const hasLower   = /[a-z]/.test(pw);
  const hasNum     = /[0-9]/.test(pw);
  const hasSymbol  = /[!@#$%^&*]/.test(pw);
  const hasLength  = pw.length >= 8;
  const noName     = !/password|1234|qwerty/i.test(pw);

  const checks = [
    { label: '8+ characters',             pass: hasLength,  icon: '📏' },
    { label: 'Uppercase letter (A-Z)',     pass: hasUpper,   icon: '🔠' },
    { label: 'Lowercase letter (a-z)',     pass: hasLower,   icon: '🔡' },
    { label: 'A number (0-9)',             pass: hasNum,     icon: '🔢' },
    { label: 'A symbol (! @ # $ % & *)',  pass: hasSymbol,  icon: '✨' },
    { label: 'No obvious words',           pass: noName,     icon: '🚫' },
  ];
  const strength = checks.filter(c => c.pass).length;
  const strengthLabel = ['', 'Very Weak 😬', 'Weak 😕', 'Okay 🙂', 'Good 👍', 'Strong 💪', 'SUPER STRONG! 🏆'][strength];
  const strengthColor = [K.pink, K.pink, K.yellow, K.yellow, K.teal, K.green, K.green][strength];

  useEffect(() => {
    if (strength >= 5 && !badgeGiven) { onBadge(); setBadgeGiven(true); }
  }, [strength, badgeGiven, onBadge]);

  return (
    <div className="space-y-4 p-6">
      <p className="font-bold text-sm" style={{ color: K.muted }}>Type a practice password to test how strong it is (don't use a real password here!):</p>
      <div className="relative">
        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5" style={{ color: K.blue }} />
        <input
          type="text"
          placeholder="Type a practice password..."
          value={pw}
          onChange={e => setPw(e.target.value)}
          className="w-full pl-10 pr-4 py-3 rounded-2xl border font-bold text-base outline-none transition-all"
          style={{ borderColor: pw ? strengthColor : K.quizBtnBorder, color: K.text, fontFamily: 'monospace', backgroundColor: K.surface }}
        />
      </div>
      {pw && (
        <>
          <div className="flex items-center gap-3">
            <div className="flex-1 h-4 rounded-full overflow-hidden" style={{ backgroundColor: K.border }}>
              <div className="h-full rounded-full transition-all duration-500" style={{ width: `${(strength / 6) * 100}%`, backgroundColor: strengthColor }} />
            </div>
            <span className="font-black text-sm shrink-0" style={{ color: strengthColor }}>{strengthLabel}</span>
          </div>
          <div className="grid grid-cols-2 gap-2">
            {checks.map((c, i) => (
              <div key={i} className="flex items-center gap-2 rounded-xl p-2 text-xs font-bold"
                style={{ backgroundColor: c.pass ? K.green + '22' : K.pink + '15', color: c.pass ? '#1A6B45' : K.pink }}>
                <span>{c.icon}</span>
                {c.pass ? <CheckCircle className="h-3.5 w-3.5 shrink-0" /> : <XCircle className="h-3.5 w-3.5 shrink-0" />}
                {c.label}
              </div>
            ))}
          </div>
        </>
      )}
      {!pw && (
        <div className="space-y-2">
          <p className="text-sm font-black" style={{ color: K.text }}>A strong password should have:</p>
          {passwordTips.map((tip, i) => (
            <div key={i} className="flex items-center gap-2 text-sm font-semibold" style={{ color: K.text }}>
              <span>{tip.icon}</span> {tip.tip}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── GAME 6: Age-Level Learning ───────────────────────────────────────────────

const ageLevels = [
  {
    id: 'prek',
    emoji: '🌈',
    ageLabel: 'Ages 3–7',
    title: 'Little Explorers',
    color: K.yellow,
    bg: '#FFFDE7',
    badgeId: 'levels-prek',
    topics: [
      { icon: '⏰', title: 'Screen Time', comic: 'Too much screen time can make our eyes tired and brain fuzzy! Set a timer — when it beeps, time for a break!', rule: 'Rule: Ask a grown-up how long your screen time is today.' },
      { icon: '🖱️', title: 'Only Approved Icons', comic: 'Only click on pictures and apps your grown-up says are okay! If you see something new, STOP and ask first.', rule: 'Rule: Only click the apps grown-ups show you.' },
      { icon: '🛑', title: 'Stop & Ask!', comic: 'If ANYTHING on the screen surprises you, makes you feel weird, or you don\'t understand — STOP! Go find a grown-up right away.', rule: 'Rule: When in doubt — STOP and ask an adult!' },
    ],
  },
  {
    id: 'elem',
    emoji: '🔭',
    ageLabel: 'Ages 8–11',
    title: 'Junior Investigators',
    color: K.teal,
    bg: '#E0FAFA',
    badgeId: 'levels-elem',
    topics: [
      { icon: '🔒', title: 'Privacy Settings', comic: 'Your social profiles should be set to PRIVATE. That means only people you approve can see your posts. Ask a grown-up to check with you!', rule: 'Rule: Always use private mode on social apps.' },
      { icon: '👤', title: 'Online Strangers', comic: 'Someone online who seems nice might not be who they say they are. A 12-year-old online could actually be an adult. Never agree to meet someone you only know online!', rule: 'Rule: Never meet up with someone you only know online.' },
      { icon: '📛', title: 'Info = Power', comic: 'Your school name, suburb, or daily routine is like giving someone a map to find you. Sharing this info online is DANGEROUS, even with "friends."', rule: 'Rule: Never share your school, address, or routine online.' },
    ],
  },
  {
    id: 'middle',
    emoji: '🚀',
    ageLabel: 'Ages 12–14',
    title: 'Digital Navigators',
    color: K.blue,
    bg: '#EFF6FF',
    badgeId: 'levels-middle',
    topics: [
      { icon: '😤', title: 'Cyberbullying', comic: 'Cyberbullying is using technology to hurt, embarrass or exclude someone. Screenshots last forever. Block, report, and tell a trusted adult. You are NEVER alone.', rule: 'Rule: Block + report + tell. Don\'t stay silent.' },
      { icon: '📱', title: 'Social Media Privacy', comic: 'Read your privacy settings — who can see your stories? Your location? Turn off location sharing in apps. Review friend lists. You control who sees your life!', rule: 'Rule: Review your privacy settings every few months.' },
      { icon: '🎮', title: 'Gaming Scams', comic: '"Free V-Bucks" offers, trading scams, and "pro" players asking for your login are all tricks. Real game companies NEVER ask for your password through chat.', rule: 'Rule: Anything "free" in gaming that needs your info is a scam.' },
      { icon: '👣', title: 'Digital Footprint', comic: 'EVERY post, comment, photo, and like is saved forever — even after deletion. Future schools, jobs, and coaches may see it. Think: "Would I show this to my nan?"', rule: 'Rule: Post as if it will exist forever — because it will.' },
    ],
  },
];

function AgeLevels({ onBadge }: { onBadge: (id: string) => void }) {
  const [active, setActive] = useState<string>('prek');
  const [flipped, setFlipped] = useState<Record<string, boolean>>({});
  const [earned, setEarned] = useState<Record<string, boolean>>({});

  const level = ageLevels.find(l => l.id === active)!;

  const flipCard = (key: string, badgeId: string) => {
    const next = { ...flipped, [key]: !flipped[key] };
    setFlipped(next);
    // earn badge when all cards in the level are flipped
    const allFlipped = level.topics.every((_, i) => next[`${active}-${i}`]);
    if (allFlipped && !earned[active]) {
      onBadge(badgeId);
      setEarned(e => ({ ...e, [active]: true }));
    }
  };

  return (
    <div className="p-4 space-y-5">
      {/* Age selector */}
      <div className="grid grid-cols-3 gap-2">
        {ageLevels.map(lvl => (
          <button key={lvl.id} onClick={() => setActive(lvl.id)}
            className="py-3 rounded-2xl font-black text-sm transition-all hover:scale-105 flex flex-col items-center gap-1"
            style={{ backgroundColor: active === lvl.id ? lvl.color : lvl.color + '22', color: active === lvl.id ? (lvl.id === 'prek' ? K.text : K.surface) : K.text, border: `1px solid ${lvl.color}55` }}>
            <span className="text-2xl">{lvl.emoji}</span>
            <span>{lvl.ageLabel}</span>
          </button>
        ))}
      </div>

      <div className="text-center">
        <span className="text-2xl font-black" style={{ color: K.text }}>{level.emoji} {level.title}</span>
        <p className="text-sm font-semibold mt-1" style={{ color: K.muted }}>Tap each card to reveal the safety tip!</p>
      </div>

      <div className="grid md:grid-cols-2 gap-3">
        {level.topics.map((topic, i) => {
          const key = `${active}-${i}`;
          const isFlipped = !!flipped[key];
          return (
            <button key={key} onClick={() => flipCard(key, level.badgeId)}
              className="text-left rounded-2xl border overflow-hidden transition-all hover:scale-[1.02] w-full"
              style={{ borderColor: level.color }}>
              {!isFlipped ? (
                <div className="p-5 flex flex-col items-center gap-3 min-h-[120px] justify-center"
                  style={{ backgroundColor: level.bg }}>
                  <span className="text-4xl">{topic.icon}</span>
                  <span className="font-black text-base" style={{ color: K.text }}>{topic.title}</span>
                  <span className="text-xs font-bold rounded-full px-3 py-1" style={{ backgroundColor: level.color + '33', color: K.muted }}>Tap to learn! 👆</span>
                </div>
              ) : (
                <div className="p-4 space-y-2 min-h-[120px]" style={{ backgroundColor: level.color + '22' }}>
                  <div className="flex items-center gap-2 font-black" style={{ color: K.text }}>
                    <span className="text-xl">{topic.icon}</span>{topic.title}
                  </div>
                  <p className="text-sm font-semibold leading-relaxed" style={{ color: K.text }}>{topic.comic}</p>
                  <div className="rounded-xl px-3 py-2 text-xs font-black" style={{ backgroundColor: level.color, color: lvl_text_color(level.id) }}>
                    {topic.rule}
                  </div>
                </div>
              )}
            </button>
          );
        })}
      </div>
      {earned[active] && (
        <div className="text-center rounded-2xl py-3 font-black" style={{ backgroundColor: level.color + '33', color: K.text }}>
          🏅 You earned the {level.title} badge! Go check your Badges tab!
        </div>
      )}
    </div>
  );
}

function lvl_text_color(id: string) {
  return id === 'prek' ? K.text : K.surface;
}

// ─── GAME 7: Avatar Builder ───────────────────────────────────────────────────

const hairStyles  = ['👩', '👧', '🧒', '👱‍♀️', '🧑', '👩‍🦱', '👩‍🦰', '👩‍🦳'];
const accessories = ['😎', '🎩', '👒', '🎓', '👑', '🎀', '🌸', '⭐'];
const backgrounds = [
  { label: '🌈', color: 'linear-gradient(135deg, #FFB3BA, #FFDDB3)' },
  { label: '🌊', color: 'linear-gradient(135deg, #A8EDEA, #72D0D0)' },
  { label: '🌿', color: 'linear-gradient(135deg, #B5EAD7, #78D6B0)' },
  { label: '🌙', color: 'linear-gradient(135deg, #C3B1E1, #8B6EC7)' },
  { label: '☀️', color: 'linear-gradient(135deg, #FFF3A3, #FFD700)' },
  { label: '🍓', color: 'linear-gradient(135deg, #FFB3C1, #E8416E)' },
];
const moodEmojis  = ['😊', '😄', '😎', '🤩', '😜', '🥳', '🤗', '😇'];

function AvatarBuilder({ onBadge }: { onBadge: () => void }) {
  const [hair,  setHair]  = useState(0);
  const [acc,   setAcc]   = useState(0);
  const [bg,    setBg]    = useState(0);
  const [mood,  setMood]  = useState(0);
  const [saved, setSaved] = useState(false);

  const save = () => {
    setSaved(true);
    onBadge();
  };

  return (
    <div className="p-5 space-y-5">
      <p className="text-center font-bold text-sm" style={{ color: K.muted }}>
        Build your safe online avatar — no real face, no real name! 🎨
      </p>

      {/* Preview */}
      <div className="flex justify-center">
        <div className="relative w-36 h-36 rounded-full flex items-center justify-center shadow-lg border-[4px]"
          style={{ background: backgrounds[bg].color, borderColor: K.teal }}>
          <div className="flex flex-col items-center">
            <span className="text-5xl leading-none">{hairStyles[hair]}</span>
          </div>
          <span className="absolute -bottom-2 -right-2 text-3xl">{accessories[acc]}</span>
          <span className="absolute -top-2 -left-2 text-2xl">{moodEmojis[mood]}</span>
        </div>
      </div>

      {/* Controls */}
      <div className="space-y-4">
        {[
          { label: '💇 Character', items: hairStyles, val: hair, set: setHair, color: K.teal },
          { label: '✨ Accessory', items: accessories, val: acc,  set: setAcc,  color: K.pink },
          { label: '😊 Mood',      items: moodEmojis,  val: mood, set: setMood, color: K.blue },
        ].map(({ label, items, val, set, color }) => (
          <div key={label}>
            <p className="text-xs font-black mb-2" style={{ color: K.muted }}>{label}</p>
            <div className="flex flex-wrap gap-2">
              {items.map((item, i) => (
                <button key={i} onClick={() => set(i)}
                  className="w-10 h-10 rounded-xl text-xl flex items-center justify-center transition-all hover:scale-110 border"
                  style={{ backgroundColor: val === i ? color + '18' : K.quizBtn, borderColor: val === i ? color : K.quizBtnBorder }}>
                  {item}
                </button>
              ))}
            </div>
          </div>
        ))}

        <div>
          <p className="text-xs font-black mb-2" style={{ color: K.muted }}>🌈 Background</p>
          <div className="flex gap-2 flex-wrap">
            {backgrounds.map((b, i) => (
              <button key={i} onClick={() => setBg(i)}
                className="w-10 h-10 rounded-xl text-xl flex items-center justify-center border transition-all hover:scale-110"
                style={{ background: b.color, borderColor: bg === i ? K.text : 'transparent' }}>
                {b.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {!saved ? (
        <button onClick={save}
          className="w-full py-3 rounded-2xl font-black text-white hover:scale-[1.02] transition-all flex items-center justify-center gap-2"
          style={{ backgroundColor: K.pink }}>
          <Palette className="h-5 w-5" /> Save My Avatar & Earn a Badge! 🏅
        </button>
      ) : (
        <div className="rounded-2xl p-4 text-center space-y-1" style={{ backgroundColor: K.green + '22', border: `1px solid ${K.green}` }}>
          <p className="text-2xl">🎉</p>
          <p className="font-black" style={{ color: K.text }}>Avatar saved! Remember: never use your real photo online.</p>
          <p className="text-sm font-semibold" style={{ color: K.green }}>Badge unlocked: Avatar Artist! 🎨</p>
        </div>
      )}
    </div>
  );
}

// ─── BADGES PANEL ──────────────────────────────────────────────────────────────

const ALL_BADGES: { id: string; emoji: string; title: string; desc: string; color: string }[] = [
  { id: 'quiz',              emoji: '🧠', title: 'Quiz Master',        desc: 'Scored 60%+ on the Safety Quiz',        color: K.blue  },
  { id: 'scam',              emoji: '🕵️', title: 'Scam Buster',        desc: 'Caught 4+ scams in Scam Detector',      color: K.pink  },
  { id: 'share',             emoji: '🛡️', title: 'Privacy Pro',        desc: 'Got 6+ right in Share or Not?',         color: K.teal  },
  { id: 'fakenews-headlines',emoji: '🗞️', title: 'News Detective',     desc: 'Finished the Real or Fake? game',       color: K.green },
  { id: 'fakenews-checker',  emoji: '🔍', title: 'Clue Hunter',        desc: 'Used the Fake News Clue Checker',       color: K.green },
  { id: 'password',          emoji: '🔐', title: 'Password Ninja',     desc: 'Built a super strong password',         color: K.yellow},
  { id: 'levels-prek',       emoji: '🌈', title: 'Little Explorer',    desc: 'Completed the Ages 3–7 level cards',   color: K.yellow},
  { id: 'levels-elem',       emoji: '🔭', title: 'Junior Investigator',desc: 'Completed the Ages 8–11 level cards',  color: K.teal  },
  { id: 'levels-middle',     emoji: '🚀', title: 'Digital Navigator',  desc: 'Completed the Ages 12–14 level cards', color: K.blue  },
  { id: 'avatar',            emoji: '🎨', title: 'Avatar Artist',      desc: 'Created and saved your avatar',         color: K.pink  },
];

const RANKS = [
  { min: 0,  label: '🌱 Safety Seedling',  color: K.green  },
  { min: 2,  label: '⭐ Safety Star',       color: K.yellow },
  { min: 5,  label: '🛡️ Safety Guardian',  color: K.teal   },
  { min: 8,  label: '🏆 Safety Champion',  color: K.blue   },
  { min: 10, label: '👑 Safety Legend',    color: K.pink   },
];

function BadgesPanel({ earned }: { earned: Set<string> }) {
  const count   = earned.size;
  const rank    = [...RANKS].reverse().find(r => count >= r.min) ?? RANKS[0];
  const next    = RANKS.find(r => r.min > count);
  const pct     = next ? Math.round((count / next.min) * 100) : 100;

  return (
    <div className="p-5 space-y-5">
      {/* Rank card */}
      <div className="rounded-2xl p-5 text-center space-y-2 border"
        style={{ borderColor: rank.color, backgroundColor: rank.color + '18' }}>
        <div className="text-4xl font-black">{rank.label}</div>
        <p className="font-bold text-sm" style={{ color: K.muted }}>
          {count}/{ALL_BADGES.length} badges earned
        </p>
        <div className="h-4 rounded-full overflow-hidden mx-auto max-w-xs" style={{ backgroundColor: K.border }}>
          <div className="h-full rounded-full transition-all duration-700"
            style={{ width: `${pct}%`, backgroundColor: rank.color }} />
        </div>
        {next && (
          <p className="text-xs font-bold" style={{ color: K.muted }}>
            {next.min - count} more badge{next.min - count !== 1 ? 's' : ''} to reach the next rank!
          </p>
        )}
      </div>

      {/* Badge grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        {ALL_BADGES.map(badge => {
          const has = earned.has(badge.id);
          return (
            <div key={badge.id}
              className="rounded-2xl p-3 text-center border space-y-1 transition-all"
              style={{
                borderColor: has ? badge.color : K.border,
                backgroundColor: has ? badge.color + '14' : K.quizBtn,
                opacity: has ? 1 : 0.55,
              }}>
              <div className="text-3xl">{has ? badge.emoji : '🔒'}</div>
              <p className="text-xs font-black" style={{ color: has ? K.text : K.muted }}>{badge.title}</p>
              <p className="text-xs font-semibold" style={{ color: K.muted }}>{badge.desc}</p>
            </div>
          );
        })}
      </div>

      {count === 0 && (
        <p className="text-center text-sm font-bold" style={{ color: K.muted }}>
          🎮 Complete the activities to earn badges!
        </p>
      )}
    </div>
  );
}

// ─── MAIN PAGE ────────────────────────────────────────────────────────────────

const BADGE_STORAGE_KEY = 'girlguard-kids-badges';

type Tab = 'quiz' | 'scam' | 'share' | 'fakenews' | 'password' | 'levels' | 'avatar' | 'badges';

const tabs: { id: Tab; emoji: string; label: string; color: string }[] = [
  { id: 'quiz',     emoji: '🧠', label: 'Safety Quiz',    color: K.blue   },
  { id: 'scam',     emoji: '🕵️', label: 'Scam Detector',  color: K.pink   },
  { id: 'share',    emoji: '🛡️', label: 'Share or Not?',  color: K.teal   },
  { id: 'fakenews', emoji: '📰', label: 'Fake News',      color: K.green  },
  { id: 'password', emoji: '🔐', label: 'Passwords',      color: K.yellow },
  { id: 'levels',   emoji: '📚', label: 'My Age Level',   color: '#9B59B6' },
  { id: 'avatar',   emoji: '🎨', label: 'Avatar Builder', color: K.pink   },
  { id: 'badges',   emoji: '🏅', label: 'My Badges',      color: K.blue   },
];

export default function KidsSafeOnlinePage() {
  const [activeTab, setActiveTab] = useState<Tab>('quiz');
  const [earnedBadges, setEarnedBadges] = useState<Set<string>>(() => {
    try {
      const stored = localStorage.getItem(BADGE_STORAGE_KEY);
      return stored ? new Set(JSON.parse(stored)) : new Set();
    } catch { return new Set(); }
  });
  const [newBadge, setNewBadge] = useState<string | null>(null);

  const awardBadge = useCallback((id: string) => {
    setEarnedBadges(prev => {
      if (prev.has(id)) return prev;
      const next = new Set(prev);
      next.add(id);
      try { localStorage.setItem(BADGE_STORAGE_KEY, JSON.stringify([...next])); } catch { /* ignore */ }
      return next;
    });
    const badge = ALL_BADGES.find(b => b.id === id);
    if (badge) {
      setNewBadge(badge.title);
      setTimeout(() => setNewBadge(null), 3000);
    }
  }, []);

  const activeTabDef = tabs.find(t => t.id === activeTab)!;

  return (
    <div className="space-y-8 max-w-4xl mx-auto">
      {/* Badge toast */}
      {newBadge && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 rounded-2xl px-5 py-3 font-black text-white shadow-xl flex items-center gap-2 transition-all"
          style={{ backgroundColor: K.teal }}>
          <Trophy className="h-5 w-5" />
          🏅 Badge unlocked: {newBadge}!
        </div>
      )}

      {/* Hero */}
      <div className="text-center space-y-4">
        <div className="text-6xl kids-bounce inline-block">🌐</div>
        <h1 className="text-3xl md:text-5xl font-black text-balance" style={{ color: K.text }}>
          Stay Safe Online
        </h1>
        <p className="text-base md:text-lg font-semibold text-pretty max-w-2xl mx-auto" style={{ color: K.muted }}>
          Games, activities and challenges for every age — collect badges as you go! 🎮
        </p>

        {/* Badge counter */}
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full font-black border"
          style={{ backgroundColor: K.yellow + '14', color: K.text, borderColor: K.yellow + '55' }}>
          <Trophy style={{ width: 14, height: 14 }} />
          {earnedBadges.size}/{ALL_BADGES.length} badges earned
          {earnedBadges.size > 0 && (
            <button onClick={() => setActiveTab('badges')}
              className="ml-1 text-xs underline font-bold" style={{ color: K.blue }}>
              View
            </button>
          )}
        </div>
      </div>

      {/* Quick tip strip */}
      <div className="rounded-2xl px-5 py-3 flex flex-wrap gap-x-4 gap-y-2 justify-center" style={{ backgroundColor: K.teal + '0C', border: `1px solid ${K.teal}44` }}>
        <span className="text-sm font-bold" style={{ color: K.text }}>⚡ Quick Rules:</span>
        {['Never share your password', 'Check before you click', 'Tell a grown-up if unsure', 'Think before you post'].map(t => (
          <span key={t} className="text-sm font-semibold" style={{ color: K.muted }}>· {t}</span>
        ))}
      </div>

      {/* Activity Hub */}
      <div className="space-y-4">
        <div className="text-center">
          <h2 className="text-xl font-black" style={{ color: K.text }}>🎮 Activity Hub</h2>
          <p className="text-sm font-semibold mt-1" style={{ color: K.muted }}>Pick an activity, earn badges, level up!</p>
        </div>

        {/* Tab grid — two rows, mobile friendly */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
          {tabs.map(tab => {
            const hasBadge = tab.id === 'badges' && earnedBadges.size > 0;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className="relative px-3 py-3 rounded-xl font-black text-sm transition-all hover:scale-105 flex flex-col items-center gap-1"
                style={{
                  backgroundColor: activeTab === tab.id ? tab.color : tab.color + '14',
                  color: activeTab === tab.id
                    ? (tab.id === 'password' ? K.text : K.surface)
                    : K.text,
                  border: `1px solid ${tab.color}55`,
                }}
              >
                <span className="text-xl">{tab.emoji}</span>
                <span className="text-xs text-center leading-tight">{tab.label}</span>
                {hasBadge && (
                  <span className="absolute -top-1.5 -right-1.5 text-xs font-black rounded-full w-5 h-5 flex items-center justify-center"
                    style={{ backgroundColor: K.pink, color: K.surface }}>
                    {earnedBadges.size}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Active panel */}
        <div className="rounded-2xl border overflow-hidden"
          style={{ backgroundColor: K.surface, borderColor: K.border }}>
          <div className="px-5 py-3 font-black text-sm flex items-center gap-2"
            style={{
              backgroundColor: activeTabDef.color + '1A',
              color: activeTabDef.color,
              borderBottom: `1px solid ${activeTabDef.color}33`,
            }}>
            {activeTabDef.emoji} {activeTabDef.label}
          </div>

          {activeTab === 'quiz'     && <SafetyQuiz   onBadge={() => awardBadge('quiz')} />}
          {activeTab === 'scam'     && <ScamDetector  onBadge={() => awardBadge('scam')} />}
          {activeTab === 'share'    && <ShareOrNot    onBadge={() => awardBadge('share')} />}
          {activeTab === 'fakenews' && <FakeNewsTab    onBadge={awardBadge} />}
          {activeTab === 'password' && <PasswordBuilder onBadge={() => awardBadge('password')} />}
          {activeTab === 'levels'   && <AgeLevels       onBadge={awardBadge} />}
          {activeTab === 'avatar'   && <AvatarBuilder   onBadge={() => awardBadge('avatar')} />}
          {activeTab === 'badges'   && <BadgesPanel     earned={earnedBadges} />}
        </div>
      </div>

      {/* Golden rules */}
      <Card color={K.blue} className="p-6 space-y-4">
        <h2 className="text-xl font-black text-center" style={{ color: K.text }}>🌟 The Golden Rules of Internet Safety</h2>
        <div className="grid md:grid-cols-2 gap-3">
          {[
            { icon: '🔐', rule: 'Never share passwords — not even with friends' },
            { icon: '🚫', rule: "Don't click links from people you don't know" },
            { icon: '🤫', rule: "Safe adults don't ask kids to keep secrets" },
            { icon: '📍', rule: 'Never share where you live or your location' },
            { icon: '🕵️', rule: 'Check before you believe — fake news is everywhere' },
            { icon: '🗣️', rule: 'Always tell a trusted adult if something feels wrong' },
            { icon: '🧠', rule: 'If something feels off, trust your gut!' },
            { icon: '💪', rule: 'You are in charge of your online safety' },
          ].map(({ icon, rule }) => (
            <div key={rule} className="flex items-start gap-2.5 rounded-xl p-3 border" style={{ backgroundColor: K.surface, borderColor: K.border }}>
              <span className="text-xl shrink-0">{icon}</span>
              <span className="text-sm font-bold" style={{ color: K.text }}>{rule}</span>
            </div>
          ))}
        </div>
      </Card>

      {/* Final encouragement */}
      <div className="rounded-2xl p-6 text-center space-y-3 border" style={{ backgroundColor: K.yellow + '0C', borderColor: K.yellow + '44' }}>
        <Star style={{ width: 28, height: 28, margin: '0 auto', color: K.text }} />
        <h2 className="text-xl font-black" style={{ color: K.text }}>You are Doing Amazing! 🌟</h2>
        <p className="font-bold text-sm" style={{ color: K.muted }}>
          The more you learn about staying safe online, the more confident you will feel. Keep playing, keep asking questions, and remember — it is always okay to ask for help!
        </p>
      </div>
    </div>
  );
}

