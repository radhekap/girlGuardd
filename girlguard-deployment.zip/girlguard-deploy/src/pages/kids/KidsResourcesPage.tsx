import { useState } from 'react';
import { ExternalLink, RefreshCw } from 'lucide-react';
import { K } from '@/components/layouts/KidsLayout';

// ─── DATA ─────────────────────────────────────────────────────────────────────

const hotlines = [
  { emoji: '📞', name: 'Crisis Text Line',                      detail: 'Text HOME to 741741 — free, 24/7',          url: 'https://www.crisistextline.org',          color: K.pink  },
  { emoji: '☎️', name: '988 Suicide & Crisis Lifeline',         detail: 'Call or text 988 — any crisis, any time',   url: 'https://988lifeline.org',                 color: K.blue  },
  { emoji: '💬', name: 'Kids Help Phone (Canada)',              detail: 'Call 1-800-668-6868 or text HELLO to 686868',url: 'https://kidshelpphone.ca',                 color: K.green },
  { emoji: '🆘', name: 'Childhelp National Hotline',           detail: 'Call 1-800-422-4453 — available 24/7',      url: 'https://www.childhelp.org/hotline/',       color: K.teal  },
];

const websites = [
  { emoji: '🌐', name: 'Cyberbullying Research Center',         detail: 'Easy-to-read guides about cyberbullying',        url: 'https://cyberbullying.org',                        color: K.pink  },
  { emoji: '🔒', name: 'Common Sense Media',                   detail: 'Reviews, tips, and guides for kids & families',  url: 'https://www.commonsensemedia.org',                 color: K.teal  },
  { emoji: '🎓', name: 'NetSmartz',                            detail: 'Fun, interactive online safety for kids',         url: 'https://www.missingkids.org/netsmartz',            color: K.blue  },
  { emoji: '🛡️', name: 'Be Internet Awesome (Google)',         detail: 'Games and tips to be safe and kind online',      url: 'https://beinternetawesome.withgoogle.com',          color: K.green },
  { emoji: '🧡', name: 'Childnet',                             detail: 'Online safety resources for young people',       url: 'https://www.childnet.com',                         color: K.yellow},
];

const forGrownUps = [
  { emoji: '👨‍👩‍👧', name: 'Internet Matters',                 detail: 'Guides for parents on protecting kids online',   url: 'https://www.internetmatters.org' },
  { emoji: '📚',    name: 'Common Sense Media — For Parents', detail: 'Parenting tips and reviews of apps & games',      url: 'https://www.commonsensemedia.org/for-parents' },
  { emoji: '🎓',    name: 'ConnectSafely',                    detail: 'Research-based safety advice for parents',        url: 'https://www.connectsafely.org' },
];

const safetyQuizQs = [
  { q: 'Which hotline can you TEXT for free help 24/7?', opts: ['Police station', 'Crisis Text Line (text HOME to 741741)', 'Your school office', 'YouTube'], correct: 1 },
  { q: 'What does NetSmartz have on its website?', opts: ['Online games and shopping', 'Only news articles', 'Fun, interactive online safety resources for kids', 'Homework help'], correct: 2 },
  { q: 'If you call 988, what kind of help can you get?', opts: ['Tech support', 'Pizza delivery', 'Help for any kind of crisis — any time', 'Weather forecasts'], correct: 2 },
  { q: 'Which website is good for kids AND parents to use together?', opts: ['Cyberbullying Research Center', 'Common Sense Media', 'Both of the above!', 'Neither'], correct: 2 },
];

// ─── COMPONENT: Resource Cards ────────────────────────────────────────────────

function ResourceFlipCard({ emoji, name, detail, url, color }: { emoji: string; name: string; detail: string; url: string; color: string }) {
  const [flipped, setFlipped] = useState(false);
  return (
    <button onClick={() => setFlipped(f => !f)}
      className="rounded-2xl border overflow-hidden text-left w-full transition-all hover:scale-[1.02]"
      style={{ borderColor: color }}>
      {!flipped ? (
        <div className="p-4 flex items-center gap-3 min-h-[80px]" style={{ backgroundColor: color + '15' }}>
          <span className="text-3xl shrink-0">{emoji}</span>
          <div className="flex-1 min-w-0">
            <p className="font-black text-sm" style={{ color: K.text }}>{name}</p>
            <p className="text-xs font-semibold mt-0.5" style={{ color: K.muted }}>Tap to see details</p>
          </div>
        </div>
      ) : (
        <div className="p-4 space-y-2 min-h-[80px]" style={{ backgroundColor: color + '25' }}>
          <p className="font-black text-sm" style={{ color: K.text }}>{emoji} {name}</p>
          <p className="text-xs font-semibold" style={{ color: K.muted }}>{detail}</p>
          <a href={url} target="_blank" rel="noreferrer"
            onClick={e => e.stopPropagation()}
            className="inline-flex items-center gap-1 text-xs font-black rounded-xl px-3 py-1.5 hover:scale-105 transition-all"
            style={{ backgroundColor: color + '18', color: color }}>
            <ExternalLink className="h-3 w-3" /> Visit site
          </a>
        </div>
      )}
    </button>
  );
}

// ─── COMPONENT: Resources Quiz ────────────────────────────────────────────────

function ResourcesQuiz() {
  const [idx, setIdx]   = useState(0);
  const [sel, setSel]   = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [done, setDone] = useState(false);

  const q = safetyQuizQs[idx];
  const choose = (i: number) => { if (sel !== null) return; setSel(i); if (i === q.correct) setScore(s => s + 1); };
  const next   = () => { if (idx + 1 >= safetyQuizQs.length) { setDone(true); return; } setIdx(i => i + 1); setSel(null); };

  if (done) return (
    <div className="text-center space-y-4 p-6">
      <div className="text-5xl">{score >= 3 ? '🏆' : '💪'}</div>
      <p className="text-2xl font-black" style={{ color: K.text }}>{score}/{safetyQuizQs.length} correct!</p>
      <p className="font-bold" style={{ color: K.blue }}>{score >= 3 ? 'Great — you know your resources!' : 'Explore the tabs and try again!'}</p>
      <button onClick={() => { setIdx(0); setSel(null); setScore(0); setDone(false); }}
        className="inline-flex items-center gap-2 px-5 py-2.5 rounded-2xl font-black text-white hover:scale-105 transition-all"
        style={{ backgroundColor: K.blue }}>
        <RefreshCw className="h-4 w-4" /> Try Again
      </button>
    </div>
  );

  return (
    <div className="p-5 space-y-4">
      <div className="flex justify-between text-xs font-bold" style={{ color: K.muted }}>
        <span>Q {idx + 1}/{safetyQuizQs.length}</span><span>Score: {score}</span>
      </div>
      <p className="font-black text-base" style={{ color: K.text }}>📚 {q.q}</p>
      <div className="space-y-2">
        {q.opts.map((o, i) => {
          const revealed = sel !== null;
          const isCorrect = i === q.correct;
          const isChosen  = sel === i;
          return (
            <button key={i} onClick={() => choose(i)}
              className="w-full text-left p-3 rounded-2xl border font-bold text-sm transition-all hover:scale-[1.01]"
              style={{ backgroundColor: !revealed ? K.quizBtn : isCorrect ? K.green + '22' : isChosen ? K.pink + '22' : K.quizBtn, borderColor: !revealed ? K.quizBtnBorder : isCorrect ? K.green : isChosen ? K.pink : K.quizBtnBorder, color: K.text }}>
              {revealed && isCorrect ? '✅ ' : revealed && isChosen ? '❌ ' : `${String.fromCharCode(65 + i)}. `}{o}
            </button>
          );
        })}
      </div>
      {sel !== null && (
        <button onClick={next}
          className="w-full py-3 rounded-2xl font-black text-white hover:scale-[1.02] transition-all"
          style={{ backgroundColor: K.teal }}>
          {idx + 1 < safetyQuizQs.length ? 'Next Question →' : 'See My Score! 🏆'}
        </button>
      )}
    </div>
  );
}

// ─── MAIN PAGE ────────────────────────────────────────────────────────────────

type Tab = 'hotlines' | 'websites' | 'quiz';

const tabs: { id: Tab; emoji: string; label: string; color: string }[] = [
  { id: 'hotlines', emoji: '📞', label: 'Helplines',     color: K.pink  },
  { id: 'websites', emoji: '🌐', label: 'Safe Websites', color: K.blue  },
  { id: 'quiz',     emoji: '🧠', label: 'Resources Quiz',color: K.teal  },
];

export default function KidsResourcesPage() {
  const [activeTab, setActiveTab] = useState<Tab>('hotlines');
  const activeTabDef = tabs.find(t => t.id === activeTab)!;

  return (
    <div className="space-y-8 max-w-4xl mx-auto">
      {/* Hero */}
      <div className="text-center space-y-3">
        <div className="text-6xl kids-bounce inline-block">📚</div>
        <h1 className="text-3xl md:text-5xl font-black text-balance" style={{ color: K.text }}>
          Resources
        </h1>
        <p className="text-sm md:text-base font-semibold text-pretty max-w-2xl mx-auto" style={{ color: K.muted }}>
          Helpful hotlines, safe websites, and tools — all in one place, just for you
        </p>
      </div>

      {/* Activity Hub */}
      <div className="space-y-4">
        <h2 className="text-xl font-black text-center" style={{ color: K.text }}>🎮 Activity Hub</h2>
        <div className="grid grid-cols-3 gap-2">
          {tabs.map(tab => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id)}
              className="px-3 py-3 rounded-xl font-black text-sm transition-all hover:scale-105 flex flex-col items-center gap-1"
              style={{ backgroundColor: activeTab === tab.id ? tab.color : tab.color + '14', color: activeTab === tab.id ? (tab.color === K.yellow ? K.text : K.surface) : K.text, border: `1px solid ${tab.color}55` }}>
              <span className="text-xl">{tab.emoji}</span>
              <span className="text-xs text-center leading-tight">{tab.label}</span>
            </button>
          ))}
        </div>

        <div className="rounded-2xl border overflow-hidden" style={{ backgroundColor: K.surface, borderColor: K.border }}>
          <div className="px-5 py-3 font-black text-sm flex items-center gap-2"
            style={{ backgroundColor: activeTabDef.color + '1A', color: activeTabDef.color, borderBottom: `1px solid ${activeTabDef.color}33` }}>
            {activeTabDef.emoji} {activeTabDef.label}
          </div>

          {activeTab === 'hotlines' && (
            <div className="p-5 space-y-4">
              <p className="text-sm font-bold text-center" style={{ color: K.muted }}>
                Free, confidential help — available 24/7. Tap a card for details!
              </p>
              <div className="space-y-3">
                {hotlines.map(r => <ResourceFlipCard key={r.name} {...r} />)}
              </div>
              <div className="rounded-xl p-4 text-center text-sm font-bold border" style={{ backgroundColor: K.pink + '08', borderColor: K.pink + '33', color: K.pink }}>
                🚨 In immediate danger? Call 911 or your local emergency number.
              </div>
            </div>
          )}

          {activeTab === 'websites' && (
            <div className="p-5 space-y-4">
              <p className="text-sm font-bold text-center" style={{ color: K.muted }}>
                Safe, kid-friendly websites for learning more. Tap to explore!
              </p>
              <div className="space-y-3">
                {websites.map(r => <ResourceFlipCard key={r.name} {...r} />)}
              </div>
              <div className="space-y-3 pt-2">
                <p className="font-black text-sm" style={{ color: K.muted }}>👨‍👩‍👧 For Parents & Teachers:</p>
                {forGrownUps.map(r => (
                  <div key={r.name} className="flex items-center justify-between gap-3 p-3 rounded-xl border"
                    style={{ borderColor: K.quizBtnBorder, backgroundColor: K.surface }}>
                    <div className="flex items-center gap-2 min-w-0">
                      <span className="text-xl shrink-0">{r.emoji}</span>
                      <div className="min-w-0">
                        <p className="font-black text-sm truncate" style={{ color: K.text }}>{r.name}</p>
                        <p className="text-xs font-semibold" style={{ color: K.muted }}>{r.detail}</p>
                      </div>
                    </div>
                    <a href={r.url} target="_blank" rel="noreferrer"
                      className="shrink-0 h-8 w-8 rounded-xl flex items-center justify-center hover:scale-110 transition-all"
                      style={{ backgroundColor: K.blue + '14', color: K.blue }}>
                      <ExternalLink className="h-4 w-4" />
                    </a>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'quiz' && <ResourcesQuiz />}
        </div>
      </div>

      {/* Reminder */}
      <div className="rounded-2xl border p-6 text-center space-y-3" style={{ backgroundColor: K.yellow + '0C', borderColor: K.yellow + '44' }}>
        <p className="text-3xl">💛</p>
        <h2 className="text-xl font-black" style={{ color: K.text }}>You Have Got This!</h2>
        <p className="text-sm font-bold" style={{ color: K.muted }}>
          These resources are always here to help you. kidsGuard will always be here for you too.
        </p>
      </div>
    </div>
  );
}

