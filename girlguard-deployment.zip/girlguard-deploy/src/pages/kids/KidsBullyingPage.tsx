import { useState, useCallback } from 'react';
import { Heart, RefreshCw, CheckCircle, XCircle } from 'lucide-react';
import { K } from '@/components/layouts/KidsLayout';

// ─── DATA ─────────────────────────────────────────────────────────────────────

const bullyingScenarios = [
  { text: 'Sam keeps sending mean messages about your drawings to your friends.', isBullying: true, why: 'Repeatedly sending mean messages to hurt you is cyberbullying.' },
  { text: 'A classmate accidentally liked the wrong post and feels embarrassed.', isBullying: false, why: 'An accidental action without intent to hurt is not bullying.' },
  { text: 'Someone made a fake account using your name and posts mean things.', isBullying: true, why: 'Impersonating you online to cause harm is a form of cyberbullying.' },
  { text: 'Your friend forgot to add you to a group project chat by accident.', isBullying: false, why: 'Accidental exclusion is not bullying — a mistake is not the same as intent.' },
  { text: 'A group of students voted you "worst dressed" in a class poll.', isBullying: true, why: 'Organizing votes to humiliate someone is bullying.' },
  { text: 'Someone posted a funny video of a puppy and tagged you in it.', isBullying: false, why: 'A friendly, kind tag is not bullying.' },
];

const responseScenarios = [
  {
    situation: 'Someone sends you a mean message about your hair.',
    options: [
      { text: 'Send 10 mean messages back! 😤', correct: false, why: 'Responding with more mean messages makes things worse and could get you in trouble.' },
      { text: 'Block them, screenshot it, tell a grown-up. ✅', correct: true,  why: 'Perfect! Block, save proof, and tell someone you trust.' },
      { text: 'Post it publicly to shame them. 😬', correct: false, why: 'This escalates the situation and could be considered bullying yourself.' },
      { text: 'Ignore it, delete it, pretend it didn\'t happen.', correct: false, why: 'Ignoring alone isn\'t enough if it keeps happening. Telling an adult is important.' },
    ],
  },
  {
    situation: 'You see your friend being left out of every group game on purpose.',
    options: [
      { text: 'Do nothing — it\'s not my problem.', correct: false, why: 'Staying silent lets bullying continue. Even witnesses can help.' },
      { text: 'Join in on excluding them too.', correct: false, why: 'Joining makes you part of the problem, not the solution.' },
      { text: 'Tell a teacher and be kind to your friend privately. ✅', correct: true,  why: 'Telling a trusted adult and supporting your friend privately is the best choice.' },
      { text: 'Post about it online for everyone to see.', correct: false, why: 'This could embarrass your friend further and worsen the situation.' },
    ],
  },
  {
    situation: 'Someone shares a photo of you online without asking.',
    options: [
      { text: 'Ask them to remove it, and tell an adult if they refuse. ✅', correct: true,  why: 'Asking politely first is great. Involving an adult if they refuse is smart.' },
      { text: 'Share an embarrassing photo of them in return.', correct: false, why: 'Revenge sharing is also wrong and could make things much worse.' },
      { text: 'Like the photo so it doesn\'t seem like a big deal.', correct: false, why: 'This shows you accept it when you don\'t have to.' },
      { text: 'Comment something mean under the photo.', correct: false, why: 'A mean comment could escalate to more bullying.' },
    ],
  },
];

// ─── COMPONENT: Is It Bullying? ──────────────────────────────────────────────

function IsBullyingGame() {
  const [idx, setIdx] = useState(0);
  const [choice, setChoice] = useState<boolean | null>(null);
  const [score, setScore] = useState(0);
  const [done, setDone] = useState(false);

  const s = bullyingScenarios[idx];

  const guess = (val: boolean) => {
    if (choice !== null) return;
    setChoice(val);
    if (val === s.isBullying) setScore(n => n + 1);
  };

  const next = () => {
    if (idx + 1 >= bullyingScenarios.length) { setDone(true); return; }
    setIdx(i => i + 1); setChoice(null);
  };

  if (done) {
    const pct = Math.round((score / bullyingScenarios.length) * 100);
    return (
      <div className="text-center space-y-4 p-6">
        <div className="text-5xl">{pct >= 80 ? '🏆' : '💪'}</div>
        <p className="text-2xl font-black" style={{ color: K.text }}>You got {score}/{bullyingScenarios.length}!</p>
        <p className="font-bold" style={{ color: K.pink }}>{pct >= 80 ? 'Amazing — you know your stuff!' : 'Good try! Keep practising.'}</p>
        <button onClick={() => { setIdx(0); setChoice(null); setScore(0); setDone(false); }}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-2xl font-black text-white hover:scale-105 transition-all"
          style={{ backgroundColor: K.pink }}>
          <RefreshCw className="h-4 w-4" /> Play Again
        </button>
      </div>
    );
  }

  return (
    <div className="p-5 space-y-4">
      <div className="flex justify-between text-xs font-bold" style={{ color: K.muted }}>
        <span>Scenario {idx + 1}/{bullyingScenarios.length}</span>
        <span>Score: {score}</span>
      </div>
      <div className="rounded-xl p-5 border" style={{ borderColor: K.pink + '55', backgroundColor: K.pink + '08' }}>
        <p className="font-bold text-base" style={{ color: K.text }}>{s.text}</p>
      </div>
      {choice === null ? (
        <div className="grid grid-cols-2 gap-3">
          {[{ label: '😡 YES — Bullying!', val: true, color: K.pink }, { label: '✅ NOT Bullying', val: false, color: K.green }].map(o => (
            <button key={o.label} onClick={() => guess(o.val)}
              className="py-4 rounded-2xl font-black text-white text-sm hover:scale-105 transition-all"
              style={{ backgroundColor: o.color }}>
              {o.label}
            </button>
          ))}
        </div>
      ) : (
        <div className="space-y-3">
          <div className={`rounded-xl p-4 border flex items-start gap-2`}
            style={{ backgroundColor: choice === s.isBullying ? K.green + '22' : K.pink + '22', borderColor: choice === s.isBullying ? K.green : K.pink }}>
            {choice === s.isBullying
              ? <CheckCircle className="h-5 w-5 shrink-0 mt-0.5" style={{ color: K.green }} />
              : <XCircle className="h-5 w-5 shrink-0 mt-0.5" style={{ color: K.pink }} />}
            <div>
              <p className="font-black text-sm" style={{ color: K.text }}>{choice === s.isBullying ? 'Correct! 🎉' : `Not quite — it ${s.isBullying ? 'IS' : 'is NOT'} bullying.`}</p>
              <p className="font-semibold text-sm mt-1" style={{ color: K.muted }}>{s.why}</p>
            </div>
          </div>
          <button onClick={next}
            className="w-full py-3 rounded-2xl font-black text-white hover:scale-[1.02] transition-all"
            style={{ backgroundColor: K.teal }}>
            {idx + 1 < bullyingScenarios.length ? 'Next Scenario →' : 'See My Score! 🏆'}
          </button>
        </div>
      )}
    </div>
  );
}

// ─── COMPONENT: What Would You Do? ──────────────────────────────────────────

function WhatWouldYouDo() {
  const [idx, setIdx] = useState(0);
  const [chosen, setChosen] = useState<number | null>(null);

  const s = responseScenarios[idx];

  const pick = (i: number) => { if (chosen !== null) return; setChosen(i); };
  const next = () => { if (idx + 1 >= responseScenarios.length) { setIdx(0); setChosen(null); return; } setIdx(i => i + 1); setChosen(null); };

  return (
    <div className="p-5 space-y-4">
      <div className="text-xs font-bold" style={{ color: K.muted }}>Scenario {idx + 1}/{responseScenarios.length}</div>
      <div className="rounded-xl p-4 border" style={{ borderColor: K.blue + '44', backgroundColor: K.blue + '08' }}>
        <p className="font-bold text-base" style={{ color: K.text }}>💭 {s.situation}</p>
      </div>
      <p className="text-sm font-black" style={{ color: K.muted }}>What would you do?</p>
      <div className="space-y-2">
        {s.options.map((opt, i) => {
          const revealed = chosen !== null;
          const isChosen = chosen === i;
          const bg = !revealed ? K.quizBtn : opt.correct ? K.green + '22' : isChosen ? K.pink + '22' : K.quizBtn;
          const border = !revealed ? K.quizBtnBorder : opt.correct ? K.green : isChosen ? K.pink : K.quizBtnBorder;
          return (
            <div key={i}>
              <button onClick={() => pick(i)} disabled={revealed}
                className="w-full text-left p-3 rounded-xl border font-bold text-sm transition-all hover:scale-[1.01]"
                style={{ backgroundColor: bg, borderColor: border, color: K.text }}>
                <div className="flex items-center gap-2">
                  {revealed && opt.correct && <CheckCircle className="h-4 w-4 shrink-0" style={{ color: K.green }} />}
                  {revealed && isChosen && !opt.correct && <XCircle className="h-4 w-4 shrink-0" style={{ color: K.pink }} />}
                  {opt.text}
                </div>
              </button>
              {revealed && (isChosen || opt.correct) && (
                <p className="text-xs font-semibold mt-1 px-3" style={{ color: K.muted }}>{opt.why}</p>
              )}
            </div>
          );
        })}
      </div>
      {chosen !== null && (
        <button onClick={next}
          className="w-full py-3 rounded-2xl font-black text-white hover:scale-[1.02] transition-all"
          style={{ backgroundColor: K.teal }}>
          {idx + 1 < responseScenarios.length ? 'Next Scenario →' : '🔄 Start Over'}
        </button>
      )}
    </div>
  );
}

// ─── COMPONENT: Quick Quiz ────────────────────────────────────────────────────

const bullyingQuizQs = [
  { q: 'What should you do FIRST if someone is mean to you online?', opts: ['Reply with mean messages', 'Tell a trusted adult', 'Delete the app', 'Pretend it didn\'t happen'], correct: 1 },
  { q: 'Cyberbullying is bullying that happens...', opts: ['Only at school', 'Using technology and the internet', 'Only on video games', 'When someone gives you the silent treatment in person'], correct: 1 },
  { q: 'Why is it important to screenshot mean messages?', opts: ['To share with everyone online', 'So you can respond later', 'As proof to show a trusted adult', 'It\'s not important to keep them'], correct: 2 },
  { q: 'If a friend is being bullied online, you should...', opts: ['Ignore it, it\'s not your problem', 'Join in so you don\'t get bullied too', 'Tell them to stand up for themselves alone', 'Support your friend and tell an adult together'], correct: 3 },
];

function BullyingQuiz() {
  const [idx, setIdx] = useState(0);
  const [sel, setSel] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [done, setDone] = useState(false);

  const q = bullyingQuizQs[idx];
  const choose = (i: number) => { if (sel !== null) return; setSel(i); if (i === q.correct) setScore(s => s + 1); };
  const next = () => { if (idx + 1 >= bullyingQuizQs.length) { setDone(true); return; } setIdx(i => i + 1); setSel(null); };

  if (done) return (
    <div className="text-center space-y-4 p-6">
      <div className="text-5xl">{score >= 3 ? '🏆' : '💪'}</div>
      <p className="text-2xl font-black" style={{ color: K.text }}>{score}/{bullyingQuizQs.length} correct!</p>
      <p className="font-bold" style={{ color: K.blue }}>{score >= 3 ? 'Awesome — you really know how to handle bullying!' : 'Great effort! Review the tips and try again.'}</p>
      <button onClick={() => { setIdx(0); setSel(null); setScore(0); setDone(false); }}
        className="inline-flex items-center gap-2 px-5 py-2.5 rounded-2xl font-black text-white hover:scale-105 transition-all"
        style={{ backgroundColor: K.blue }}>
        <RefreshCw className="h-4 w-4" /> Try Again
      </button>
    </div>
  );

  return (
    <div className="p-5 space-y-4">
      <div className="flex justify-between text-xs font-bold" style={{ color: K.muted }}>
        <span>Q {idx + 1}/{bullyingQuizQs.length}</span><span>Score: {score}</span>
      </div>
      <p className="font-black text-base" style={{ color: K.text }}>💬 {q.q}</p>
      <div className="space-y-2">
        {q.opts.map((o, i) => {
          const revealed = sel !== null;
          const isCorrect = i === q.correct;
          const isChosen  = sel === i;
          return (
            <button key={i} onClick={() => choose(i)}
              className="w-full text-left p-3 rounded-xl border font-bold text-sm transition-all hover:scale-[1.01]"
              style={{ backgroundColor: !revealed ? K.quizBtn : isCorrect ? K.green + '22' : isChosen ? K.pink + '22' : K.quizBtn, borderColor: !revealed ? K.quizBtnBorder : isCorrect ? K.green : isChosen ? K.pink : K.quizBtnBorder, color: K.text }}>
              <span className="mr-2">{revealed && isCorrect ? '✅' : revealed && isChosen ? '❌' : `${String.fromCharCode(65 + i)}.`}</span>
              {o}
            </button>
          );
        })}
      </div>
      {sel !== null && (
        <button onClick={next}
          className="w-full py-3 rounded-2xl font-black text-white hover:scale-[1.02] transition-all"
          style={{ backgroundColor: K.teal }}>
          {idx + 1 < bullyingQuizQs.length ? 'Next Question →' : 'See My Score! 🏆'}
        </button>
      )}
    </div>
  );
}

// ─── COMPONENT: Kind Words Builder ───────────────────────────────────────────

const kindPhrases = [
  { text: 'That wasn\'t okay. You deserve kindness.', color: K.green  },
  { text: 'I\'m here for you. You\'re not alone.',   color: K.teal   },
  { text: 'What happened wasn\'t your fault.',        color: K.blue   },
  { text: 'You are brave for speaking up!',           color: K.pink   },
  { text: 'Let\'s go tell a grown-up together.',      color: K.yellow },
  { text: 'I believe you and I\'m on your side.',     color: K.teal   },
  { text: 'You are important and you matter!',        color: K.green  },
  { text: 'Want to talk about what happened?',        color: K.blue   },
];

function KindWordsBuilder() {
  const [selected, setSelected] = useState<Set<number>>(new Set());
  const [sent, setSent] = useState(false);

  const toggle = (i: number) => setSelected(s => { const n = new Set(s); n.has(i) ? n.delete(i) : n.add(i); return n; });

  if (sent) return (
    <div className="text-center space-y-4 p-6">
      <div className="text-5xl">💌</div>
      <p className="text-xl font-black" style={{ color: K.text }}>Your kind words are ready to share!</p>
      <div className="space-y-2">
        {[...selected].map(i => (
          <div key={i} className="rounded-2xl px-4 py-3 font-bold text-sm"
            style={{ backgroundColor: kindPhrases[i].color + '22', borderLeft: `4px solid ${kindPhrases[i].color}`, color: K.text }}>
            "{kindPhrases[i].text}"
          </div>
        ))}
      </div>
      <button onClick={() => { setSelected(new Set()); setSent(false); }}
        className="inline-flex items-center gap-2 px-5 py-2.5 rounded-2xl font-black text-white hover:scale-105 transition-all"
        style={{ backgroundColor: K.green }}>
        <RefreshCw className="h-4 w-4" /> Build Another
      </button>
    </div>
  );

  return (
    <div className="p-5 space-y-4">
      <p className="font-bold text-sm text-center" style={{ color: K.muted }}>
        Tap kind phrases to select what you'd say to a friend who is being bullied:
      </p>
      <div className="flex flex-wrap gap-2">
        {kindPhrases.map((p, i) => {
          const on = selected.has(i);
          return (
            <button key={i} onClick={() => toggle(i)}
              className="px-4 py-2 rounded-xl font-bold text-sm transition-all hover:scale-105 border"
              style={{ backgroundColor: on ? p.color : K.quizBtn, color: on ? (p.color === K.yellow ? K.text : K.surface) : K.text, borderColor: on ? p.color : K.quizBtnBorder }}>
              {p.text}
            </button>
          );
        })}
      </div>
      <button disabled={selected.size === 0} onClick={() => setSent(true)}
        className="w-full py-3 rounded-2xl font-black text-white hover:scale-[1.02] transition-all disabled:opacity-40"
        style={{ backgroundColor: K.green }}>
        {selected.size === 0 ? 'Select some kind phrases! 💚' : `Send ${selected.size} kind phrase${selected.size > 1 ? 's' : ''}! 💌`}
      </button>
    </div>
  );
}

// ─── MAIN PAGE ────────────────────────────────────────────────────────────────

type Tab = 'isbullying' | 'whatdo' | 'quiz' | 'kindwords';

const tabs: { id: Tab; emoji: string; label: string; color: string }[] = [
  { id: 'isbullying', emoji: '🤔', label: 'Is It Bullying?',    color: K.pink   },
  { id: 'whatdo',     emoji: '💭', label: 'What Would You Do?', color: K.blue   },
  { id: 'quiz',       emoji: '🧠', label: 'Bullying Quiz',      color: K.teal   },
  { id: 'kindwords',  emoji: '💚', label: 'Kind Words Builder', color: K.green  },
];

export default function KidsBullyingPage() {
  const [activeTab, setActiveTab] = useState<Tab>('isbullying');

  const noBadge = useCallback(() => {}, []);

  const activeTabDef = tabs.find(t => t.id === activeTab)!;

  return (
    <div className="space-y-8 max-w-4xl mx-auto">
      {/* Hero */}
      <div className="text-center space-y-3">
        <div className="text-6xl kids-bounce inline-block">💬</div>
        <h1 className="text-3xl md:text-5xl font-black text-balance" style={{ color: K.text }}>
          Online Bullying
        </h1>
        <p className="text-base md:text-lg font-semibold text-pretty max-w-2xl mx-auto" style={{ color: K.muted }}>
          Learn what it is, how to spot it, and exactly what to do — through games and quizzes!
        </p>
        <div className="rounded-full px-5 py-2 inline-block font-black text-sm"
          style={{ backgroundColor: K.pink + '14', color: K.pink, border: `1px solid ${K.pink}55` }}>
          Bullying is NEVER okay. You deserve to feel safe. 💛
        </div>
      </div>

      {/* Quick tip strip */}
      <div className="rounded-2xl px-5 py-3 flex flex-wrap gap-x-4 gap-y-2 justify-center"
        style={{ backgroundColor: K.pink + '0C', border: `1px solid ${K.pink}44` }}>
        <span className="text-sm font-bold" style={{ color: K.text }}>⚡ Quick Rules:</span>
        {['Block · Screenshot · Tell a grown-up', 'Never reply with mean messages', 'Asking for help is brave', 'It is NEVER your fault'].map(t => (
          <span key={t} className="text-sm font-semibold" style={{ color: K.pink }}>· {t}</span>
        ))}
      </div>

      {/* Activity Hub */}
      <div className="space-y-4">
        <h2 className="text-2xl font-black text-center" style={{ color: K.text }}>🎮 Activity Hub</h2>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
          {tabs.map(tab => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id)}
              className="px-3 py-3 rounded-2xl font-black text-sm transition-all hover:scale-105 flex flex-col items-center gap-1"
              style={{ backgroundColor: activeTab === tab.id ? tab.color : tab.color + '14', color: activeTab === tab.id ? (tab.color === K.yellow ? K.text : K.surface) : K.text, border: `1px solid ${tab.color}55` }}>
              <span className="text-xl">{tab.emoji}</span>
              <span className="text-xs text-center leading-tight">{tab.label}</span>
            </button>
          ))}
        </div>

        <div className="rounded-2xl border overflow-hidden" style={{ backgroundColor: K.surface, borderColor: K.border }}>
          <div className="px-5 py-3 font-black text-sm flex items-center gap-2"
            style={{ backgroundColor: activeTabDef.color + '1A', color: activeTabDef.color, borderBottom: `1px solid ${activeTabDef.color}33` }}>
            {activeTabDef.emoji} {activeTabDef.label}
          </div>
          {activeTab === 'isbullying' && <IsBullyingGame />}
          {activeTab === 'whatdo'     && <WhatWouldYouDo />}
          {activeTab === 'quiz'       && <BullyingQuiz />}
          {activeTab === 'kindwords'  && <KindWordsBuilder />}
        </div>
      </div>

      {/* 4-step action plan */}
      <div className="space-y-4">
        <h2 className="text-xl font-black text-center" style={{ color: K.text }}>💪 Your 4-Step Action Plan</h2>
        <div className="grid md:grid-cols-2 gap-3">
          {[
            { n: '1', title: 'Tell a Grown-Up',     text: 'Show a parent, teacher, or counselor. Proof helps!',                color: K.teal   },
            { n: '2', title: 'Don\'t Reply',         text: 'Never send mean messages back — it usually makes it worse.',       color: K.yellow },
            { n: '3', title: 'Screenshot It',        text: 'Take screenshots before deleting — keep the evidence.',           color: K.green  },
            { n: '4', title: 'Block the Person',     text: 'Most apps let you block. Ask a grown-up to help find the button.',color: K.pink   },
          ].map(({ n, title, text, color }) => (
            <div key={n} className="flex gap-4 p-4 rounded-xl border"
              style={{ backgroundColor: color + '15', borderColor: color }}>
              <div className="h-10 w-10 rounded-full flex items-center justify-center font-black text-xl shrink-0"
                style={{ backgroundColor: color + '18', color: color }}>
                {n}
              </div>
              <div>
                <p className="font-black text-base" style={{ color: K.text }}>{title}</p>
                <p className="text-sm font-semibold mt-0.5" style={{ color: K.muted }}>{text}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Reminder */}
      <div className="rounded-2xl p-6 border text-center space-y-3" style={{ backgroundColor: K.green + '0A', borderColor: K.green + '44' }}>
        <Heart className="h-8 w-8 mx-auto" style={{ color: K.green }} />
        <h2 className="text-xl font-black" style={{ color: K.text }}>Remember 💚</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-2 text-sm font-bold" style={{ color: K.text }}>
          {['🌟 Never your fault', '🌟 Asking for help is brave', '🌟 You deserve to feel safe'].map(r => (
            <div key={r} className="rounded-xl p-3" style={{ backgroundColor: K.surface, border: `1px solid ${K.border}` }}>{r}</div>
          ))}
        </div>
      </div>
    </div>
  );
}

// eslint-disable-next-line @typescript-eslint/no-unused-vars
const _noBadgeRef = KidsBullyingPage;
void _noBadgeRef;

