/**
 * KidsArcadeGames.tsx
 * Five real-time arcade games for the kidsGuard Games Hub.
 *
 * Games:
 *  1. FirewallSnakeGame   – Classic snake collecting safe data packets 💾
 *  2. VirusBusterGame     – Whack-a-mole with viruses 🦠
 *  3. SafeSurferGame      – 3-lane dodge game: catch shields, avoid viruses
 *  4. CyberMemoryGame     – Memory flip-card match (16 cards / 8 pairs)
 *  5. PasswordSprintGame  – Typing speed: type cybersec phrases as fast as you can
 */

import { useState, useEffect, useRef, useCallback } from 'react';
import { RefreshCw } from 'lucide-react';
import { K } from '@/components/layouts/KidsLayout';

// ─── Shared Helpers ────────────────────────────────────────────────────────────

function ArcadeReplay({ onReplay, color = K.teal }: { onReplay: () => void; color?: string }) {
  return (
    <button
      onClick={onReplay}
      className="inline-flex items-center gap-2 px-5 py-2.5 rounded-2xl font-black text-white hover:scale-105 transition-all"
      style={{ backgroundColor: color }}
    >
      <RefreshCw className="h-4 w-4" /> Play Again
    </button>
  );
}

function StatPill({ label, value, color }: { label: string; value: string | number; color: string }) {
  return (
    <div className="flex flex-col items-center px-4 py-2 rounded-2xl border min-w-[64px]"
      style={{ borderColor: color + '55', backgroundColor: color + '12' }}>
      <span className="text-xs font-semibold" style={{ color: K.muted }}>{label}</span>
      <span className="text-base font-black" style={{ color }}>{value}</span>
    </div>
  );
}

function DPad({ onDir }: { onDir: (d: 'UP' | 'DOWN' | 'LEFT' | 'RIGHT') => void }) {
  const btn = (label: string, dir: 'UP' | 'DOWN' | 'LEFT' | 'RIGHT') => (
    <button
      onPointerDown={(e) => { e.preventDefault(); onDir(dir); }}
      className="h-12 w-12 rounded-2xl font-black text-lg flex items-center justify-center border active:scale-95 transition-all select-none"
      style={{ borderColor: K.teal + '88', backgroundColor: K.teal + '15', color: K.teal }}
    >
      {label}
    </button>
  );
  return (
    <div className="flex flex-col items-center gap-1">
      <div>{btn('↑', 'UP')}</div>
      <div className="flex gap-1">
        {btn('←', 'LEFT')}
        {btn('↓', 'DOWN')}
        {btn('→', 'RIGHT')}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// GAME 1: FIREWALL SNAKE
// ═══════════════════════════════════════════════════════════════════════════════

const COLS = 18;
const ROWS = 14;
type Pt = { x: number; y: number };
type Dir = 'UP' | 'DOWN' | 'LEFT' | 'RIGHT';

function randPt(exclude: Pt[]): Pt {
  let p: Pt;
  do {
    p = { x: Math.floor(Math.random() * COLS), y: Math.floor(Math.random() * ROWS) };
  } while (exclude.some(e => e.x === p.x && e.y === p.y));
  return p;
}

function mkViruses(count: number, exclude: Pt[]): Pt[] {
  const vs: Pt[] = [];
  for (let i = 0; i < count; i++) vs.push(randPt([...exclude, ...vs]));
  return vs;
}

function initSnake(): Pt[] {
  const cx = Math.floor(COLS / 2);
  const cy = Math.floor(ROWS / 2);
  return [{ x: cx, y: cy }, { x: cx - 1, y: cy }, { x: cx - 2, y: cy }];
}

export function FirewallSnakeGame() {
  const [snake, setSnake]       = useState<Pt[]>(() => initSnake());
  const [food, setFood]         = useState<Pt>(() => randPt(initSnake()));
  const [viruses, setViruses]   = useState<Pt[]>(() => mkViruses(8, [...initSnake(), randPt(initSnake())]));
  const [dir, setDir]           = useState<Dir>('RIGHT');
  const [score, setScore]       = useState(0);
  const [best, setBest]         = useState(0);
  const [status, setStatus]     = useState<'idle' | 'running' | 'over'>('idle');

  const dirRef   = useRef<Dir>('RIGHT');
  const snakeRef = useRef<Pt[]>(initSnake());
  const foodRef  = useRef<Pt>(food);
  const virusRef = useRef<Pt[]>(viruses);
  const scoreRef = useRef(0);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Sync refs
  useEffect(() => { snakeRef.current = snake; }, [snake]);
  useEffect(() => { foodRef.current = food; }, [food]);
  useEffect(() => { virusRef.current = viruses; }, [viruses]);
  useEffect(() => { scoreRef.current = score; }, [score]);

  const tick = useCallback(() => {
    const s    = snakeRef.current;
    const d    = dirRef.current;
    const head = s[0];
    const next: Pt = {
      x: d === 'LEFT' ? head.x - 1 : d === 'RIGHT' ? head.x + 1 : head.x,
      y: d === 'UP'   ? head.y - 1 : d === 'DOWN'  ? head.y + 1 : head.y,
    };

    const hitWall    = next.x < 0 || next.x >= COLS || next.y < 0 || next.y >= ROWS;
    const hitSelf    = s.some(p => p.x === next.x && p.y === next.y);
    const hitVirus   = virusRef.current.some(v => v.x === next.x && v.y === next.y);

    if (hitWall || hitSelf || hitVirus) {
      setStatus('over');
      if (intervalRef.current) clearInterval(intervalRef.current);
      setBest(b => Math.max(b, scoreRef.current));
      return;
    }

    const ateFood = next.x === foodRef.current.x && next.y === foodRef.current.y;
    const newSnake = ateFood ? [next, ...s] : [next, ...s.slice(0, -1)];

    if (ateFood) {
      const newScore = scoreRef.current + 1;
      setScore(newScore);
      const newFood = randPt([...newSnake, ...virusRef.current]);
      setFood(newFood);
      // Every 5 points add a virus
      if (newScore % 5 === 0) {
        const newVirus = randPt([...newSnake, ...virusRef.current, newFood]);
        setViruses(v => [...v, newVirus]);
      }
    }

    setSnake(newSnake);
    setDir(d);
  }, []);

  const startGame = useCallback(() => {
    const initS = initSnake();
    const initF = randPt(initS);
    const initV = mkViruses(8, [...initS, initF]);
    snakeRef.current = initS;
    foodRef.current  = initF;
    virusRef.current = initV;
    dirRef.current   = 'RIGHT';
    scoreRef.current = 0;
    setSnake(initS);
    setFood(initF);
    setViruses(initV);
    setDir('RIGHT');
    setScore(0);
    setStatus('running');
    if (intervalRef.current) clearInterval(intervalRef.current);
    intervalRef.current = setInterval(tick, 160);
  }, [tick]);

  // Keyboard
  useEffect(() => {
    const OPPOSITE: Record<Dir, Dir> = { UP: 'DOWN', DOWN: 'UP', LEFT: 'RIGHT', RIGHT: 'LEFT' };
    const handle = (e: KeyboardEvent) => {
      const map: Record<string, Dir> = {
        ArrowUp: 'UP', ArrowDown: 'DOWN', ArrowLeft: 'LEFT', ArrowRight: 'RIGHT',
      };
      const d = map[e.key];
      if (d && d !== OPPOSITE[dirRef.current]) {
        e.preventDefault();
        dirRef.current = d;
      }
    };
    window.addEventListener('keydown', handle);
    return () => window.removeEventListener('keydown', handle);
  }, []);

  useEffect(() => () => { if (intervalRef.current) clearInterval(intervalRef.current); }, []);

  const changeDir = (d: Dir) => {
    const OPPOSITE: Record<Dir, Dir> = { UP: 'DOWN', DOWN: 'UP', LEFT: 'RIGHT', RIGHT: 'LEFT' };
    if (d !== OPPOSITE[dirRef.current]) dirRef.current = d;
  };

  const snakeSet = new Set(snake.map(p => `${p.x},${p.y}`));
  const virusSet = new Set(viruses.map(p => `${p.x},${p.y}`));

  const cellSize = 'calc((min(100vw - 3rem, 480px) - 2px) / 18)';

  return (
    <div className="p-4 space-y-4">
      {/* Stats */}
      <div className="flex items-center justify-center gap-3 flex-wrap">
        <StatPill label="Score"   value={score} color={K.teal} />
        <StatPill label="Best"    value={best}  color={K.yellow} />
        <StatPill label="Length"  value={snake.length} color={K.green} />
      </div>

      {/* Grid */}
      <div className="relative mx-auto overflow-hidden rounded-2xl border"
        style={{
          width: '100%',
          maxWidth: 480,
          aspectRatio: `${COLS} / ${ROWS}`,
          borderColor: K.teal + '55',
          backgroundColor: '#F0FFF8',
          display: 'grid',
          gridTemplateColumns: `repeat(${COLS}, 1fr)`,
          gridTemplateRows: `repeat(${ROWS}, 1fr)`,
        }}>
        {Array.from({ length: COLS * ROWS }).map((_, i) => {
          const x = i % COLS;
          const y = Math.floor(i / COLS);
          const key = `${x},${y}`;
          const isHead   = x === snake[0]?.x && y === snake[0]?.y;
          const isBody   = snakeSet.has(key) && !isHead;
          const isFood   = x === food.x && y === food.y;
          const isVirus  = virusSet.has(key);
          return (
            <div key={key} className="relative flex items-center justify-center"
              style={{
                fontSize: cellSize,
                backgroundColor: isHead ? K.teal : isBody ? K.teal + 'AA' : isVirus ? K.pink + '22' : 'transparent',
                borderRadius: isHead || isBody ? '3px' : 0,
                border: isVirus ? `1px solid ${K.pink}44` : undefined,
              }}>
              {isFood  && <span style={{ fontSize: 'min(1rem, 3vw)', lineHeight: 1 }}>💾</span>}
              {isVirus && <span style={{ fontSize: 'min(0.8rem, 2.4vw)', lineHeight: 1 }}>🦠</span>}
            </div>
          );
        })}

        {/* Overlays */}
        {status === 'idle' && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 rounded-2xl"
            style={{ backgroundColor: 'rgba(0,0,0,0.55)' }}>
            <p className="text-3xl font-black text-white text-center">🐍 Firewall Snake</p>
            <p className="text-sm font-semibold text-white/80 text-center px-4">
              Eat 💾 data packets. Avoid 🦠 viruses and walls!
            </p>
            <button onClick={startGame}
              className="px-6 py-3 rounded-2xl font-black text-white text-lg hover:scale-105 transition-all"
              style={{ backgroundColor: K.teal }}>
              Start!
            </button>
          </div>
        )}
        {status === 'over' && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 rounded-2xl"
            style={{ backgroundColor: 'rgba(0,0,0,0.65)' }}>
            <p className="text-4xl">💀</p>
            <p className="text-2xl font-black text-white">Game Over!</p>
            <p className="text-lg font-bold text-white/80">Score: {score}</p>
            <ArcadeReplay onReplay={startGame} color={K.teal} />
          </div>
        )}
      </div>

      {/* D-Pad */}
      <div className="flex justify-center pt-1">
        <DPad onDir={changeDir} />
      </div>
      <p className="text-center text-xs font-semibold" style={{ color: K.muted }}>
        Arrow keys or D-pad to steer 🎮
      </p>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// GAME 2: VIRUS BUSTER (WHACK-A-MOLE)
// ═══════════════════════════════════════════════════════════════════════════════

const MOLE_GRID = 9; // 3×3
const GAME_DURATION = 30;

interface MoleState {
  active: boolean;
  type: 'virus' | 'safe';
  timerId: ReturnType<typeof setTimeout> | null;
}

export function VirusBusterGame() {
  const [moles, setMoles]   = useState<MoleState[]>(() =>
    Array.from({ length: MOLE_GRID }, () => ({ active: false, type: 'virus', timerId: null }))
  );
  const [score, setScore]   = useState(0);
  const [misses, setMisses] = useState(0);
  const [timeLeft, setTime] = useState(GAME_DURATION);
  const [status, setStatus] = useState<'idle' | 'running' | 'over'>('idle');

  const timerRef    = useRef<ReturnType<typeof setInterval> | null>(null);
  const spawnRef    = useRef<ReturnType<typeof setInterval> | null>(null);
  const molesRef    = useRef(moles);
  const scoreRef    = useRef(0);
  const missesRef   = useRef(0);

  useEffect(() => { molesRef.current = moles; }, [moles]);
  useEffect(() => { scoreRef.current = score; }, [score]);
  useEffect(() => { missesRef.current = misses; }, [misses]);

  const hideMole = useCallback((idx: number) => {
    setMoles(m => {
      const next = [...m];
      const wasVirus = next[idx].type === 'virus';
      if (next[idx].active && wasVirus) setMisses(ms => ms + 1);
      next[idx] = { active: false, type: 'virus', timerId: null };
      return next;
    });
  }, []);

  const spawnMole = useCallback(() => {
    // Find inactive slots
    const inactive = molesRef.current
      .map((m, i) => ({ m, i }))
      .filter(({ m }) => !m.active)
      .map(({ i }) => i);
    if (inactive.length === 0) return;
    const idx  = inactive[Math.floor(Math.random() * inactive.length)];
    const type: 'virus' | 'safe' = Math.random() < 0.75 ? 'virus' : 'safe';
    const delay = 800 + Math.random() * 600;
    const tid   = setTimeout(() => hideMole(idx), delay);
    setMoles(m => {
      const next = [...m];
      next[idx]  = { active: true, type, timerId: tid };
      return next;
    });
  }, [hideMole]);

  const endGame = useCallback(() => {
    if (timerRef.current) clearInterval(timerRef.current);
    if (spawnRef.current) clearInterval(spawnRef.current);
    setMoles(m => m.map(mol => {
      if (mol.timerId) clearTimeout(mol.timerId);
      return { active: false, type: 'virus', timerId: null };
    }));
    setStatus('over');
  }, []);

  const startGame = useCallback(() => {
    setScore(0);
    setMisses(0);
    setTime(GAME_DURATION);
    setMoles(Array.from({ length: MOLE_GRID }, () => ({ active: false, type: 'virus', timerId: null })));
    setStatus('running');
    scoreRef.current  = 0;
    missesRef.current = 0;

    if (timerRef.current) clearInterval(timerRef.current);
    if (spawnRef.current) clearInterval(spawnRef.current);

    timerRef.current = setInterval(() => {
      setTime(t => {
        if (t <= 1) { endGame(); return 0; }
        return t - 1;
      });
    }, 1000);

    spawnRef.current = setInterval(spawnMole, 700);
  }, [spawnMole, endGame]);

  useEffect(() => () => {
    if (timerRef.current) clearInterval(timerRef.current);
    if (spawnRef.current) clearInterval(spawnRef.current);
  }, []);

  const whack = (idx: number) => {
    if (status !== 'running') return;
    const mole = moles[idx];
    if (!mole.active) return;
    if (mole.timerId) clearTimeout(mole.timerId);
    if (mole.type === 'virus') {
      setScore(s => s + 1);
    } else {
      // Clicked safe item = penalty
      setMisses(m => m + 1);
    }
    setMoles(m => {
      const next = [...m];
      next[idx]  = { active: false, type: 'virus', timerId: null };
      return next;
    });
  };

  const icons: Record<MoleState['type'], string> = { virus: '🦠', safe: '🛡️' };

  return (
    <div className="p-4 space-y-5">
      {/* Stats */}
      <div className="flex items-center justify-center gap-3 flex-wrap">
        <StatPill label="Score"  value={score}    color={K.green} />
        <StatPill label="Misses" value={misses}   color={K.pink} />
        <StatPill label="Time"   value={`${timeLeft}s`} color={timeLeft <= 10 ? K.pink : K.blue} />
      </div>

      {/* Grid */}
      <div className="grid grid-cols-3 gap-3 mx-auto" style={{ maxWidth: 320 }}>
        {moles.map((mole, i) => (
          <button key={i}
            onClick={() => whack(i)}
            className="aspect-square rounded-2xl border flex items-center justify-center text-4xl transition-all"
            style={{
              borderColor: mole.active
                ? (mole.type === 'virus' ? K.pink : K.green)
                : K.border,
              backgroundColor: mole.active
                ? (mole.type === 'virus' ? K.pink + '20' : K.green + '20')
                : K.panel,
              transform: mole.active ? 'scale(1.08)' : 'scale(1)',
              cursor: mole.active ? 'pointer' : 'default',
            }}>
            {mole.active ? icons[mole.type] : '🕳️'}
          </button>
        ))}
      </div>

      {status === 'idle' && (
        <div className="text-center space-y-3">
          <p className="text-sm font-semibold" style={{ color: K.muted }}>
            Tap 🦠 viruses to destroy them! Avoid 🛡️ safe items.
          </p>
          <button onClick={startGame}
            className="px-6 py-3 rounded-2xl font-black text-white text-base hover:scale-105 transition-all"
            style={{ backgroundColor: K.green }}>
            Start Busting!
          </button>
        </div>
      )}

      {status === 'over' && (
        <div className="text-center space-y-3">
          <div className="rounded-2xl border p-5 space-y-2" style={{ borderColor: K.border, backgroundColor: K.panel }}>
            <p className="text-4xl">{score >= 20 ? '🏆' : score >= 10 ? '💪' : '🌱'}</p>
            <p className="text-2xl font-black" style={{ color: K.text }}>
              {score} virus{score !== 1 ? 'es' : ''} busted!
            </p>
            <p className="text-sm font-semibold" style={{ color: K.muted }}>
              {score >= 20 ? 'Incredible! You\'re a virus-busting champion! 🏆' : score >= 10 ? 'Great job! Keep training to beat more viruses!' : 'Good start! Every virus you catch protects your device!'}
            </p>
          </div>
          <ArcadeReplay onReplay={startGame} color={K.green} />
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// GAME 3: SAFE SURFER (3-LANE DODGE)
// ═══════════════════════════════════════════════════════════════════════════════

interface FallingItem {
  id:    number;
  lane:  number;       // 0 | 1 | 2
  type:  'shield' | 'virus' | 'phish';
  y:     number;       // 0–100 percent
  speed: number;
}

const SURF_TICKS = 50; // ms per tick
const ITEM_HEIGHT = 8; // percent

let _itemId = 0;
const nextId = () => ++_itemId;

export function SafeSurferGame() {
  const [lane, setLane]       = useState(1);
  const [items, setItems]     = useState<FallingItem[]>([]);
  const [score, setScore]     = useState(0);
  const [lives, setLives]     = useState(3);
  const [status, setStatus]   = useState<'idle' | 'running' | 'over'>('idle');

  const laneRef   = useRef(1);
  const livesRef  = useRef(3);
  const scoreRef  = useRef(0);
  const tickRef   = useRef<ReturnType<typeof setInterval> | null>(null);
  const spawnRef  = useRef<ReturnType<typeof setInterval> | null>(null);
  const tickCount = useRef(0);

  const stopGame = useCallback(() => {
    if (tickRef.current)  clearInterval(tickRef.current);
    if (spawnRef.current) clearInterval(spawnRef.current);
  }, []);

  const tick = useCallback(() => {
    tickCount.current++;
    const speedBoost = 1 + Math.floor(scoreRef.current / 10) * 0.3;

    setItems(prev => {
      const next: FallingItem[] = [];
      let hitVirus = false;
      let hitShield = false;

      for (const item of prev) {
        const newY = item.y + item.speed * speedBoost;
        if (newY >= 100 - ITEM_HEIGHT) {
          // Item reached player row (bottom 10%)
          if (item.lane === laneRef.current) {
            if (item.type === 'shield') hitShield = true;
            else hitVirus = true;
          }
          // item is gone regardless
        } else {
          next.push({ ...item, y: newY });
        }
      }

      if (hitShield) setScore(s => { scoreRef.current = s + 1; return s + 1; });
      if (hitVirus)  {
        const newLives = livesRef.current - 1;
        livesRef.current = newLives;
        setLives(newLives);
        if (newLives <= 0) {
          stopGame();
          setStatus('over');
        }
      }

      return next;
    });
  }, [stopGame]);

  const spawnItem = useCallback(() => {
    const r = Math.random();
    const type: FallingItem['type'] = r < 0.5 ? 'shield' : r < 0.8 ? 'virus' : 'phish';
    setItems(prev => [...prev, {
      id:    nextId(),
      lane:  Math.floor(Math.random() * 3),
      type,
      y:     0,
      speed: 2.5 + Math.random() * 1.5,
    }]);
  }, []);

  const startGame = useCallback(() => {
    _itemId = 0;
    laneRef.current  = 1;
    livesRef.current = 3;
    scoreRef.current = 0;
    tickCount.current = 0;
    setLane(1);
    setLives(3);
    setScore(0);
    setItems([]);
    setStatus('running');
    stopGame();
    tickRef.current  = setInterval(tick, SURF_TICKS);
    spawnRef.current = setInterval(spawnItem, 900);
  }, [tick, spawnItem, stopGame]);

  useEffect(() => () => stopGame(), [stopGame]);

  const moveLane = useCallback((d: -1 | 1) => {
    setLane(l => {
      const nl = Math.max(0, Math.min(2, l + d));
      laneRef.current = nl;
      return nl;
    });
  }, []);

  // Keyboard
  useEffect(() => {
    const handle = (e: KeyboardEvent) => {
      if (status !== 'running') return;
      if (e.key === 'ArrowLeft')  { e.preventDefault(); moveLane(-1); }
      if (e.key === 'ArrowRight') { e.preventDefault(); moveLane(+1); }
    };
    window.addEventListener('keydown', handle);
    return () => window.removeEventListener('keydown', handle);
  }, [status, moveLane]);

  const laneLabels = ['Left', 'Center', 'Right'];
  const itemEmoji: Record<FallingItem['type'], string> = { shield: '🛡️', virus: '🦠', phish: '🎣' };
  const laneColor = [K.blue, K.teal, K.green];

  return (
    <div className="p-4 space-y-4">
      {/* Stats */}
      <div className="flex items-center justify-center gap-3 flex-wrap">
        <StatPill label="Score" value={score} color={K.teal} />
        <StatPill label="Lives" value={'❤️'.repeat(Math.max(0, lives)) || '💀'} color={K.pink} />
      </div>

      {/* Game field */}
      <div className="relative mx-auto rounded-2xl border overflow-hidden"
        style={{
          width: '100%',
          maxWidth: 360,
          height: 320,
          borderColor: K.teal + '55',
          background: 'linear-gradient(to bottom, #e0f2fe, #f0fdf4)',
        }}>
        {/* Lane dividers */}
        {[1, 2].map(n => (
          <div key={n} className="absolute top-0 bottom-0"
            style={{ left: `${(n / 3) * 100}%`, width: 1, backgroundColor: K.border }} />
        ))}

        {/* Falling items */}
        {items.map(item => (
          <div key={item.id}
            className="absolute flex items-center justify-center text-2xl"
            style={{
              left:   `${(item.lane / 3) * 100 + 16.666 / 2 - 4}%`,
              top:    `${item.y}%`,
              width:  '10%',
              height: `${ITEM_HEIGHT}%`,
              transform: 'translateX(-50%)',
            }}>
            {itemEmoji[item.type]}
          </div>
        ))}

        {/* Player */}
        <div className="absolute flex items-center justify-center text-3xl transition-all duration-75"
          style={{
            bottom: '4%',
            left:   `${(lane / 3) * 100 + 16.666 / 2}%`,
            transform: 'translateX(-50%)',
          }}>
          🏄
        </div>

        {/* Overlays */}
        {status === 'idle' && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 rounded-2xl"
            style={{ backgroundColor: 'rgba(0,0,0,0.55)' }}>
            <p className="text-2xl font-black text-white">🏄 Safe Surfer</p>
            <p className="text-xs font-semibold text-white/80 text-center px-6">
              Catch 🛡️ shields, dodge 🦠 viruses & 🎣 phishing!
            </p>
            <button onClick={startGame}
              className="px-6 py-3 rounded-2xl font-black text-white hover:scale-105 transition-all"
              style={{ backgroundColor: K.teal }}>
              Surf!
            </button>
          </div>
        )}
        {status === 'over' && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 rounded-2xl"
            style={{ backgroundColor: 'rgba(0,0,0,0.65)' }}>
            <p className="text-4xl">🌊</p>
            <p className="text-xl font-black text-white">Wiped Out!</p>
            <p className="text-base font-bold text-white/80">Shields caught: {score}</p>
            <ArcadeReplay onReplay={startGame} color={K.teal} />
          </div>
        )}
      </div>

      {/* Lane buttons */}
      {status === 'running' && (
        <div className="flex gap-3 justify-center">
          {laneLabels.map((l, i) => (
            <button key={l}
              onPointerDown={(e) => { e.preventDefault(); setLane(i); laneRef.current = i; }}
              className="flex-1 max-w-[100px] py-3 rounded-2xl font-black text-white text-sm transition-all"
              style={{ backgroundColor: lane === i ? laneColor[i] : laneColor[i] + '55' }}>
              {l}
            </button>
          ))}
        </div>
      )}
      <p className="text-center text-xs font-semibold" style={{ color: K.muted }}>
        Arrow keys or tap lane buttons 🏄
      </p>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// GAME 4: CYBER MEMORY MATCH
// ═══════════════════════════════════════════════════════════════════════════════

const MEMORY_PAIRS = ['🔑', '🔒', '🛡️', '🦠', '💻', '📱', '🔐', '⚠️'];

interface Card { id: number; emoji: string; flipped: boolean; matched: boolean }

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function mkCards(): Card[] {
  return shuffle([...MEMORY_PAIRS, ...MEMORY_PAIRS].map((emoji, i) => ({
    id: i, emoji, flipped: false, matched: false,
  })));
}

export function CyberMemoryGame() {
  const [cards, setCards]       = useState<Card[]>(() => mkCards());
  const [selected, setSelected] = useState<number[]>([]);
  const [moves, setMoves]       = useState(0);
  const [elapsed, setElapsed]   = useState(0);
  const [status, setStatus]     = useState<'idle' | 'running' | 'won'>('idle');
  const [locked, setLocked]     = useState(false);

  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const startTimer = useCallback(() => {
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = setInterval(() => setElapsed(e => e + 1), 1000);
  }, []);

  const stopTimer = useCallback(() => {
    if (timerRef.current) clearInterval(timerRef.current);
  }, []);

  useEffect(() => () => stopTimer(), [stopTimer]);

  const startGame = useCallback(() => {
    setCards(mkCards());
    setSelected([]);
    setMoves(0);
    setElapsed(0);
    setLocked(false);
    setStatus('idle');
    stopTimer();
  }, [stopTimer]);

  const flip = (id: number) => {
    if (locked) return;
    const card = cards.find(c => c.id === id);
    if (!card || card.flipped || card.matched) return;

    if (status === 'idle') {
      setStatus('running');
      startTimer();
    }

    const newCards = cards.map(c => c.id === id ? { ...c, flipped: true } : c);
    const newSel   = [...selected, id];
    setCards(newCards);
    setSelected(newSel);

    if (newSel.length === 2) {
      setMoves(m => m + 1);
      setLocked(true);
      const [a, b] = newSel.map(sid => newCards.find(c => c.id === sid)!);
      if (a.emoji === b.emoji) {
        const matched = newCards.map(c =>
          c.id === a.id || c.id === b.id ? { ...c, matched: true } : c
        );
        setCards(matched);
        setSelected([]);
        setLocked(false);
        if (matched.every(c => c.matched)) {
          stopTimer();
          setStatus('won');
        }
      } else {
        setTimeout(() => {
          setCards(prev => prev.map(c =>
            newSel.includes(c.id) ? { ...c, flipped: false } : c
          ));
          setSelected([]);
          setLocked(false);
        }, 900);
      }
    }
  };

  const matchedCount = cards.filter(c => c.matched).length / 2;
  const fmtTime = (s: number) => `${Math.floor(s / 60)}:${(s % 60).toString().padStart(2, '0')}`;

  return (
    <div className="p-4 space-y-4">
      {/* Stats */}
      <div className="flex items-center justify-center gap-3 flex-wrap">
        <StatPill label="Pairs"  value={`${matchedCount}/${MEMORY_PAIRS.length}`} color={K.teal} />
        <StatPill label="Moves"  value={moves}   color={K.blue} />
        <StatPill label="Time"   value={fmtTime(elapsed)} color={K.yellow} />
      </div>

      {/* Card grid */}
      <div className="grid grid-cols-4 gap-2 mx-auto" style={{ maxWidth: 360 }}>
        {cards.map(card => {
          const show = card.flipped || card.matched;
          return (
            <button key={card.id}
              onClick={() => flip(card.id)}
              className="aspect-square rounded-2xl border flex items-center justify-center text-2xl transition-all duration-200"
              style={{
                borderColor: card.matched
                  ? K.green
                  : card.flipped
                  ? K.teal
                  : K.border,
                backgroundColor: card.matched
                  ? K.green + '20'
                  : card.flipped
                  ? K.teal + '15'
                  : '#F1F5F9',
                transform: show ? 'rotateY(0deg)' : 'rotateY(90deg)',
                cursor: show ? 'default' : 'pointer',
              }}>
              {show ? card.emoji : '❓'}
            </button>
          );
        })}
      </div>

      {status === 'idle' && (
        <p className="text-center text-sm font-semibold" style={{ color: K.muted }}>
          Flip cards to find matching pairs! Tap any card to start.
        </p>
      )}

      {status === 'won' && (
        <div className="text-center space-y-3">
          <div className="rounded-2xl border p-5 space-y-2" style={{ borderColor: K.green + '55', backgroundColor: K.green + '0D' }}>
            <p className="text-4xl">🎉</p>
            <p className="text-xl font-black" style={{ color: K.text }}>All pairs matched!</p>
            <div className="flex justify-center gap-4 text-sm font-bold" style={{ color: K.muted }}>
              <span>🃏 {moves} moves</span>
              <span>⏱️ {fmtTime(elapsed)}</span>
            </div>
            <p className="text-sm font-semibold" style={{ color: K.muted }}>
              {moves <= 16 ? 'Memory master! 🧠 Incredible recall!' : moves <= 24 ? 'Well done! Great memory skills!' : 'You did it! Practice makes perfect!'}
            </p>
          </div>
          <ArcadeReplay onReplay={startGame} color={K.teal} />
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// GAME 5: PASSWORD SPRINT (TYPING SPEED)
// ═══════════════════════════════════════════════════════════════════════════════

const SPRINT_PHRASES = [
  'Use a strong password with numbers and symbols',
  'Never share your password with anyone online',
  'Enable two factor authentication on your accounts',
  'Lock your screen when you walk away from your device',
  'Think before you click on any suspicious link',
  'Keep your software and apps up to date always',
  'Do not overshare personal information on social media',
  'A good password is long random and unique',
  'Check the sender before opening any email attachment',
  'Log out of accounts when using shared computers',
];

function calcWPM(chars: number, seconds: number): number {
  if (seconds === 0) return 0;
  return Math.round((chars / 5) / (seconds / 60));
}

function calcAccuracy(typed: string, target: string): number {
  if (!typed.length) return 0;
  const len = Math.min(typed.length, target.length);
  let correct = 0;
  for (let i = 0; i < len; i++) if (typed[i] === target[i]) correct++;
  return Math.round((correct / target.length) * 100);
}

export function PasswordSprintGame() {
  const [phraseIdx, setPhraseIdx] = useState(0);
  const [typed, setTyped]         = useState('');
  const [startTime, setStartTime] = useState<number | null>(null);
  const [elapsed, setElapsed]     = useState(0);
  const [roundWPM, setRoundWPM]   = useState(0);
  const [roundAcc, setRoundAcc]   = useState(0);
  const [results, setResults]     = useState<{ wpm: number; acc: number }[]>([]);
  const [status, setStatus]       = useState<'idle' | 'typing' | 'roundDone' | 'done'>('idle');
  const [rounds] = useState(3);

  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const phrase = SPRINT_PHRASES[phraseIdx % SPRINT_PHRASES.length];

  useEffect(() => () => { if (timerRef.current) clearInterval(timerRef.current); }, []);

  const startRound = (idx: number) => {
    setPhraseIdx(idx);
    setTyped('');
    setStartTime(null);
    setElapsed(0);
    setStatus('typing');
    if (timerRef.current) clearInterval(timerRef.current);
    setTimeout(() => inputRef.current?.focus(), 50);
  };

  const startGame = () => {
    setResults([]);
    startRound(Math.floor(Math.random() * SPRINT_PHRASES.length));
  };

  const handleInput = (val: string) => {
    if (status !== 'typing') return;
    if (!startTime) {
      const now = Date.now();
      setStartTime(now);
      timerRef.current = setInterval(() => {
        setElapsed(Math.floor((Date.now() - now) / 1000));
      }, 200);
    }
    setTyped(val);
    const target = SPRINT_PHRASES[phraseIdx % SPRINT_PHRASES.length];
    if (val.length >= target.length) {
      if (timerRef.current) clearInterval(timerRef.current);
      const secs  = startTime ? (Date.now() - startTime) / 1000 : 1;
      const wpm   = calcWPM(val.length, secs);
      const acc   = calcAccuracy(val, target);
      setRoundWPM(wpm);
      setRoundAcc(acc);
      const newResults = [...results, { wpm, acc }];
      setResults(newResults);
      if (newResults.length >= rounds) {
        setStatus('done');
      } else {
        setStatus('roundDone');
      }
    }
  };

  const avgWPM = results.length ? Math.round(results.reduce((s, r) => s + r.wpm, 0) / results.length) : 0;
  const avgAcc = results.length ? Math.round(results.reduce((s, r) => s + r.acc, 0) / results.length) : 0;

  // Render typed phrase with per-char coloring
  const renderPhrase = () => phrase.split('').map((ch, i) => {
    const typedCh = typed[i];
    const color = typedCh === undefined ? K.muted
      : typedCh === ch ? K.green : K.pink;
    return (
      <span key={i} className="font-mono text-base" style={{ color, fontWeight: typedCh !== undefined ? 700 : 400 }}>
        {ch}
      </span>
    );
  });

  return (
    <div className="p-4 space-y-5">
      {/* Stats */}
      <div className="flex items-center justify-center gap-3 flex-wrap">
        <StatPill label="Round" value={`${Math.min(results.length + 1, rounds)}/${rounds}`} color={K.teal} />
        {status === 'typing' && (
          <>
            <StatPill label="Time"    value={`${elapsed}s`}              color={K.yellow} />
            <StatPill label="Typed"   value={`${typed.length}/${phrase.length}`} color={K.blue} />
          </>
        )}
        {(status === 'roundDone' || status === 'done') && (
          <>
            <StatPill label="WPM"  value={roundWPM} color={K.green} />
            <StatPill label="Acc"  value={`${roundAcc}%`} color={K.teal} />
          </>
        )}
      </div>

      {status === 'idle' && (
        <div className="text-center space-y-3">
          <p className="text-sm font-semibold" style={{ color: K.muted }}>
            Type the phrase shown as fast and accurately as you can.<br />
            You'll do <strong>{rounds} rounds</strong>. Your WPM and accuracy will be tracked!
          </p>
          <button onClick={startGame}
            className="px-6 py-3 rounded-2xl font-black text-white hover:scale-105 transition-all"
            style={{ backgroundColor: K.blue }}>
            Start Sprint!
          </button>
        </div>
      )}

      {(status === 'typing' || status === 'roundDone') && (
        <div className="space-y-4">
          <div className="rounded-2xl border p-4" style={{ borderColor: K.border, backgroundColor: K.panel }}>
            <p className="text-xs font-black mb-2" style={{ color: K.muted }}>Type this phrase:</p>
            <div className="flex flex-wrap gap-0 leading-relaxed">{renderPhrase()}</div>
          </div>
          <input
            ref={inputRef}
            type="text"
            value={typed}
            onChange={e => handleInput(e.target.value)}
            disabled={status !== 'typing'}
            placeholder="Start typing here…"
            className="w-full px-4 py-3 rounded-2xl border font-mono text-sm outline-none transition-all"
            style={{
              borderColor: status === 'typing' ? K.teal : K.border,
              backgroundColor: K.surface,
              color: K.text,
            }}
          />
        </div>
      )}

      {status === 'roundDone' && (
        <div className="text-center space-y-3">
          <div className="rounded-2xl border p-4 space-y-1"
            style={{ borderColor: K.green + '55', backgroundColor: K.green + '0D' }}>
            <p className="font-black text-base" style={{ color: K.text }}>
              Round {results.length} complete! ⚡ {roundWPM} WPM · {roundAcc}% accuracy
            </p>
          </div>
          <button
            onClick={() => startRound(Math.floor(Math.random() * SPRINT_PHRASES.length))}
            className="px-6 py-2.5 rounded-2xl font-black text-white hover:scale-105 transition-all"
            style={{ backgroundColor: K.blue }}>
            Next Round →
          </button>
        </div>
      )}

      {status === 'done' && (
        <div className="text-center space-y-3">
          <div className="rounded-2xl border p-5 space-y-3"
            style={{ borderColor: K.border, backgroundColor: K.panel }}>
            <p className="text-3xl">{avgWPM >= 50 ? '🚀' : avgWPM >= 30 ? '💪' : '🌱'}</p>
            <p className="text-xl font-black" style={{ color: K.text }}>Sprint Complete!</p>
            <div className="flex justify-center gap-4">
              <StatPill label="Avg WPM" value={avgWPM}    color={K.teal} />
              <StatPill label="Avg Acc" value={`${avgAcc}%`} color={K.green} />
            </div>
            <p className="text-sm font-semibold" style={{ color: K.muted }}>
              {avgWPM >= 50
                ? 'Blazing fast! You type like a cybersecurity pro! 🔐'
                : avgWPM >= 30
                ? 'Solid speed! Keep practising to get even faster!'
                : 'Good effort — every practice session builds speed and accuracy!'}
            </p>
          </div>
          <ArcadeReplay onReplay={startGame} color={K.blue} />
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// ARCADE GAME 6: Encryption Decoder
// Type the plaintext that matches the Caesar-cipher encrypted word
// ═══════════════════════════════════════════════════════════════════════════════

const encryptionRounds = [
  { cipher: 'SDVVZRUG', answer: 'PASSWORD', shift: 3, hint: 'Something you use to log in' },
  { cipher: 'ILUHZDOO', answer: 'FIREWALL', shift: 3, hint: 'A barrier that blocks bad traffic' },
  { cipher: 'YLUXV',    answer: 'VIRUS',    shift: 3, hint: 'A harmful program that spreads' },
  { cipher: 'SKlvklqj', answer: 'PHISHING', shift: 3, hint: 'Tricking you with fake emails' },
  { cipher: 'KDFFHU',   answer: 'HACKER',   shift: 3, hint: 'Someone who breaks into systems' },
  { cipher: 'HQFUBSW',  answer: 'ENCRYPT',  shift: 3, hint: 'To scramble data so only you can read it' },
  { cipher: 'EDFNXS',   answer: 'BACKUP',   shift: 3, hint: 'A copy of your files kept safe' },
  { cipher: 'PDOZUUH',  answer: 'MALWARE',  shift: 3, hint: 'Software designed to damage your device' },
];

export function EncryptionDecoderGame() {
  const [round, setRound]     = useState(0);
  const [input, setInput]     = useState('');
  const [result, setResult]   = useState<'correct' | 'wrong' | null>(null);
  const [score, setScore]     = useState(0);
  const [done, setDone]       = useState(false);
  const [showHint, setShowHint] = useState(false);
  const total = encryptionRounds.length;
  const q     = encryptionRounds[round];

  const submit = () => {
    if (!input.trim()) return;
    const correct = input.trim().toUpperCase() === q.answer;
    setResult(correct ? 'correct' : 'wrong');
    if (correct) setScore(s => s + 1);
  };

  const next = () => {
    if (round + 1 >= total) { setDone(true); return; }
    setRound(r => r + 1);
    setInput('');
    setResult(null);
    setShowHint(false);
  };

  const replay = () => { setRound(0); setInput(''); setResult(null); setScore(0); setDone(false); setShowHint(false); };

  if (done) {
    const pct = Math.round((score / total) * 100);
    return (
      <div className="p-6 text-center space-y-4">
        <div className="text-5xl">{pct >= 80 ? '🏆' : pct >= 50 ? '💪' : '🌱'}</div>
        <p className="text-2xl font-black" style={{ color: K.text }}>{score}/{total} cracked!</p>
        <p className="font-bold" style={{ color: K.muted }}>
          {pct >= 80 ? 'Master decoder — you belong in cryptography!' : pct >= 50 ? 'Good decrypting! Keep practising.' : 'Encryption is tricky — you\'ll crack it next time!'}
        </p>
        <ArcadeReplay onReplay={replay} color={K.teal} />
      </div>
    );
  }

  return (
    <div className="p-6 space-y-5">
      {/* Progress */}
      <div className="flex items-center justify-between">
        <span className="text-sm font-black" style={{ color: K.muted }}>Round {round + 1}/{total}</span>
        <span className="text-sm font-black px-3 py-1 rounded-full" style={{ backgroundColor: K.teal + '22', color: K.teal }}>🔓 {score} cracked</span>
      </div>
      {/* Cipher display */}
      <div className="rounded-2xl border p-5 text-center space-y-2" style={{ borderColor: K.teal, backgroundColor: K.teal + '10' }}>
        <p className="text-xs font-black uppercase tracking-widest" style={{ color: K.muted }}>Caesar Cipher (shift 3) — decode this word:</p>
        <p className="text-4xl font-black tracking-widest" style={{ color: K.text, fontFamily: 'monospace' }}>{q.cipher}</p>
        <button onClick={() => setShowHint(h => !h)} className="text-xs font-bold underline" style={{ color: K.blue }}>
          {showHint ? 'Hide hint' : '💡 Show hint'}
        </button>
        {showHint && <p className="text-sm font-semibold italic" style={{ color: K.muted }}>"{q.hint}"</p>}
      </div>
      {/* Input */}
      {result === null ? (
        <div className="space-y-3">
          <input
            type="text"
            value={input}
            onChange={e => setInput(e.target.value.toUpperCase())}
            onKeyDown={e => e.key === 'Enter' && submit()}
            placeholder="Type the decoded word..."
            className="w-full px-4 py-3 rounded-2xl border font-black text-lg text-center uppercase tracking-widest outline-none transition-all"
            style={{ borderColor: K.teal, backgroundColor: K.surface, color: K.text, fontFamily: 'monospace' }}
          />
          <button onClick={submit} disabled={!input.trim()}
            className="w-full py-3 rounded-2xl font-black text-white disabled:opacity-40 hover:scale-[1.02] transition-all"
            style={{ backgroundColor: K.teal }}>
            🔓 Decode!
          </button>
        </div>
      ) : (
        <div className={`rounded-2xl border p-4 text-center space-y-2`}
          style={{ borderColor: result === 'correct' ? K.green : K.pink, backgroundColor: (result === 'correct' ? K.green : K.pink) + '15' }}>
          <p className="text-2xl">{result === 'correct' ? '✅' : '❌'}</p>
          <p className="font-black text-lg" style={{ color: K.text }}>
            {result === 'correct' ? 'Cracked it!' : `Answer: ${q.answer}`}
          </p>
          <p className="text-sm font-semibold" style={{ color: K.muted }}>
            {result === 'correct' ? 'Nice decryption skills! 🕵️' : 'Each letter shifts back 3 positions in the alphabet.'}
          </p>
          <button onClick={next}
            className="px-6 py-2.5 rounded-2xl font-black text-white hover:scale-105 transition-all"
            style={{ backgroundColor: result === 'correct' ? K.green : K.blue }}>
            {round + 1 >= total ? '🏁 See Results' : 'Next →'}
          </button>
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// ARCADE GAME 7: Cyber Tower Defence
// Click waves of threats before they reach your "shield bar"
// ═══════════════════════════════════════════════════════════════════════════════

const THREAT_TYPES = [
  { label: 'Virus',    emoji: '🦠', color: '#E8416E', points: 10 },
  { label: 'Phish',   emoji: '🎣', color: '#F59E0B', points: 15 },
  { label: 'Hacker',  emoji: '💀', color: '#8B5CF6', points: 20 },
  { label: 'Malware', emoji: '☠️',  color: '#EF4444', points: 25 },
  { label: 'Spam',    emoji: '📧', color: '#6B7280', points: 5  },
];
const SAFE_TYPES = [
  { label: 'Update',  emoji: '🔄', color: K.green   },
  { label: 'Backup',  emoji: '💾', color: K.teal    },
  { label: 'Shield',  emoji: '🛡️', color: K.blue    },
];

interface ThreatTarget {
  id: number;
  x: number; // % from left
  y: number; // % from top
  type: typeof THREAT_TYPES[0] | typeof SAFE_TYPES[0];
  isThreat: boolean;
  alive: boolean;
}

let _tId = 0;
function makeThreat(): ThreatTarget {
  const isThreat = Math.random() > 0.35;
  const pool = isThreat ? THREAT_TYPES : SAFE_TYPES;
  const type = pool[Math.floor(Math.random() * pool.length)];
  return {
    id: ++_tId,
    x: 5 + Math.random() * 85,
    y: 5 + Math.random() * 80,
    type,
    isThreat,
    alive: true,
  };
}

export function CyberTowerDefenceGame() {
  const [phase, setPhase]       = useState<'idle' | 'play' | 'over'>('idle');
  const [targets, setTargets]   = useState<ThreatTarget[]>([]);
  const [score, setScore]       = useState(0);
  const [shield, setShield]     = useState(5);
  const [wave, setWave]         = useState(1);
  const [timeLeft, setTimeLeft] = useState(20);
  const timerRef                = useState<ReturnType<typeof setInterval> | null>(null);
  const spawnRef                = useState<ReturnType<typeof setInterval> | null>(null);

  const endGame = useCallback(() => {
    setPhase('over');
    if (timerRef[0]) clearInterval(timerRef[0]);
    if (spawnRef[0]) clearInterval(spawnRef[0]);
  }, [timerRef, spawnRef]);

  const startGame = useCallback(() => {
    _tId = 0;
    setScore(0);
    setShield(5);
    setWave(1);
    setTimeLeft(20);
    setTargets([makeThreat(), makeThreat(), makeThreat()]);
    setPhase('play');
  }, []);

  useEffect(() => {
    if (phase !== 'play') return;
    const tick = setInterval(() => {
      setTimeLeft(t => {
        if (t <= 1) { endGame(); return 0; }
        return t - 1;
      });
    }, 1000);
    timerRef[1](tick);
    return () => clearInterval(tick);
  }, [phase, endGame, timerRef]);

  useEffect(() => {
    if (phase !== 'play') return;
    const spawn = setInterval(() => {
      setTargets(ts => {
        const alive = ts.filter(t => t.alive);
        if (alive.length < 6) return [...ts.filter(t => t.alive), makeThreat()];
        return ts;
      });
    }, 1200);
    spawnRef[1](spawn);
    return () => clearInterval(spawn);
  }, [phase, spawnRef]);

  const tap = (id: number) => {
    setTargets(ts => ts.map(t => {
      if (t.id !== id || !t.alive) return t;
      if (t.isThreat) {
        setScore(s => s + (t.type as typeof THREAT_TYPES[0]).points);
      } else {
        setShield(s => {
          const next = s - 1;
          if (next <= 0) { endGame(); return 0; }
          return next;
        });
      }
      return { ...t, alive: false };
    }));
  };

  useEffect(() => {
    if (phase === 'play') {
      const missed = setInterval(() => {
        setTargets(ts => {
          const updated = ts.filter(t => t.alive);
          const removed = ts.filter(t => !t.alive);
          removed.forEach(t => {
            if (t.isThreat) {
              setShield(s => {
                const next = s - 1;
                if (next <= 0) endGame();
                return Math.max(0, next);
              });
            }
          });
          return updated;
        });
      }, 2500);
      return () => clearInterval(missed);
    }
  }, [phase, endGame]);

  if (phase === 'idle') {
    return (
      <div className="p-6 text-center space-y-5">
        <div className="text-5xl">🏰</div>
        <h3 className="text-2xl font-black" style={{ color: K.text }}>Cyber Tower Defence</h3>
        <p className="font-semibold" style={{ color: K.muted }}>
          Tap threats (🦠💀🎣☠️📧) to destroy them! <br/>
          <strong>DON'T tap</strong> safe items (🔄💾🛡️) — they cost you shield!<br/>
          You have 5 shields and 20 seconds.
        </p>
        <div className="flex justify-center gap-4 flex-wrap text-sm font-black">
          {THREAT_TYPES.map(t => (
            <span key={t.label} className="px-3 py-1.5 rounded-full text-white" style={{ backgroundColor: t.color }}>
              {t.emoji} +{t.points}pts
            </span>
          ))}
        </div>
        <button onClick={startGame}
          className="px-8 py-3 rounded-2xl font-black text-white hover:scale-105 transition-all"
          style={{ backgroundColor: K.teal }}>
          🚀 Start Defence!
        </button>
      </div>
    );
  }

  if (phase === 'over') {
    return (
      <div className="p-6 text-center space-y-4">
        <div className="text-5xl">{score >= 150 ? '🏆' : score >= 75 ? '💪' : '🌱'}</div>
        <p className="text-3xl font-black" style={{ color: K.text }}>{score} pts!</p>
        <p className="font-bold" style={{ color: K.muted }}>
          {score >= 150 ? 'Unstoppable defender! Your network is safe! 🔐'
            : score >= 75 ? 'Good job! Most threats neutralised!'
            : 'Threats got through — keep practising to protect your network!'}
        </p>
        <p className="text-sm font-semibold" style={{ color: K.muted }}>Wave {wave} reached</p>
        <ArcadeReplay onReplay={startGame} color={K.teal} />
      </div>
    );
  }

  return (
    <div className="p-4 space-y-3">
      {/* HUD */}
      <div className="flex items-center justify-between text-sm font-black">
        <span style={{ color: K.text }}>⏱️ {timeLeft}s</span>
        <span style={{ color: K.pink }}>🏆 {score} pts</span>
        <span style={{ color: K.teal }}>{'🛡️'.repeat(shield)}</span>
      </div>
      {/* Arena */}
      <div className="relative rounded-2xl border overflow-hidden select-none"
        style={{ height: 300, borderColor: K.teal, backgroundColor: '#0D1B2A' }}>
        {/* Grid lines */}
        <div className="absolute inset-0 opacity-10"
          style={{ backgroundImage: 'linear-gradient(#5BC8C4 1px,transparent 1px),linear-gradient(90deg,#5BC8C4 1px,transparent 1px)', backgroundSize: '40px 40px' }} />
        {targets.filter(t => t.alive).map(t => (
          <button key={t.id} onClick={() => tap(t.id)}
            className="absolute text-3xl hover:scale-125 transition-transform cursor-pointer"
            style={{ left: `${t.x}%`, top: `${t.y}%`, transform: 'translate(-50%,-50%)' }}
            aria-label={t.type.label}>
            {t.type.emoji}
          </button>
        ))}
        {/* Shield bar */}
        <div className="absolute bottom-2 left-2 right-2 h-2 rounded-full bg-white/20 overflow-hidden">
          <div className="h-full rounded-full transition-all"
            style={{ width: `${(shield / 5) * 100}%`, backgroundColor: shield > 2 ? K.green : K.pink }} />
        </div>
      </div>
      <p className="text-center text-xs font-black" style={{ color: K.muted }}>
        Tap threats! Avoid safe items!
      </p>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// ARCADE GAME 8: Password Crossword
// Fill in cybersecurity vocabulary in a mini crossword
// ═══════════════════════════════════════════════════════════════════════════════

interface CrosswordClue { id: string; clue: string; answer: string; direction: 'across' | 'down'; row: number; col: number }

const CROSSWORD_CLUES: CrosswordClue[] = [
  { id: '1a', clue: 'A secret word to access your account (8)',   answer: 'PASSWORD', direction: 'across', row: 0, col: 0 },
  { id: '1d', clue: 'Malicious software (6)',                     answer: 'PHISH',    direction: 'down',   row: 0, col: 3 },
  { id: '2a', clue: 'A harmful program that copies itself (5)',   answer: 'VIRUS',    direction: 'across', row: 2, col: 0 },
  { id: '2d', clue: 'A firewall blocks unwanted ___ (7)',         answer: 'TRAFFIC',  direction: 'down',   row: 2, col: 4 },
  { id: '3a', clue: 'A copy of your data kept somewhere safe (6)',answer: 'BACKUP',   direction: 'across', row: 4, col: 1 },
];

export function CyberCrosswordGame() {
  const [selected, setSelected] = useState<string | null>(null);
  const [answers, setAnswers]   = useState<Record<string, string>>({});
  const [checked, setChecked]   = useState(false);

  const setAns = (id: string, val: string) =>
    setAnswers(a => ({ ...a, [id]: val.toUpperCase() }));

  const correct = CROSSWORD_CLUES.filter(c => (answers[c.id] || '').trim() === c.answer);
  const allDone = correct.length === CROSSWORD_CLUES.length;

  const replay = () => { setAnswers({}); setChecked(false); setSelected(null); };

  return (
    <div className="p-6 space-y-5">
      <div className="flex items-center justify-between">
        <p className="text-sm font-black" style={{ color: K.muted }}>Fill in the cybersecurity crossword!</p>
        <span className="text-sm font-black px-3 py-1 rounded-full" style={{ backgroundColor: K.green + '22', color: K.green }}>
          {correct.length}/{CROSSWORD_CLUES.length} ✓
        </span>
      </div>

      {/* Clues + inputs */}
      <div className="space-y-3">
        {CROSSWORD_CLUES.map(c => {
          const val = answers[c.id] || '';
          const isCorrect = checked && val === c.answer;
          const isWrong   = checked && val !== c.answer && val.length > 0;
          return (
            <div key={c.id}
              className="rounded-2xl border p-4 space-y-2 transition-all cursor-pointer"
              style={{
                borderColor: isCorrect ? K.green : isWrong ? K.pink : selected === c.id ? K.teal : K.border,
                backgroundColor: isCorrect ? K.green + '12' : isWrong ? K.pink + '10' : selected === c.id ? K.teal + '08' : K.quizBtn,
              }}
              onClick={() => setSelected(c.id)}>
              <div className="flex items-center gap-2">
                <span className="text-xs font-black px-2 py-0.5 rounded-full text-white"
                  style={{ backgroundColor: c.direction === 'across' ? K.blue : K.pink }}>
                  {c.id.toUpperCase()} {c.direction}
                </span>
                <span className="text-sm font-semibold" style={{ color: K.text }}>{c.clue}</span>
              </div>
              <input
                type="text"
                value={val}
                maxLength={c.answer.length}
                onChange={e => setAns(c.id, e.target.value)}
                onClick={e => { e.stopPropagation(); setSelected(c.id); }}
                placeholder={`${c.answer.length} letters`}
                className="w-full px-3 py-2 rounded-xl border font-black uppercase tracking-widest text-center outline-none"
                style={{
                  borderColor: isCorrect ? K.green : isWrong ? K.pink : K.teal + '44',
                  fontFamily: 'monospace',
                  color: K.text,
                  backgroundColor: K.surface,
                }}
              />
              {isCorrect && <p className="text-xs font-black text-center" style={{ color: K.green }}>✓ Correct!</p>}
              {isWrong   && <p className="text-xs font-black text-center" style={{ color: K.pink }}>✗ Try again</p>}
            </div>
          );
        })}
      </div>

      {!allDone ? (
        <button onClick={() => setChecked(true)}
          className="w-full py-3 rounded-2xl font-black text-white hover:scale-[1.02] transition-all"
          style={{ backgroundColor: K.teal }}>
          ✏️ Check Answers
        </button>
      ) : (
        <div className="rounded-2xl border p-4 text-center space-y-3" style={{ borderColor: K.yellow, backgroundColor: K.yellow + '18' }}>
          <p className="text-4xl">🏆</p>
          <p className="text-xl font-black" style={{ color: K.text }}>Crossword Complete! You nailed it!</p>
          <ArcadeReplay onReplay={replay} color={K.yellow} />
        </div>
      )}
    </div>
  );
}
