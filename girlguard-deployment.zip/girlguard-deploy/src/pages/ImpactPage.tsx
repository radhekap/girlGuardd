import { useState, useEffect } from 'react';
import AppLayout from '@/components/layouts/AppLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { storage } from '@/lib/storage';
import type { ImpactData } from '@/types/types';
import { useDebounce } from '@/hooks/use-debounce';

export default function ImpactPage() {
  const [impact, setImpact] = useState<ImpactData>(() => storage.getImpact());

  const debouncedImpact = useDebounce(impact, 500);

  useEffect(() => {
    storage.setImpact(debouncedImpact);
  }, [debouncedImpact]);

  const handleChange = (field: keyof ImpactData, value: string) => {
    setImpact(prev => ({ ...prev, [field]: value }));
  };

  return (
    <AppLayout>
      <div className="max-w-4xl mx-auto space-y-12">
        <div className="space-y-4">
          <h1 className="text-3xl md:text-4xl font-light tracking-tight">Impact</h1>
          <p className="text-lg text-muted-foreground">
            Document the emotional and practical effects of these incidents.
          </p>
        </div>

        {/* Reports Filed */}
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl font-light">Reports Filed</CardTitle>
            <CardDescription>
              Log any reports you've made to platforms, authorities, or organizations. Include ticket numbers and reference IDs. This data auto-saves as you type.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <Label htmlFor="reportsFiled">Reports and Ticket Numbers</Label>
              <Textarea
                id="reportsFiled"
                placeholder="Example:&#10;- Instagram report #12345678 (submitted 01/15/2024)&#10;- Snapchat safety ticket REF-ABC123&#10;- Police report #2024-001234"
                value={impact.reportsFiled}
                onChange={(e) => handleChange('reportsFiled', e.target.value)}
                rows={8}
                className="font-mono text-sm"
              />
            </div>
          </CardContent>
        </Card>

        {/* Impact Journal */}
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl font-light">Impact Journal</CardTitle>
            <CardDescription>
              Record how these incidents have affected your emotional well-being, daily life, school, relationships, sleep, and mental health. This information is important for legal and support purposes. This data auto-saves as you type.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <Label htmlFor="impactJournal">Emotional and Daily Life Impact</Label>
              <Textarea
                id="impactJournal"
                placeholder="Describe how this has affected you:&#10;- Emotional state (anxiety, fear, stress, depression)&#10;- Sleep patterns&#10;- School or work performance&#10;- Relationships with friends and family&#10;- Daily activities and routines&#10;- Physical symptoms (headaches, stomach issues, etc.)"
                value={impact.impactJournal}
                onChange={(e) => handleChange('impactJournal', e.target.value)}
                rows={12}
              />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-muted/50">
          <CardContent className="p-6">
            <p className="text-sm text-muted-foreground">
              <strong>Remember:</strong> Your feelings are valid. Documenting the impact helps authorities and support professionals understand the seriousness of the situation. Be as detailed and honest as you can.
            </p>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}
