import { useState, useEffect, useRef } from'react';
import { Checkbox } from'@/components/ui/checkbox';
import { Label } from'@/components/ui/label';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from'@/components/ui/accordion';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from'@/components/ui/select';
import { AlertTriangle, Smartphone, Lock, Eye, MessageSquare, CheckCircle, XCircle, Users, Shield, Heart } from'lucide-react';

const G = {
  gradSoft: 'linear-gradient(135deg, rgba(255,107,157,0.12) 0%, rgba(183,148,246,0.12) 100%)',
  grad: 'linear-gradient(135deg, #FF6B9D 0%, #B794F6 100%)',
};

const audienceTips: Record<string, { heading: string; tips: string[] }> = {
  student: {
    heading: "Tips for you as a student",
    tips: [
      "Keep your profiles private — only accept friend requests from people you know in real life.",
      "Never share your location, school name, home address, or daily schedule with people online.",
      "Screenshots last forever. Think before posting anything you wouldn't want a parent or teacher to see.",
      "If someone online makes you uncomfortable, you don't owe them an explanation. Block, report, and tell a trusted adult.",
      "Real friends don't pressure you to send photos or keep secrets from your parents.",
      "Trust your gut. If something feels off, it probably is — and telling an adult is always the right move.",
    ],
  },
  parent: {
    heading: "Tips for parents and guardians",
    tips: [
      "Have regular, judgment-free conversations about who your child talks to online — not as interrogation, but as genuine interest.",
      "Know which apps and platforms your child uses. Many have minimum age requirements that aren't enforced.",
      "Enable parental controls and privacy settings together with your child so it's collaborative, not punitive.",
      "Watch for behavioral changes: withdrawal, anxiety around devices, new gifts, secrecy — these can be warning signs.",
      "Make sure your child knows they can come to you without facing punishment, even if they've broken a rule.",
      "Report incidents to the platform AND local law enforcement. Save all evidence before deleting anything.",
    ],
  },
  educator: {
    heading: "Tips for teachers and school staff",
    tips: [
      "Integrate online safety into regular curriculum — not as a one-off assembly but as an ongoing conversation.",
      "Create a classroom culture where students feel safe reporting without fear of social consequences.",
      "Know your school's reporting obligations and safeguarding procedures for online abuse cases.",
      "Be alert to students who seem distressed around device use, or who suddenly avoid technology.",
      "Connect students and families to local support services — schools don't have to handle this alone.",
      "Maintain a list of crisis contacts and share them accessibly with all students.",
    ],
  },
};

function StatBar({ value, label }: { value: number; label: string }) {
  const [width, setWidth] = useState(0);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) { setTimeout(() => setWidth(value), 120); observer.disconnect(); } },
      { threshold: 0.3 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, [value]);

  return (
    <div className="space-y-1.5" ref={ref}>
      <div className="flex items-baseline justify-between gap-2">
        <span className="text-xs text-muted-foreground text-pretty">{label}</span>
        <span className="text-xl font-light text-primary shrink-0">{value}%</span>
      </div>
      <div className="h-1.5 w-full rounded-full bg-border overflow-hidden">
        <div className="h-full rounded-full transition-all duration-1000 ease-out"
          style={{ width: `${width}%`, background: G.grad }} />
      </div>
    </div>
  );
}

export default function PreventionStatsPage() {
  const [checklist, setChecklist] = useState({
    understanding: false,
    secrecy: false,
    gifts: false,
    privateApps: false,
    boundaries: false,
    guilt: false,
  });
  const [behaviorTab, setBehaviorTab] = useState<'Healthy' | 'Red Flags'>('Healthy');
  const [audience, setAudience] = useState<string>('');

  const handleCheckboxChange = (key: keyof typeof checklist) => {
    setChecklist(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const socialSafetyTips = [
    { icon: Lock, title: 'Make Your Accounts Private', desc: 'Set Instagram, TikTok, and Snapchat to private. Only accept follow requests from people you actually know in real life.' },
    { icon: Eye, title: 'Control Who Can Contact You', desc: 'Turn off "Allow Message Requests" from strangers. Disable location sharing. Remove your phone number from your profile.' },
    { icon: MessageSquare, title: 'Think Before You Share', desc: "Don't post your school name, workplace, home address, or daily routines. Avoid sharing when you're home alone." },
  ];

  const datingTips = [
    { title: 'Age verification is weak', desc: 'People lie about their age online. Adults often pose as teens to target young people.' },
    { title: 'Never meet alone', desc: 'If you decide to meet someone from online, always meet in a public place, bring a friend, and tell a trusted adult.' },
    { title: 'Video chat first', desc: 'Before meeting in person, video chat to verify they are who they say they are. Catfishing is extremely common.' },
    { title: 'Trust your instincts', desc: "If something feels off, it probably is. You don't owe anyone an explanation for ending contact." },
  ];

  const groomingStages = [
    { num: 1, title: 'Targeting & Friendship', desc: 'They find you on social media, gaming platforms, or apps. They seem really interested in you, compliment you, and make you feel special.' },
    { num: 2, title: 'Building Trust', desc: 'They listen to your problems, offer advice, and position themselves as the only one who "really understands" you. They might give you gifts or attention.' },
    { num: 3, title: 'Isolation', desc: "They encourage you to keep your relationship secret. They might criticize your friends or family, making you feel like they're the only one you can trust." },
    { num: 4, title: 'Sexualization', desc: 'They gradually introduce sexual topics, normalize inappropriate behavior, and start making requests for images or videos.' },
    { num: 5, title: 'Control & Exploitation', desc: 'They use guilt, threats, or blackmail to maintain control. They might threaten to share images or tell people about your relationship.' },
  ];

  const healthyBehaviors = [
    'Respects your boundaries and accepts "no"',
    "Doesn't pressure you for personal information or images",
    'Supports your other friendships and activities',
    'Communicates at a normal pace (not constant messaging)',
    'Respects your privacy and doesn\'t demand passwords',
    'Makes you feel safe and comfortable',
  ];

  const redFlags = [
    'Asks for explicit images or videos',
    'Turns conversations sexual quickly',
    'Wants to move to private apps or platforms',
    'Gets angry when you set boundaries',
    'Creates new accounts after being blocked',
    'Monitors your activity or demands constant updates',
    'Isolates you from friends and family',
    'Uses guilt or threats to control you',
  ];

  const checklistItems: { key: keyof typeof checklist; label: string }[] = [
    { key: 'understanding', label: "Someone says they're the only one who \"really understands\" you or tries to isolate you from friends/family" },
    { key: 'secrecy', label: 'Someone asks you to keep your relationship or conversations secret from parents or friends' },
    { key: 'gifts', label: 'Someone gives you gifts, money, or special attention that makes you feel like you "owe" them something' },
    { key: 'privateApps', label: "Someone wants to move conversations to private apps, encrypted messaging, or platforms your parents can't see" },
    { key: 'boundaries', label: 'Someone gradually tests your boundaries with increasingly inappropriate requests or sexual content' },
    { key: 'guilt', label: 'Someone uses guilt, anger, or threats when you try to set boundaries or end contact' },
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-12 p-4 md:p-8">

      {/* Hero */}
      <div className="space-y-3">
        <p className="text-xs font-semibold tracking-widest uppercase text-muted-foreground">Safety Guide</p>
        <h1 className="text-3xl md:text-4xl font-light tracking-tight">Prevention & Awareness</h1>
        <p className="text-base text-muted-foreground">
          Understanding online abuse, recognizing warning signs, and learning how to protect yourself.
        </p>
      </div>

      {/* Audience selector */}
      <section className="space-y-4 animate-fade-in">
        <div className="flex items-start gap-3">
          <div className="h-9 w-9 rounded-xl flex items-center justify-center shrink-0" style={{ background: G.gradSoft }}>
            <Users className="h-4.5 w-4.5 text-primary" strokeWidth={1.75} />
          </div>
          <div>
            <h2 className="text-xl font-light tracking-tight">Personalised safety tips</h2>
            <p className="text-sm text-muted-foreground">Get advice tailored to your role</p>
          </div>
        </div>
        <Select value={audience} onValueChange={setAudience}>
          <SelectTrigger className="w-full max-w-xs h-11 text-sm">
            <SelectValue placeholder="Who are you?" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="student">A student / young person</SelectItem>
            <SelectItem value="parent">A parent or guardian</SelectItem>
            <SelectItem value="educator">A teacher or school staff</SelectItem>
          </SelectContent>
        </Select>
        {audience && audienceTips[audience] && (
          <div className="rounded-xl border border-primary/25 p-5 space-y-3 animate-fade-in">
            <p className="text-sm font-medium text-foreground">{audienceTips[audience].heading}</p>
            <div className="space-y-2">
              {audienceTips[audience].tips.map((tip, i) => (
                <div key={i} className="flex items-start gap-3">
                  <div className="h-5 w-5 rounded-full flex items-center justify-center text-xs font-semibold text-white shrink-0 mt-0.5"
                    style={{ background: G.grad }}>{i + 1}</div>
                  <p className="text-sm text-muted-foreground text-pretty">{tip}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </section>

      {/* Stats */}
      <section className="space-y-5 opacity-0 intersect:opacity-100 transition duration-700">
        <div className="flex items-start gap-3">
          <div className="h-9 w-9 rounded-xl flex items-center justify-center shrink-0" style={{ background: G.gradSoft }}>
            <AlertTriangle className="h-4.5 w-4.5 text-primary" strokeWidth={1.75} />
          </div>
          <div>
            <h2 className="text-xl font-light tracking-tight">The Reality for Teen Girls Online</h2>
            <p className="text-sm text-muted-foreground">These statistics show you're not alone, and this is a widespread problem</p>
          </div>
        </div>
        <div className="rounded-xl border border-border p-5 space-y-5">
          <StatBar value={68} label="of online abuse happens on social media platforms like Instagram, Snapchat, and TikTok" />
          <StatBar value={90} label="of image-based abuse victims are female, with teenage girls being the most targeted group" />
          <StatBar value={41} label="of U.S. adults (and higher for teens) experience online harassment" />
        </div>
        <div className="rounded-xl border border-border p-4 flex items-start gap-3">
          <Heart className="h-4 w-4 text-primary shrink-0 mt-0.5" strokeWidth={1.5} />
          <p className="text-sm text-muted-foreground text-pretty">
            <strong className="text-foreground">Important:</strong> If something happened to you, it's NOT your fault. These statistics show this is a systemic problem, not something you caused.
          </p>
        </div>
      </section>

      {/* Social Media Safety */}
      <section className="space-y-5 opacity-0 intersect:opacity-100 transition duration-700">
        <div className="flex items-start gap-3">
          <div className="h-9 w-9 rounded-xl flex items-center justify-center shrink-0" style={{ background: G.gradSoft }}>
            <Smartphone className="h-4.5 w-4.5 text-primary" strokeWidth={1.75} />
          </div>
          <div>
            <h2 className="text-xl font-light tracking-tight">Social Media Safety Essentials</h2>
            <p className="text-sm text-muted-foreground">Practical steps to protect yourself on the platforms you use every day</p>
          </div>
        </div>
        <div className="grid gap-3 md:grid-cols-3">
          {socialSafetyTips.map(({ icon: Icon, title, desc }) => (
            <div key={title} className="rounded-xl border border-border p-4 flex flex-col gap-3 h-full">
              <div className="h-8 w-8 rounded-lg flex items-center justify-center" style={{ background: G.gradSoft }}>
                <Icon className="h-4 w-4 text-primary" strokeWidth={1.75} />
              </div>
              <div className="space-y-0.5 flex-1">
                <p className="text-sm font-medium text-foreground">{title}</p>
                <p className="text-xs text-muted-foreground leading-relaxed text-pretty">{desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Digital Footprint */}
      <section className="space-y-5 opacity-0 intersect:opacity-100 transition duration-700">
        <div className="flex items-start gap-3">
          <div className="h-9 w-9 rounded-xl flex items-center justify-center shrink-0" style={{ background: G.gradSoft }}>
            <Eye className="h-4.5 w-4.5 text-primary" strokeWidth={1.75} />
          </div>
          <div>
            <h2 className="text-xl font-light tracking-tight">Your Digital Footprint Matters</h2>
            <p className="text-sm text-muted-foreground">Everything you post online can be permanent, even if you delete it</p>
          </div>
        </div>
        <div className="space-y-2">
          {[
            { title: 'Screenshots are forever', desc: 'Even if you delete a post, someone might have already taken a screenshot. Assume anything you post could be seen by anyone.' },
            { title: 'Future consequences', desc: 'Colleges, employers, and others can find your old posts. What seems funny now might affect your future.' },
            { title: 'Google yourself', desc: 'Search your name regularly to see what information about you is public. Set up Google Alerts for your name.' },
          ].map(({ title, desc }) => (
            <div key={title} className="flex items-start gap-3 p-3 rounded-xl border border-border">
              <Shield className="h-4 w-4 text-primary shrink-0 mt-0.5" strokeWidth={1.5} />
              <p className="text-sm text-muted-foreground text-pretty"><strong className="text-foreground">{title}:</strong> {desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Sexting legal facts */}
      <section className="space-y-5 opacity-0 intersect:opacity-100 transition duration-700">
        <div className="flex items-start gap-3">
          <div className="h-9 w-9 rounded-xl flex items-center justify-center shrink-0 bg-destructive/10">
            <AlertTriangle className="h-4.5 w-4.5 text-destructive" strokeWidth={1.75} />
          </div>
          <div>
            <h2 className="text-xl font-light tracking-tight">Sexting: Legal and Safety Facts</h2>
            <p className="text-sm text-muted-foreground">Important information every teen needs to know</p>
          </div>
        </div>
        <div className="rounded-xl border border-destructive/30 p-5 space-y-3">
          {[
            { title: "It's illegal", desc: "If you're under 18, sending, receiving, or possessing explicit images of yourself or other minors is illegal in most places, even if you took the photo yourself." },
            { title: 'Loss of control', desc: 'Once you send an image, you have zero control over where it goes. It can be shared, posted publicly, or used to blackmail you.' },
            { title: 'Pressure is manipulation', desc: 'If someone pressures you to send images by saying "if you loved me" or "everyone does it," that\'s manipulation. A real friend or partner would never pressure you.' },
            { title: 'If it happened to you', desc: 'You are the victim, not the criminal. Tell a trusted adult immediately. There are laws to protect victims of image-based abuse.' },
          ].map(({ title, desc }) => (
            <div key={title} className="flex items-start gap-2 text-sm text-muted-foreground">
              <AlertTriangle className="h-3.5 w-3.5 text-destructive shrink-0 mt-0.5" strokeWidth={1.5} />
              <span className="text-pretty"><strong className="text-foreground">{title}:</strong> {desc}</span>
            </div>
          ))}
        </div>
      </section>

      {/* Online Dating Safety */}
      <section className="space-y-5 opacity-0 intersect:opacity-100 transition duration-700">
        <div className="flex items-start gap-3">
          <div className="h-9 w-9 rounded-xl flex items-center justify-center shrink-0" style={{ background: G.gradSoft }}>
            <Users className="h-4.5 w-4.5 text-primary" strokeWidth={1.75} />
          </div>
          <div>
            <h2 className="text-xl font-light tracking-tight">Online Relationships & Dating Apps</h2>
            <p className="text-sm text-muted-foreground">How to stay safe when meeting people online</p>
          </div>
        </div>
        <div className="grid gap-3 md:grid-cols-2">
          {datingTips.map(({ title, desc }) => (
            <div key={title} className="rounded-xl border border-border p-4 space-y-1 h-full">
              <p className="text-sm font-medium text-foreground">{title}</p>
              <p className="text-xs text-muted-foreground text-pretty">{desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Normal vs Not Normal — tab toggle */}
      <section className="space-y-5 opacity-0 intersect:opacity-100 transition duration-700">
        <div className="flex items-start gap-3">
          <div className="h-9 w-9 rounded-xl flex items-center justify-center shrink-0" style={{ background: G.gradSoft }}>
            <Shield className="h-4.5 w-4.5 text-primary" strokeWidth={1.75} />
          </div>
          <div>
            <h2 className="text-xl font-light tracking-tight">Healthy vs. Concerning Online Behavior</h2>
          </div>
        </div>
        {/* Tab toggle */}
        <div className="flex rounded-lg border border-border overflow-hidden w-fit">
          {(['Healthy', 'Red Flags'] as const).map(tab => (
            <button key={tab}
              onClick={() => setBehaviorTab(tab)}
              className={[
                'px-5 py-2 text-sm font-medium transition-colors',
                behaviorTab === tab
                  ? tab === 'Healthy'
                    ? 'bg-primary/10 text-primary'
                    : 'bg-destructive/10 text-destructive'
                  : 'text-muted-foreground hover:text-foreground',
              ].join(' ')}>
              {tab === 'Healthy' ? '✓ Healthy Signs' : '⚠ Red Flags'}
            </button>
          ))}
        </div>
        <div className={[
          'rounded-xl border p-4 space-y-2 transition-all duration-300',
          behaviorTab === 'Healthy' ? 'border-border' : 'border-destructive/30',
        ].join(' ')}>
          <div className="flex items-center gap-2 mb-3">
            {behaviorTab === 'Healthy'
              ? <CheckCircle className="h-4 w-4 text-green-600 dark:text-green-400" strokeWidth={1.75} />
              : <XCircle className="h-4 w-4 text-destructive" strokeWidth={1.75} />}
            <p className="text-sm font-medium text-foreground">
              {behaviorTab === 'Healthy' ? 'Healthy Online Behavior' : 'Red Flags & Warning Signs'}
            </p>
          </div>
          {(behaviorTab === 'Healthy' ? healthyBehaviors : redFlags).map(item => (
            <div key={item} className="flex items-start gap-2 text-xs text-muted-foreground">
              <div className={['h-1.5 w-1.5 rounded-full shrink-0 mt-1.5',
                behaviorTab === 'Healthy' ? 'bg-green-500' : 'bg-destructive'].join(' ')} />
              <span className="text-pretty">{item}</span>
            </div>
          ))}
        </div>
      </section>

      {/* Grooming — accordion stages */}
      <section className="space-y-5 opacity-0 intersect:opacity-100 transition duration-700">
        <div className="flex items-start gap-3">
          <div className="h-9 w-9 rounded-xl flex items-center justify-center shrink-0 border border-primary/30">
            <AlertTriangle className="h-4.5 w-4.5 text-primary" strokeWidth={1.75} />
          </div>
          <div>
            <h2 className="text-xl font-light tracking-tight">Understanding Grooming</h2>
            <p className="text-sm text-muted-foreground">Tap each stage to learn what to watch for</p>
          </div>
        </div>
        <div className="rounded-xl border border-border p-5 space-y-3">
          <p className="text-sm text-muted-foreground text-pretty">
            Grooming is when someone builds trust with you to manipulate or exploit you. It often feels like friendship or romance at first, which is why it's so effective.
          </p>
          <Accordion type="single" collapsible className="space-y-2">
            {groomingStages.map(({ num, title, desc }) => (
              <AccordionItem key={num} value={`stage-${num}`}
                className="rounded-xl border border-border overflow-hidden px-0">
                <AccordionTrigger className="px-4 py-3 hover:no-underline hover:bg-muted/40 transition-colors">
                  <div className="flex items-center gap-3">
                    <div className="h-6 w-6 rounded-full flex items-center justify-center text-xs font-semibold text-white shrink-0"
                      style={{ background: G.grad }}>{num}</div>
                    <span className="text-sm font-medium text-foreground">{title}</span>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="px-4 pb-4 pt-0">
                  <p className="text-sm text-muted-foreground text-pretty pl-9">{desc}</p>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
          <div className="pt-3 border-t">
            <p className="text-sm text-muted-foreground text-pretty">
              <strong className="text-foreground">Remember:</strong> Grooming can happen over days, weeks, or months. Age doesn't matter — adults, teens, and even people your own age can be groomers.
            </p>
          </div>
        </div>
      </section>

      {/* Peer Pressure */}
      <section className="space-y-5 opacity-0 intersect:opacity-100 transition duration-700">
        <div className="flex items-start gap-3">
          <div className="h-9 w-9 rounded-xl flex items-center justify-center shrink-0" style={{ background: G.gradSoft }}>
            <Users className="h-4.5 w-4.5 text-primary" strokeWidth={1.75} />
          </div>
          <div>
            <h2 className="text-xl font-light tracking-tight">Peer Pressure & Social Dynamics</h2>
            <p className="text-sm text-muted-foreground">How to handle pressure from friends and classmates</p>
          </div>
        </div>
        <div className="space-y-2">
          {[
            { title: '"Everyone\'s doing it"', desc: "This is rarely true, and even if it were, it doesn't make something safe or right. Many teens feel pressured to do things they're uncomfortable with." },
            { title: 'FOMO (Fear of Missing Out)', desc: 'Social media makes it seem like everyone else is having more fun or living better lives. Remember that people only post highlights, not reality.' },
            { title: 'Group chats can be toxic', desc: 'Gossip, bullying, and sharing inappropriate content often happens in group chats. You can leave or mute conversations that make you uncomfortable.' },
            { title: 'Real friends respect boundaries', desc: "If someone stops being your friend because you won't do something you're uncomfortable with, they weren't a real friend." },
          ].map(({ title, desc }) => (
            <div key={title} className="flex items-start gap-3 p-3 rounded-xl border border-border">
              <Heart className="h-4 w-4 text-primary shrink-0 mt-0.5" strokeWidth={1.5} />
              <p className="text-sm text-muted-foreground text-pretty"><strong className="text-foreground">{title}:</strong> {desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Reflection Checklist */}
      <section className="space-y-5 opacity-0 intersect:opacity-100 transition duration-700">
        <div className="flex items-start gap-3">
          <div className="h-9 w-9 rounded-xl flex items-center justify-center shrink-0" style={{ background: G.gradSoft }}>
            <Eye className="h-4.5 w-4.5 text-primary" strokeWidth={1.75} />
          </div>
          <div>
            <h2 className="text-xl font-light tracking-tight">Reflection Checklist</h2>
            <p className="text-sm text-muted-foreground">Check any behaviors you've experienced. These are NOT saved — this is just for your own awareness.</p>
          </div>
        </div>
        <div className="rounded-xl border border-border p-5 space-y-4">
          {checklistItems.map(({ key, label }) => (
            <div key={key} className={[
              'flex items-start gap-3 p-3 rounded-xl border transition-all duration-200',
              checklist[key] ? 'border-primary/30 bg-primary/5' : 'border-border',
            ].join(' ')}>
              <Checkbox
                id={key}
                checked={checklist[key]}
                onCheckedChange={() => handleCheckboxChange(key)}
                className="mt-0.5"
              />
              <Label htmlFor={key} className="text-sm font-normal cursor-pointer text-muted-foreground text-pretty leading-relaxed">
                {label}
              </Label>
            </div>
          ))}
          {Object.values(checklist).some(v => v) && (
            <div className="pt-3 border-t flex items-start gap-2">
              <AlertTriangle className="h-4 w-4 text-primary shrink-0 mt-0.5" strokeWidth={1.5} />
              <p className="text-sm text-muted-foreground text-pretty">
                If you checked any of these, please talk to a trusted adult. These are warning signs of manipulation or grooming, and you deserve support.
              </p>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
