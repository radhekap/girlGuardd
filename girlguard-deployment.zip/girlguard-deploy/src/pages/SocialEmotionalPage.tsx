import { useState } from 'react';
import { Heart, Users, Sparkles, AlertCircle, Phone, ExternalLink, Brain, BookOpen, ChevronRight, RotateCcw, ChevronDown } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const G = {
  gradSoft: 'linear-gradient(135deg, rgba(255,107,157,0.12) 0%, rgba(183,148,246,0.12) 100%)',
  grad: 'linear-gradient(135deg, #FF6B9D 0%, #B794F6 100%)',
};

function SectionHeading({ icon: Icon, title, sub }: { icon: React.ElementType; title: string; sub?: string }) {
  return (
    <div className="flex items-start gap-3">
      <div className="h-9 w-9 rounded-xl flex items-center justify-center shrink-0" style={{ background: G.gradSoft }}>
        <Icon className="h-4.5 w-4.5 text-primary" strokeWidth={1.75} />
      </div>
      <div>
        <h2 className="text-xl font-light tracking-tight">{title}</h2>
        {sub && <p className="text-sm text-muted-foreground mt-0.5">{sub}</p>}
      </div>
    </div>
  );
}

const groundingSteps = [
  { num: 5, sense: 'See',   prompt: 'Name 5 things you can see right now',   placeholder: 'e.g. a lamp, my hand, the wall…', color: 'text-blue-500' },
  { num: 4, sense: 'Touch', prompt: 'Name 4 things you can physically feel', placeholder: 'e.g. the chair, my clothes, the floor…', color: 'text-purple-500' },
  { num: 3, sense: 'Hear',  prompt: 'Name 3 things you can hear',            placeholder: 'e.g. birds outside, my breathing…',  color: 'text-green-500' },
  { num: 2, sense: 'Smell', prompt: 'Name 2 things you can smell',           placeholder: 'e.g. coffee, fresh air…',             color: 'text-amber-500' },
  { num: 1, sense: 'Taste', prompt: 'Name 1 thing you can taste',            placeholder: 'e.g. mint from toothpaste…',          color: 'text-rose-500' },
];

const feelingGuides: Record<string, { label: string; what: string; doNow: string[]; doNotDo: string; crisis?: string }> = {
  anxious: {
    label: 'Anxious / Scared',
    what: "Anxiety after online harassment is your brain treating a digital threat as a physical one — it's a completely normal stress response. Your nervous system is trying to protect you.",
    doNow: [
      'Box breathing: breathe in 4 counts, hold 4, out 4, hold 4. Repeat 4 times.',
      'Remind yourself: "I am physically safe right now, in this moment."',
      'Do the 5-4-3-2-1 grounding exercise below — it directly interrupts the anxiety cycle.',
      'Tell a trusted adult today. Anxiety grows in secrecy.',
    ],
    doNotDo: "Don't keep checking the platform to see what's being said. Every check feeds the anxiety loop.",
    crisis: 'If anxiety is stopping you from sleeping or leaving the house, text HOME to 741741.',
  },
  sad: {
    label: 'Sad / Hopeless',
    what: "Sadness and hopelessness after online abuse are real grief responses. You've experienced a loss — of safety, of trust, sometimes of friendships. That deserves to be felt, not suppressed.",
    doNow: [
      "Allow yourself to feel sad without judging it as weakness. Crying is healthy.",
      'Tell someone you trust — not to fix it, just to not be alone with it.',
      'Do something physical: a walk, stretching, anything that gets you out of your head.',
      'Write one thing, however small, that is still good in your life.',
    ],
    doNotDo: "Don't isolate. Sadness intensifies in silence. Even texting one friend makes a real difference.",
    crisis: "If you're having thoughts of hurting yourself, call or text 988 right now.",
  },
  angry: {
    label: 'Angry / Frustrated',
    what: "Anger is a completely healthy and appropriate response to being harassed. It means you know you deserve better. The key is directing that energy productively, not at yourself.",
    doNow: [
      'Physical release first: go for a hard walk, hit a pillow, do jumping jacks. Anger is chemical — movement metabolizes it.',
      'Write down exactly what you want to say to the person who hurt you. You never have to send it.',
      'Channel the anger into action: document and report every piece of evidence.',
      'Talk to someone who will validate your anger, not minimize it.',
    ],
    doNotDo: "Don't retaliate online. Anything you post in anger can be used against you and escalates the situation.",
  },
  overwhelmed: {
    label: 'Overwhelmed / Numb',
    what: "Numbness and overwhelm are your mind's protective shutdown mode — it's protecting you from processing too much at once. It's common after sustained harassment. It doesn't mean you don't care.",
    doNow: [
      'Reduce inputs: close all apps, notifications off, one thing at a time.',
      "Drink water. It sounds trivial but dehydration intensifies overwhelm.",
      'Do the grounding exercise below — it works specifically for dissociation and numbness.',
      "Give yourself permission to not solve everything today. One small step is enough.",
    ],
    doNotDo: "Don't make major decisions while overwhelmed. Wait until you feel more grounded before deciding what to do about the situation.",
    crisis: "If you feel completely detached from reality, call 988.",
  },
  ashamed: {
    label: 'Ashamed / Embarrassed',
    what: "Shame is the most harmful emotion after harassment because it makes victims blame themselves. This is exactly what harassers count on. Shame belongs to the person who chose to harass — not to you.",
    doNow: [
      "Say this out loud: 'What happened to me is not my fault.'",
      'Tell at least one trusted person. Shame only survives in silence.',
      'Remember: online harassers target people they perceive as vulnerable or successful. Being targeted says nothing bad about you.',
      'Read survivor stories — realizing you are not alone dismantles shame.',
    ],
    doNotDo: "Don't delete evidence out of shame. Screenshots and records protect you. The harasser should be embarrassed, not you.",
  },
};


export default function SocialEmotionalPage() {
  const [groundingStep, setGroundingStep] = useState(0); // 0 = not started, 1-5 = active step, 6 = complete
  const [groundingInputs, setGroundingInputs] = useState(['', '', '', '', '']);
  const [selectedFeeling, setSelectedFeeling] = useState<string>('');
  const isStarted = groundingStep > 0;
  const isDone = groundingStep > 5;

  const handleGroundingNext = () => setGroundingStep(s => s + 1);
  const handleGroundingReset = () => { setGroundingStep(0); setGroundingInputs(['', '', '', '', '']); };
  const currentStep = groundingSteps[groundingStep - 1];
  const emotionalEffects = [
    'Anxiety and fear about what might happen next',
    'Depression, sadness, or feeling hopeless',
    'Shame, embarrassment, or self-blame',
    'Anger and frustration at the situation',
    'Loss of trust in others',
    'Feeling isolated or alone',
  ];
  const socialEffects = [
    'Withdrawing from friends and activities you used to enjoy',
    'Difficulty concentrating at school or work',
    'Changes in sleep patterns (sleeping too much or too little)',
    'Loss of confidence and self-esteem',
    'Strained relationships with family and friends',
    'Fear of using technology or social media',
  ];
  const immediateStrategies = [
    { title: 'Take breaks from screens', desc: "It's okay to step away from social media and technology. Give yourself permission to disconnect and focus on the real world." },
    { title: 'Practice grounding exercises', desc: 'When you feel overwhelmed, try the 5-4-3-2-1 technique: Name 5 things you see, 4 you can touch, 3 you hear, 2 you smell, and 1 you taste.' },
    { title: 'Reach out to trusted people', desc: "Talk to friends or family members you trust. You don't have to go through this alone." },
    { title: 'Do activities you enjoy', desc: 'Engage in hobbies, sports, art, music, or anything that brings you joy and helps you feel like yourself.' },
    { title: 'Write in a journal', desc: 'Writing down your thoughts and feelings can help you process what happened and track your healing journey.' },
  ];
  const longTermStrategies = [
    { title: 'Consider professional counseling', desc: 'A therapist who specializes in trauma can provide tools and support tailored to your situation.' },
    { title: 'Join support groups', desc: 'Connecting with others who have similar experiences can help you feel less alone and learn from their healing journeys.' },
    { title: 'Set healthy boundaries', desc: 'Learn to say no, limit your time on social media, and protect your energy and well-being.' },
    { title: 'Build a support network', desc: 'Surround yourself with people who believe you, support you, and make you feel safe.' },
    { title: 'Practice self-compassion', desc: "Be kind to yourself. Healing isn't linear, and it's okay to have good days and bad days." },
  ];
  const crisisHotlines = [
    { title: '988 Suicide & Crisis Lifeline', desc: 'Call or text 988 for free, confidential support 24/7' },
    { title: 'Crisis Text Line', desc: 'Text "HELLO" to 741741 to connect with a trained crisis counselor' },
    { title: 'RAINN National Sexual Assault Hotline', desc: 'Call 1-800-656-4673 or visit online.rainn.org for online chat' },
    { title: 'Teen Line', desc: 'Call 1-800-852-8336 or text "TEEN" to 839863 (6-9 PM PT)' },
  ];
  const mentalResources = [
    { title: 'Psychology Today Therapist Directory', desc: 'Find therapists in your area who specialize in trauma and abuse', link: 'https://www.psychologytoday.com/us/therapists' },
    { title: 'BetterHelp Online Therapy', desc: 'Affordable online counseling with licensed therapists', link: 'https://www.betterhelp.com/' },
    { title: 'NAMI (National Alliance on Mental Illness)', desc: 'Free support groups and mental health resources', link: 'https://www.nami.org/' },
    { title: 'The Trevor Project', desc: 'Crisis support for LGBTQ+ youth: 1-866-488-7386', link: 'https://www.thetrevorproject.org/' },
  ];
  const selfHelp = [
    { title: 'Headspace or Calm Apps', desc: 'Guided meditation and mindfulness exercises' },
    { title: 'The Body Keeps the Score', desc: 'Book about understanding and healing from trauma' },
    { title: 'r/TwoXChromosomes Support Community', desc: 'Online community for women to share experiences and support' },
    { title: 'Yoga with Adriene (YouTube)', desc: 'Free yoga videos for stress relief and emotional healing' },
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-12 p-4 md:p-8">

      {/* Hero */}
      <div className="space-y-3">
        <p className="text-xs font-semibold tracking-widest uppercase text-muted-foreground">Emotional Health</p>
        <h1 className="text-3xl md:text-4xl font-light tracking-tight text-balance">Social & Emotional Impact</h1>
        <p className="text-base text-muted-foreground">
          Understanding and healing from the emotional toll of online harassment
        </p>
      </div>

      {/* How are you feeling — targeted guide */}
      <section className="space-y-4 animate-fade-in">
        <div className="flex items-start gap-3">
          <div className="h-9 w-9 rounded-xl flex items-center justify-center shrink-0" style={{ background: G.gradSoft }}>
            <Heart className="h-4.5 w-4.5 text-primary" strokeWidth={1.75} />
          </div>
          <div>
            <h2 className="text-xl font-light tracking-tight">How are you feeling right now?</h2>
            <p className="text-sm text-muted-foreground">Get guidance specific to what you're experiencing</p>
          </div>
        </div>
        <Select value={selectedFeeling} onValueChange={setSelectedFeeling}>
          <SelectTrigger className="w-full max-w-sm h-11 text-sm">
            <SelectValue placeholder="Select your feeling…" />
          </SelectTrigger>
          <SelectContent>
            {Object.entries(feelingGuides).map(([key, val]) => (
              <SelectItem key={key} value={key}>{val.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        {selectedFeeling && feelingGuides[selectedFeeling] && (() => {
          const guide = feelingGuides[selectedFeeling];
          return (
            <div className="rounded-xl border border-primary/25 p-5 space-y-4 animate-fade-in">
              <div className="space-y-1">
                <p className="text-xs font-semibold tracking-widest uppercase text-muted-foreground">Understanding this feeling</p>
                <p className="text-sm text-muted-foreground text-pretty leading-relaxed">{guide.what}</p>
              </div>
              <div className="space-y-2 border-t pt-4">
                <p className="text-xs font-semibold tracking-widest uppercase text-muted-foreground">What to do right now</p>
                <div className="space-y-1.5">
                  {guide.doNow.map((item, i) => (
                    <div key={i} className="flex items-start gap-2.5">
                      <div className="h-5 w-5 rounded-full flex items-center justify-center text-xs font-semibold text-white shrink-0 mt-0.5"
                        style={{ background: G.grad }}>{i + 1}</div>
                      <p className="text-sm text-muted-foreground text-pretty">{item}</p>
                    </div>
                  ))}
                </div>
              </div>
              <div className="flex items-start gap-2.5 border-t pt-4">
                <ChevronRight className="h-4 w-4 text-destructive/70 shrink-0 mt-0.5" strokeWidth={2} />
                <p className="text-sm text-muted-foreground text-pretty">
                  <strong className="text-foreground">Avoid: </strong>{guide.doNotDo}
                </p>
              </div>
              {guide.crisis && (
                <div className="flex items-start gap-2.5 rounded-lg border border-destructive/25 bg-destructive/5 px-4 py-3">
                  <AlertCircle className="h-4 w-4 text-destructive shrink-0 mt-0.5" strokeWidth={1.75} />
                  <p className="text-sm text-muted-foreground text-pretty">{guide.crisis}</p>
                </div>
              )}
            </div>
          );
        })()}
      </section>

      {/* Disclaimer */}
      <div className="rounded-xl border border-primary/25 p-4 flex items-start gap-3">
        <AlertCircle className="h-4 w-4 text-primary shrink-0 mt-0.5" strokeWidth={1.5} />
        <div className="space-y-0.5">
          <p className="text-sm font-medium text-foreground">Educational Information Only</p>
          <p className="text-sm text-muted-foreground text-pretty">
            The information on this page is for educational and awareness purposes only. It does
            not constitute mental health, medical, or psychological advice and is not a substitute
            for professional support. If you are struggling with your mental health, please speak
            to a trusted adult, school counsellor, therapist, or contact a crisis helpline.
          </p>
        </div>
      </div>

      {/* Understanding the Impact — split two columns */}
      <section className="space-y-5 opacity-0 intersect:opacity-100 transition duration-700">
        <SectionHeading icon={Heart} title="Understanding the Impact" sub="What you're feeling is a normal response to an abnormal situation" />
        <div className="grid gap-4 md:grid-cols-2">
          <div className="rounded-xl border border-border p-5 space-y-3 h-full">
            <p className="text-xs font-semibold tracking-widest uppercase text-muted-foreground">Emotional Effects</p>
            <div className="space-y-2">
              {emotionalEffects.map((effect, i) => (
                <div key={i} className="flex items-start gap-3">
                  <div className="h-5 w-5 rounded-full flex items-center justify-center text-xs font-medium text-white shrink-0 mt-0.5"
                    style={{ background: G.grad }}>{i + 1}</div>
                  <p className="text-sm text-muted-foreground leading-relaxed">{effect}</p>
                </div>
              ))}
            </div>
          </div>
          <div className="rounded-xl border border-border p-5 space-y-3 h-full">
            <p className="text-xs font-semibold tracking-widest uppercase text-muted-foreground">Social Effects</p>
            <div className="space-y-2">
              {socialEffects.map((effect, i) => (
                <div key={i} className="flex items-start gap-2">
                  <div className="h-1.5 w-1.5 rounded-full bg-primary shrink-0 mt-2" />
                  <p className="text-sm text-muted-foreground leading-relaxed">{effect}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* You Are Not Alone */}
      <section className="space-y-5 opacity-0 intersect:opacity-100 transition duration-700">
        <SectionHeading icon={Users} title="You Are Not Alone" />
        <div className="grid gap-3 md:grid-cols-3">
          {[
            { title: 'These feelings are normal', desc: "You're experiencing a natural response to trauma and violation. What happened to you is not your fault, and you deserve support and healing." },
            { title: "You're not the only one", desc: '41% of U.S. adults have experienced online harassment, and the numbers are even higher for young women. Many girls have found ways to heal and move forward.' },
            { title: 'Healing is possible', desc: 'While the impact of online abuse is real and serious, recovery is absolutely possible with the right support, resources, and time.' },
          ].map(({ title, desc }) => (
            <div key={title} className="rounded-xl border border-primary/20 p-4 space-y-2 h-full">
              <p className="text-sm font-medium text-foreground">{title}</p>
              <p className="text-xs text-muted-foreground text-pretty">{desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Interactive 5-4-3-2-1 Grounding Exercise */}
      <section className="space-y-5 opacity-0 intersect:opacity-100 transition duration-700">
        <SectionHeading icon={Sparkles} title="5-4-3-2-1 Grounding Exercise"
          sub="Use this when you feel overwhelmed — it only takes 2 minutes" />
        <div className="rounded-xl border border-border p-5 space-y-4">
          {!isStarted && !isDone && (
            <div className="space-y-3 text-center py-2">
              <p className="text-sm text-muted-foreground text-pretty max-w-sm mx-auto">
                This technique helps bring you back to the present moment by engaging all five senses. Take your time with each step.
              </p>
              <button onClick={() => setGroundingStep(1)}
                className="h-10 px-6 rounded-lg text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90"
                style={{ background: G.grad }}>
                Start exercise
              </button>
            </div>
          )}
          {isStarted && !isDone && currentStep && (
            <div className="space-y-4 animate-fade-in">
              {/* Progress dots */}
              <div className="flex items-center justify-center gap-2">
                {groundingSteps.map((_, i) => (
                  <div key={i} className={['h-2 rounded-full transition-all duration-300',
                    i < groundingStep ? 'w-6 bg-primary' : 'w-2 bg-border'].join(' ')} />
                ))}
              </div>
              <div className="text-center space-y-1">
                <span className={['text-4xl font-light', currentStep.color].join(' ')}>{currentStep.num}</span>
                <p className="text-xs font-semibold tracking-widest uppercase text-muted-foreground">{currentStep.sense}</p>
                <p className="text-base font-light text-foreground">{currentStep.prompt}</p>
              </div>
              <textarea
                value={groundingInputs[groundingStep - 1]}
                onChange={e => { const n = [...groundingInputs]; n[groundingStep - 1] = e.target.value; setGroundingInputs(n); }}
                placeholder={currentStep.placeholder}
                rows={2}
                className="w-full rounded-lg border border-border bg-background px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground resize-none focus:outline-none focus:ring-1 focus:ring-primary/40 transition"
              />
              <div className="flex items-center justify-between gap-3">
                <button onClick={handleGroundingReset}
                  className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors">
                  <RotateCcw className="h-3 w-3" strokeWidth={1.75} /> Start over
                </button>
                <button onClick={handleGroundingNext}
                  className="flex items-center gap-1.5 h-9 px-5 rounded-lg text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90"
                  style={{ background: G.grad }}>
                  {groundingStep < 5 ? 'Next' : 'Finish'}
                  <ChevronRight className="h-3.5 w-3.5" strokeWidth={2} />
                </button>
              </div>
            </div>
          )}
          {isDone && (
            <div className="space-y-4 animate-fade-in">
              <div className="text-center space-y-1.5 py-2">
                <Heart className="h-8 w-8 text-primary mx-auto" strokeWidth={1.5} />
                <p className="text-base font-light text-foreground">Well done — you're present.</p>
                <p className="text-sm text-muted-foreground">Notice how you feel now compared to before you started.</p>
              </div>
              <div className="space-y-2 border-t pt-4">
                {groundingSteps.map((step, i) => groundingInputs[i] && (
                  <div key={i} className="flex items-start gap-2">
                    <span className={['text-xs font-semibold w-14 shrink-0 pt-0.5', step.color].join(' ')}>{step.num} {step.sense}</span>
                    <p className="text-sm text-muted-foreground text-pretty">{groundingInputs[i]}</p>
                  </div>
                ))}
              </div>
              <button onClick={handleGroundingReset}
                className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors">
                <RotateCcw className="h-3 w-3" strokeWidth={1.75} /> Do it again
              </button>
            </div>
          )}
        </div>
      </section>

      {/* Coping strategies — tabbed */}
      <section className="space-y-5 opacity-0 intersect:opacity-100 transition duration-700">
        <SectionHeading icon={Sparkles} title="Coping Strategies" sub="Practical ways to take care of yourself right now" />
        <Tabs defaultValue="immediate">
          <TabsList className="w-full grid grid-cols-2">
            <TabsTrigger value="immediate">Immediate Self-Care</TabsTrigger>
            <TabsTrigger value="longterm">Long-Term Healing</TabsTrigger>
          </TabsList>
          <TabsContent value="immediate" className="mt-4">
            <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
              {immediateStrategies.map(({ title, desc }, i) => (
                <div key={i} className="rounded-xl border border-border p-4 space-y-1.5 h-full flex flex-col">
                  <div className="flex items-center gap-2">
                    <div className="h-5 w-5 rounded-full flex items-center justify-center text-xs font-medium text-white shrink-0"
                      style={{ background: G.grad }}>{i + 1}</div>
                    <p className="text-sm font-medium text-foreground">{title}</p>
                  </div>
                  <p className="text-xs text-muted-foreground text-pretty flex-1">{desc}</p>
                </div>
              ))}
            </div>
          </TabsContent>
          <TabsContent value="longterm" className="mt-4">
            <div className="grid gap-3 md:grid-cols-2">
              {longTermStrategies.map(({ title, desc }) => (
                <div key={title} className="rounded-xl border border-border p-4 flex items-start gap-3 h-full">
                  <div className="h-7 w-7 rounded-lg flex items-center justify-center shrink-0" style={{ background: G.gradSoft }}>
                    <Brain className="h-3.5 w-3.5 text-primary" strokeWidth={1.75} />
                  </div>
                  <div className="space-y-0.5 min-w-0">
                    <p className="text-sm font-medium text-foreground">{title}</p>
                    <p className="text-xs text-muted-foreground text-pretty">{desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </section>

      {/* When to seek professional help */}
      <section className="space-y-5 opacity-0 intersect:opacity-100 transition duration-700">
        <div className="flex items-start gap-3">
          <div className="h-9 w-9 rounded-xl flex items-center justify-center shrink-0 bg-destructive/10">
            <AlertCircle className="h-4.5 w-4.5 text-destructive" strokeWidth={1.75} />
          </div>
          <div>
            <h2 className="text-xl font-light tracking-tight">When to Seek Professional Help</h2>
            <p className="text-sm text-muted-foreground">These signs indicate you may benefit from professional support</p>
          </div>
        </div>
        <div className="rounded-xl border border-destructive/30 p-5 space-y-3">
          <p className="text-sm text-muted-foreground text-pretty">If you're experiencing any of these, please reach out to a counselor, therapist, or crisis hotline:</p>
          <div className="space-y-2">
            {[
              'Persistent feelings of hopelessness or that things will never get better',
              'Thoughts of self-harm or suicide',
              'Inability to function in daily life (school, work, relationships)',
              'Severe anxiety, panic attacks, or constant fear',
              'Prolonged depression lasting more than two weeks',
              'Significant changes in eating or sleeping patterns',
              'Using alcohol or drugs to cope',
              'Feeling disconnected from reality',
            ].map(sign => (
              <div key={sign} className="flex items-start gap-2">
                <AlertCircle className="h-3.5 w-3.5 text-destructive shrink-0 mt-0.5" strokeWidth={1.5} />
                <p className="text-sm text-muted-foreground">{sign}</p>
              </div>
            ))}
          </div>
          <p className="text-sm font-medium text-destructive pt-2 border-t border-destructive/20">
            If you're in immediate danger or having thoughts of suicide, call 988 (Suicide & Crisis Lifeline) or text "HELLO" to 741741 (Crisis Text Line).
          </p>
        </div>
      </section>

      {/* Support Resources */}
      <section className="space-y-5 opacity-0 intersect:opacity-100 transition duration-700">
        <SectionHeading icon={Phone} title="Support Resources" sub="Help is available 24/7" />

        <div className="space-y-2">
          <p className="text-xs font-semibold tracking-widest uppercase text-muted-foreground mb-3">Crisis Hotlines</p>
          <div className="grid gap-3 md:grid-cols-2">
            {crisisHotlines.map(({ title, desc }) => (
              <div key={title} className="rounded-xl border border-primary/20 p-4 space-y-1 h-full">
                <p className="text-sm font-medium text-foreground">{title}</p>
                <p className="text-xs text-muted-foreground">{desc}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-2">
          <p className="text-xs font-semibold tracking-widest uppercase text-muted-foreground mb-3">Mental Health Resources</p>
          <div className="grid gap-3 md:grid-cols-2">
            {mentalResources.map(({ title, desc, link }) => (
              <div key={title} className="rounded-xl border border-border p-4 flex items-start gap-3 h-full">
                <ExternalLink className="h-4 w-4 text-primary shrink-0 mt-0.5" strokeWidth={1.5} />
                <div className="space-y-0.5 min-w-0">
                  <a href={link} target="_blank" rel="noopener noreferrer" className="text-sm font-medium hover:underline text-foreground">{title}</a>
                  <p className="text-xs text-muted-foreground">{desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-2">
          <p className="text-xs font-semibold tracking-widest uppercase text-muted-foreground mb-3">Self-Help Resources</p>
          <div className="grid gap-3 md:grid-cols-2">
            {selfHelp.map(({ title, desc }) => (
              <div key={title} className="rounded-xl border border-border p-4 flex items-start gap-3 h-full">
                <BookOpen className="h-4 w-4 text-primary shrink-0 mt-0.5" strokeWidth={1.5} />
                <div className="space-y-0.5 min-w-0">
                  <p className="text-sm font-medium text-foreground">{title}</p>
                  <p className="text-xs text-muted-foreground">{desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Final encouragement */}
      <section className="opacity-0 intersect:opacity-100 transition duration-700">
        <div className="rounded-xl border border-primary/25 p-6 space-y-2 text-center">
          <Heart className="h-6 w-6 text-primary mx-auto" strokeWidth={1.5} />
          <h2 className="text-lg font-light tracking-tight">Remember</h2>
          <p className="text-sm text-muted-foreground max-w-2xl mx-auto leading-relaxed text-pretty">
            Healing takes time, and everyone's journey is different. Be patient with yourself. You've already taken an important step by seeking information and support. You are strong, you are worthy, and you will get through this.
          </p>
        </div>
      </section>

    </div>
  );
}


