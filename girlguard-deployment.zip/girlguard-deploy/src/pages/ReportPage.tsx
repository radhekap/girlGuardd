import { useState } from 'react';
import AppLayout from '@/components/layouts/AppLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { storage } from '@/lib/storage';
import type { ReportData, TimelineEntry, EvidenceFile } from '@/types/types';
import { FileText, Printer } from 'lucide-react';
import { toast } from 'sonner';

export default function ReportPage() {
  const [report, setReport] = useState<string>('');
  const [generated, setGenerated] = useState(false);

  const generateReport = () => {
    const identity = storage.getIdentity();
    const timeline = storage.getTimeline();
    const impact = storage.getImpact();
    const evidence = storage.getEvidence();

    const reportData: ReportData = {
      identity,
      timeline,
      impact,
      evidence,
      generatedAt: new Date().toISOString(),
    };

    let reportText = '═══════════════════════════════════════════════════\n';
    reportText += '           INCIDENT SUMMARY REPORT\n';
    reportText += '═══════════════════════════════════════════════════\n\n';
    reportText += `Generated: ${new Date(reportData.generatedAt).toLocaleString()}\n\n`;

    // Identity Information
    reportText += '───────────────────────────────────────────────────\n';
    reportText += 'IDENTITY INFORMATION\n';
    reportText += '───────────────────────────────────────────────────\n\n';
    if (identity.usernames) {
      reportText += `Usernames/Handles: ${identity.usernames}\n`;
    }
    if (identity.realName) {
      reportText += `Real Name: ${identity.realName}\n`;
    }
    if (identity.otherDetails) {
      reportText += `Other Details:\n${identity.otherDetails}\n`;
    }
    if (!identity.usernames && !identity.realName && !identity.otherDetails) {
      reportText += 'No identity information recorded.\n';
    }
    reportText += '\n';

    // Timeline
    reportText += '───────────────────────────────────────────────────\n';
    reportText += 'TIMELINE OF INCIDENTS\n';
    reportText += '───────────────────────────────────────────────────\n\n';
    if (timeline.length > 0) {
      timeline.forEach((entry: TimelineEntry, index: number) => {
        reportText += `[${index + 1}] ${new Date(entry.date).toLocaleDateString()} at ${entry.time}\n`;
        reportText += `Platform: ${entry.platform}\n`;
        reportText += `Description:\n${entry.description}\n\n`;
      });
    } else {
      reportText += 'No incidents recorded.\n\n';
    }

    // Impact
    reportText += '───────────────────────────────────────────────────\n';
    reportText += 'IMPACT DOCUMENTATION\n';
    reportText += '───────────────────────────────────────────────────\n\n';
    if (impact.reportsFiled) {
      reportText += 'Reports Filed:\n';
      reportText += `${impact.reportsFiled}\n\n`;
    }
    if (impact.impactJournal) {
      reportText += 'Impact on Daily Life:\n';
      reportText += `${impact.impactJournal}\n\n`;
    }
    if (!impact.reportsFiled && !impact.impactJournal) {
      reportText += 'No impact documentation recorded.\n\n';
    }

    // Evidence
    reportText += '───────────────────────────────────────────────────\n';
    reportText += 'EVIDENCE FILES\n';
    reportText += '───────────────────────────────────────────────────\n\n';
    if (evidence.length > 0) {
      evidence.forEach((file: EvidenceFile, index: number) => {
        reportText += `[${index + 1}] ${file.fileName}\n`;
        reportText += `   Uploaded: ${new Date(file.uploadedAt).toLocaleString()}\n`;
        reportText += `   SHA-256 Hash: ${file.hash}\n\n`;
      });
      reportText += 'Note: SHA-256 hashes provide cryptographic proof that files\n';
      reportText += 'have not been altered since upload.\n\n';
    } else {
      reportText += 'No evidence files uploaded.\n\n';
    }

    reportText += '═══════════════════════════════════════════════════\n';
    reportText += '                 END OF REPORT\n';
    reportText += '═══════════════════════════════════════════════════\n';

    setReport(reportText);
    setGenerated(true);
    toast.success('Report generated successfully');
  };

  const handlePrint = () => {
    if (!report) {
      toast.error('Please generate a report first');
      return;
    }
    window.print();
  };

  return (
    <AppLayout>
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="space-y-4">
          <h1 className="text-3xl md:text-4xl font-light tracking-tight">Report</h1>
          <p className="text-lg text-muted-foreground">
            Generate a comprehensive summary of all documented information.
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-2xl font-light">Generate Incident Summary</CardTitle>
            <CardDescription>
              This will compile all your documented information into a formatted report that can be printed or saved as PDF.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex gap-4">
              <Button onClick={generateReport} className="gap-2">
                <FileText className="h-4 w-4" />
                Generate Incident Summary
              </Button>
              {generated && (
                <Button onClick={handlePrint} variant="secondary" className="gap-2">
                  <Printer className="h-4 w-4" />
                  Print / Save as PDF
                </Button>
              )}
            </div>

            {generated && (
              <div className="space-y-4">
                <div className="space-y-2">
                  <p className="text-sm font-medium">Generated Report</p>
                  <Textarea
                    value={report}
                    readOnly
                    rows={20}
                    className="font-mono text-xs resize-none"
                  />
                </div>
                <p className="text-xs text-muted-foreground">
                  You can copy this text or use the Print button to save as PDF. The report includes all identity information, timeline entries, impact documentation, and evidence file hashes.
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="bg-muted/50">
          <CardContent className="p-6 space-y-3">
            <p className="text-sm font-medium">What to do with this report:</p>
            <ul className="text-sm text-muted-foreground space-y-2 pl-4 list-disc">
              <li>Share with trusted adults (parents, guardians, teachers)</li>
              <li>Provide to law enforcement when filing a report</li>
              <li>Submit to school administrators or counselors</li>
              <li>Keep for your own records</li>
              <li>Use when seeking legal advice or support services</li>
            </ul>
          </CardContent>
        </Card>
      </div>

      <style>{`
        @media print {
          body * {
            visibility: hidden;
          }
          textarea {
            visibility: visible !important;
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            height: auto;
            border: none;
            padding: 1in;
            font-family: monospace;
            font-size: 10pt;
            white-space: pre-wrap;
          }
        }
      `}</style>
    </AppLayout>
  );
}
