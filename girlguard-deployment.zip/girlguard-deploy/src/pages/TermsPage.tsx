import { useNavigate } from 'react-router-dom';
import { Scale, AlertCircle, ExternalLink, Shield, Info, FileText } from 'lucide-react';
import PublicLayout from '@/components/layouts/PublicLayout';

const LAST_UPDATED = 'May 2025';

interface SectionProps {
  icon: React.ElementType;
  title: string;
  children: React.ReactNode;
}

function Section({ icon: Icon, title, children }: SectionProps) {
  return (
    <section className="space-y-3 opacity-0 intersect:opacity-100 transition duration-700">
      <div className="flex items-center gap-2">
        <Icon className="h-4 w-4 text-primary shrink-0" strokeWidth={1.75} />
        <h2 className="text-lg font-medium tracking-tight">{title}</h2>
      </div>
      <div className="text-sm text-muted-foreground space-y-2 leading-relaxed pl-6">
        {children}
      </div>
    </section>
  );
}

export default function TermsPage() {
  const navigate = useNavigate();

  return (
    <PublicLayout>
      <div className="max-w-3xl mx-auto space-y-10 p-4 md:p-8">

        {/* Header */}
        <div className="space-y-3">
          <div className="flex items-center gap-1.5">
            <Scale className="h-3 w-3 text-primary shrink-0" strokeWidth={2} />
            <p className="text-xs font-semibold tracking-widest uppercase text-muted-foreground">Legal</p>
          </div>
          <h1 className="text-3xl md:text-4xl font-light tracking-tight text-balance">Terms of Use</h1>
          <p className="text-sm text-muted-foreground">Last updated: {LAST_UPDATED}</p>
        </div>

        {/* Important notice banner */}
        <div className="rounded-xl border border-primary/25 bg-primary/5 p-4 flex items-start gap-3">
          <AlertCircle className="h-4 w-4 text-primary shrink-0 mt-0.5" strokeWidth={1.5} />
          <p className="text-sm text-foreground text-pretty leading-relaxed">
            By accessing or using girlGuard, you agree to these Terms of Use. If you do not agree,
            please do not use the platform. These terms are designed to protect both you and us.
          </p>
        </div>

        {/* Sections */}
        <Section icon={Info} title="About girlGuard">
          <p>
            girlGuard is a free, student-created educational platform designed to help young people —
            especially girls and teens — understand online safety, digital rights, and available
            support resources. It was created as a personal project by a 17-year-old and is not
            operated by any company, school, or government body.
          </p>
          <p>
            girlGuard is provided as-is, free of charge, for educational and informational
            purposes only.
          </p>
        </Section>

        <div className="border-t border-border" />

        <Section icon={FileText} title="Educational Purpose — Not Professional Advice">
          <p>
            <strong className="text-foreground">All content on girlGuard is for educational and
            informational purposes only.</strong> Nothing on this platform constitutes legal advice,
            medical advice, mental health advice, or any other form of professional advice.
          </p>
          <p>
            You should not rely on information from girlGuard as a substitute for professional
            consultation. Laws, regulations, and best practices change frequently. Always consult a
            qualified professional (lawyer, doctor, counsellor, or other specialist) for advice
            specific to your situation.
          </p>
          <p>
            Specifically, the following does not constitute professional advice:
          </p>
          <ul className="list-disc pl-4 space-y-1 text-muted-foreground">
            <li>Information about cybercrime laws or your legal rights</li>
            <li>Guidance on documenting or reporting incidents</li>
            <li>Mental health and emotional wellbeing content</li>
            <li>Safety tips and privacy recommendations</li>
            <li>Links to third-party organisations or resources</li>
          </ul>
        </Section>

        <div className="border-t border-border" />

        <Section icon={ExternalLink} title="Third-Party Links & Resources">
          <p>
            girlGuard links to external websites, organisations, and resources to help you find
            further support. We do not control, endorse, or take responsibility for the content,
            accuracy, privacy practices, or availability of any third-party website.
          </p>
          <p>
            External links are provided for convenience only. Clicking a link and leaving girlGuard
            means you are subject to that site's own terms and privacy policy. We encourage you to
            review those policies before sharing any personal information.
          </p>
          <p>
            We make every effort to link only to reputable, active sources, but links may become
            outdated or unavailable at any time. If you find a broken or inappropriate link, please
            let us know via the feedback form.
          </p>
        </Section>

        <div className="border-t border-border" />

        <Section icon={AlertCircle} title="Accuracy & Content Disclaimer">
          <p>
            We aim to provide accurate, up-to-date information, but we cannot guarantee the
            completeness or accuracy of any content on girlGuard. Information may be out of date,
            incomplete, or not applicable to your specific situation or jurisdiction.
          </p>
          <p>
            girlGuard is not liable for any loss, harm, or damage arising from reliance on
            information found on this platform. Use of this site is entirely at your own risk.
          </p>
        </Section>

        <div className="border-t border-border" />

        <Section icon={Shield} title="User Conduct">
          <p>By using girlGuard, you agree to:</p>
          <ul className="list-disc pl-4 space-y-1 text-muted-foreground">
            <li>Use the platform only for lawful, educational purposes</li>
            <li>Not attempt to misuse, hack, or disrupt the platform</li>
            <li>Not use any content to harass, harm, or deceive others</li>
            <li>Take responsibility for how you use the information provided</li>
          </ul>
          <p>
            Any documentation tools (evidence logs, timelines) are personal tools to help you
            organise your own information. girlGuard does not review, store server-side, or take
            responsibility for user-generated content.
          </p>
        </Section>

        <div className="border-t border-border" />

        <Section icon={Shield} title="Minors">
          <p>
            girlGuard is designed for use by teenagers and young adults. Users under 13 years of age
            should use the kidsGuard section only, which is specifically designed for ages 8–12.
          </p>
          <p>
            If you are a minor, we encourage you to discuss anything you learn on this platform with
            a trusted adult — a parent, guardian, teacher, or school counsellor.
          </p>
          <p>
            girlGuard does not knowingly collect personal data from users under 13. See our{' '}
            <button onClick={() => navigate('/privacy')}
              className="text-primary underline underline-offset-2 hover:opacity-80 transition-opacity">
              Privacy Policy
            </button>{' '}
            for details.
          </p>
        </Section>

        <div className="border-t border-border" />

        <Section icon={FileText} title="Intellectual Property">
          <p>
            All original content on girlGuard — including text, design, and code — is the
            intellectual property of the creator unless otherwise stated. You may share or print
            content for personal, non-commercial, educational use with appropriate attribution.
          </p>
          <p>
            You may not reproduce, republish, or redistribute content for commercial purposes
            without prior written permission.
          </p>
        </Section>

        <div className="border-t border-border" />

        <Section icon={Info} title="Changes to These Terms">
          <p>
            We may update these Terms of Use from time to time. The date at the top of this page
            reflects the most recent revision. Continued use of girlGuard after changes constitutes
            your acceptance of the updated terms.
          </p>
        </Section>

        <div className="border-t border-border" />

        <Section icon={Info} title="Contact">
          <p>
            If you have questions about these terms, or want to report an issue with the platform,
            please use the feedback form on the{' '}
            <button onClick={() => navigate('/public/info')}
              className="text-primary underline underline-offset-2 hover:opacity-80 transition-opacity">
              home page
            </button>.
          </p>
        </Section>

        {/* Footer note */}
        <div className="rounded-xl border border-border bg-muted/40 p-4 text-xs text-muted-foreground text-pretty leading-relaxed">
          © {new Date().getFullYear()} girlGuard. All rights reserved. This platform is an
          independent student project and is not affiliated with any government, school, or
          commercial organisation. See also our{' '}
          <button onClick={() => navigate('/privacy')}
            className="text-primary underline underline-offset-2 hover:opacity-80 transition-opacity">
            Privacy Policy
          </button>.
        </div>

      </div>
    </PublicLayout>
  );
}
