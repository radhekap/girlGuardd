import { useState } from 'react';
import AppLayout from '@/components/layouts/AppLayout';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { FileText, Calendar, Heart, FileCheck } from 'lucide-react';

// Import existing page content (we'll extract the content from these pages)
import EvidenceContent from '@/components/documentation/EvidenceContent';
import TimelineContent from '@/components/documentation/TimelineContent';
import ImpactContent from '@/components/documentation/ImpactContent';
import ReportContent from '@/components/documentation/ReportContent';

export default function DocumentationPage() {
  const [activeTab, setActiveTab] = useState('evidence');

  return (
    <AppLayout>
      <div className="max-w-6xl mx-auto space-y-8 animate-fade-in">
        <div className="space-y-4 text-center">
          <h1 className="text-4xl md:text-5xl font-light tracking-tight gradient-text">Documentation</h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Collect evidence, track incidents, record impact, and generate reports
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 md:grid-cols-4 h-auto gap-2 bg-transparent p-0">
            <TabsTrigger
              value="evidence"
              className="flex items-center gap-2 h-12 data-[state=active]:bg-gradient-primary data-[state=active]:text-white data-[state=active]:shadow-md transition-all border-2 border-transparent data-[state=active]:border-primary/30"
            >
              <FileText className="h-4 w-4" />
              <span>Evidence</span>
            </TabsTrigger>
            <TabsTrigger
              value="timeline"
              className="flex items-center gap-2 h-12 data-[state=active]:bg-gradient-primary data-[state=active]:text-white data-[state=active]:shadow-md transition-all border-2 border-transparent data-[state=active]:border-primary/30"
            >
              <Calendar className="h-4 w-4" />
              <span>Timeline</span>
            </TabsTrigger>
            <TabsTrigger
              value="impact"
              className="flex items-center gap-2 h-12 data-[state=active]:bg-gradient-primary data-[state=active]:text-white data-[state=active]:shadow-md transition-all border-2 border-transparent data-[state=active]:border-primary/30"
            >
              <Heart className="h-4 w-4" />
              <span>Impact</span>
            </TabsTrigger>
            <TabsTrigger
              value="report"
              className="flex items-center gap-2 h-12 data-[state=active]:bg-gradient-primary data-[state=active]:text-white data-[state=active]:shadow-md transition-all border-2 border-transparent data-[state=active]:border-primary/30"
            >
              <FileCheck className="h-4 w-4" />
              <span>Report</span>
            </TabsTrigger>
          </TabsList>

          <div className="mt-8">
            <TabsContent value="evidence" className="mt-0 animate-fade-in">
              <EvidenceContent />
            </TabsContent>

            <TabsContent value="timeline" className="mt-0 animate-fade-in">
              <TimelineContent />
            </TabsContent>

            <TabsContent value="impact" className="mt-0 animate-fade-in">
              <ImpactContent />
            </TabsContent>

            <TabsContent value="report" className="mt-0 animate-fade-in">
              <ReportContent />
            </TabsContent>
          </div>
        </Tabs>
      </div>
    </AppLayout>
  );
}
