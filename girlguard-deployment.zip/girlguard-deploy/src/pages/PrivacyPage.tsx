import { useNavigate } from 'react-router-dom';
import { Lock, AlertCircle, Eye, Shield, Info, Database } from 'lucide-react';
import PublicLayout from '@/components/layouts/PublicLayout';

const LAST_UPDATED = 'May 2025';

interface SectionProps {
  icon: React.ElementType;
  title: string;
  children: React.ReactNode;
}

function Section({ icon: Icon, title, children }: SectionProps) {
  return (
    <section className="space-y-3 opacity-0 intersect:opacity-100 transition duration-700">
      <div className="flex items-center gap-2">
        <Icon className="h-4 w-4 text-primary shrink-0" strokeWidth={1.75} />
        <h2 className="text-lg font-medium tracking-tight">{title}</h2>
      </div>
      <div className="text-sm text-muted-foreground space-y-2 leading-relaxed pl-6">
        {children}
      </div>
    </section>
  );
}

export default function PrivacyPage() {
  const navigate = useNavigate();

  return (
    <PublicLayout>
      <div className="max-w-3xl mx-auto space-y-10 p-4 md:p-8">

        {/* Header */}
        <div className="space-y-3">
          <div className="flex items-center gap-1.5">
            <Lock className="h-3 w-3 text-primary shrink-0" strokeWidth={2} />
            <p className="text-xs font-semibold tracking-widest uppercase text-muted-foreground">Legal</p>
          </div>
          <h1 className="text-3xl md:text-4xl font-light tracking-tight text-balance">Privacy Policy</h1>
          <p className="text-sm text-muted-foreground">Last updated: {LAST_UPDATED}</p>
        </div>

        {/* Summary banner */}
        <div className="rounded-xl border border-primary/25 bg-primary/5 p-4 flex items-start gap-3">
          <Shield className="h-4 w-4 text-primary shrink-0 mt-0.5" strokeWidth={1.5} />
          <div className="space-y-1">
            <p className="text-sm font-medium text-foreground">Your privacy matters</p>
            <p className="text-sm text-muted-foreground text-pretty leading-relaxed">
              girlGuard collects as little data as possible. We never sell your data.
              We never share it with advertisers. This policy explains exactly what we do collect
              and why.
            </p>
          </div>
        </div>

        {/* Sections */}
        <Section icon={Info} title="Who We Are">
          <p>
            girlGuard is a free, student-created educational platform about online safety. It is
            an independent personal project — not operated by a company, school, or commercial
            organisation. References to "we", "us", or "our" refer to the individual creator of
            girlGuard.
          </p>
        </Section>

        <div className="border-t border-border" />

        <Section icon={Database} title="What Data We Collect">
          <p>
            <strong className="text-foreground">Public visitors (no account):</strong>
          </p>
          <ul className="list-disc pl-4 space-y-1 text-muted-foreground">
            <li>No personal data is collected from visitors who do not create an account.</li>
            <li>
              Your browser may store theme preferences and accessibility settings in{' '}
              <code className="text-xs bg-muted px-1 py-0.5 rounded">localStorage</code> — this
              stays on your device only and is never sent to us.
            </li>
            <li>Standard web server logs may record your IP address and browser type for
              security and debugging. These are not used for profiling or advertising.</li>
          </ul>

          <p className="pt-1">
            <strong className="text-foreground">Registered users (optional account):</strong>
          </p>
          <ul className="list-disc pl-4 space-y-1 text-muted-foreground">
            <li>
              <strong className="text-foreground">Email address</strong> — used to create and
              manage your account. We do not send marketing emails.
            </li>
            <li>
              <strong className="text-foreground">Password (hashed)</strong> — stored securely via
              Supabase Auth. We never see your plain-text password.
            </li>
            <li>
              <strong className="text-foreground">Display name</strong> — if you choose to provide
              one.
            </li>
            <li>
              <strong className="text-foreground">Documentation content</strong> — evidence logs,
              timelines, and impact statements you create are stored in your account only and are
              visible only to you.
            </li>
          </ul>

          <p className="pt-1">
            <strong className="text-foreground">We do not collect:</strong>
          </p>
          <ul className="list-disc pl-4 space-y-1 text-muted-foreground">
            <li>Location or GPS data</li>
            <li>Phone numbers</li>
            <li>Biometric data</li>
            <li>Payment information (the platform is entirely free)</li>
            <li>Social media profiles or third-party account data</li>
          </ul>
        </Section>

        <div className="border-t border-border" />

        <Section icon={Eye} title="How We Use Your Data">
          <p>We use the data we collect only to:</p>
          <ul className="list-disc pl-4 space-y-1 text-muted-foreground">
            <li>Provide and maintain your account and saved content</li>
            <li>Authenticate your login securely</li>
            <li>Fix bugs and improve the platform</li>
          </ul>
          <p>
            We do <strong className="text-foreground">not</strong> use your data for advertising,
            behavioural profiling, or any commercial purpose. We do not sell, rent, or share your
            personal information with third parties for their own purposes.
          </p>
        </Section>

        <div className="border-t border-border" />

        <Section icon={Shield} title="Data Storage & Security">
          <p>
            Registered user data is stored using{' '}
            <a href="https://supabase.com" target="_blank" rel="noopener noreferrer"
              className="text-primary underline underline-offset-2 hover:opacity-80 transition-opacity">
              Supabase
            </a>
            , a secure cloud database platform. Supabase encrypts data in transit (TLS) and at
            rest.
          </p>
          <p>
            Passwords are hashed using industry-standard algorithms — we never store or see your
            plain-text password.
          </p>
          <p>
            Despite reasonable precautions, no internet transmission or electronic storage is
            completely secure. We cannot guarantee absolute security. If you believe your account
            has been compromised, please change your password immediately.
          </p>
          <p>
            <strong className="text-foreground">Documentation content you create</strong> (evidence
            logs, timelines, etc.) is private to your account. We do not review, share, or use it
            for any purpose. If you delete your account, this content is deleted.
          </p>
        </Section>

        <div className="border-t border-border" />

        <Section icon={Database} title="Cookies & Local Storage">
          <p>girlGuard uses the following browser storage:</p>
          <ul className="list-disc pl-4 space-y-1 text-muted-foreground">
            <li>
              <strong className="text-foreground">theme-mode</strong> — stores your chosen visual
              theme. Stays on your device only.
            </li>
            <li>
              <strong className="text-foreground">Authentication tokens</strong> — if you log in,
              a secure session token is stored to keep you logged in. You can clear this by logging
              out.
            </li>
          </ul>
          <p>
            We do not use advertising cookies, tracking pixels, or third-party analytics cookies.
          </p>
        </Section>

        <div className="border-t border-border" />

        <Section icon={AlertCircle} title="Children & COPPA Compliance">
          <p>
            girlGuard is designed for teenagers and young adults. The kidsGuard section is intended
            for children aged 8–12.
          </p>
          <p>
            <strong className="text-foreground">We do not knowingly collect personal data from
            children under 13.</strong> Account registration is not available for children under 13.
            If you are a parent or guardian and believe your child under 13 has registered for an
            account, please contact us immediately so we can delete their information.
          </p>
          <p>
            For children aged 13–17, we recommend using girlGuard with parental awareness.
            Parents or guardians may contact us at any time to request deletion of their teen's
            account data.
          </p>
        </Section>

        <div className="border-t border-border" />

        <Section icon={Shield} title="Your Rights (GDPR & General)">
          <p>
            Depending on where you live, you may have certain rights regarding your personal data:
          </p>
          <ul className="list-disc pl-4 space-y-1 text-muted-foreground">
            <li><strong className="text-foreground">Access</strong> — request a copy of the data we hold about you</li>
            <li><strong className="text-foreground">Correction</strong> — ask us to correct inaccurate data</li>
            <li><strong className="text-foreground">Deletion</strong> — request that we delete your account and all associated data</li>
            <li><strong className="text-foreground">Restriction</strong> — ask us to stop processing your data in certain ways</li>
            <li><strong className="text-foreground">Portability</strong> — request your data in a portable format</li>
          </ul>
          <p>
            To exercise any of these rights, please use the feedback form on the home page. We will
            respond within 30 days.
          </p>
        </Section>

        <div className="border-t border-border" />

        <Section icon={Info} title="Third-Party Services">
          <p>girlGuard uses the following third-party services:</p>
          <ul className="list-disc pl-4 space-y-1 text-muted-foreground">
            <li>
              <strong className="text-foreground">Supabase</strong> — database, authentication,
              and file storage.{' '}
              <a href="https://supabase.com/privacy" target="_blank" rel="noopener noreferrer"
                className="text-primary underline underline-offset-2 hover:opacity-80 transition-opacity">
                Supabase Privacy Policy ↗
              </a>
            </li>
          </ul>
          <p>
            We link to many external websites and organisations. Visiting those sites means you are
            subject to their own privacy policies. We have no control over their data practices.
          </p>
        </Section>

        <div className="border-t border-border" />

        <Section icon={Info} title="Changes to This Policy">
          <p>
            We may update this Privacy Policy from time to time. The date at the top of the page
            reflects the most recent revision. We encourage you to review this page periodically.
            Continued use of girlGuard after changes constitutes acceptance of the updated policy.
          </p>
        </Section>

        <div className="border-t border-border" />

        <Section icon={Info} title="Contact">
          <p>
            For privacy-related questions, data requests, or to report a concern, please use the
            feedback form on the{' '}
            <button onClick={() => navigate('/public/info')}
              className="text-primary underline underline-offset-2 hover:opacity-80 transition-opacity">
              home page
            </button>.
          </p>
        </Section>

        {/* Footer note */}
        <div className="rounded-xl border border-border bg-muted/40 p-4 text-xs text-muted-foreground text-pretty leading-relaxed">
          © {new Date().getFullYear()} girlGuard. All rights reserved. This platform is an
          independent student project. See also our{' '}
          <button onClick={() => navigate('/terms')}
            className="text-primary underline underline-offset-2 hover:opacity-80 transition-opacity">
            Terms of Use
          </button>.
        </div>

      </div>
    </PublicLayout>
  );
}
