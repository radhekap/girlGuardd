import PublicLayout from'@/components/layouts/PublicLayout';
import { useState } from'react';
import { Lock, Eye, Wifi, Brain, Lightbulb, RefreshCw, CheckCircle, XCircle, Gamepad2, Trophy, Star, ShieldCheck } from'lucide-react';

// ─── PALETTE ─────────────────────────────────────────────────────────────────
const G = {
  grad:'linear-gradient(135deg, #FF6B9D 0%, #B794F6 100%)',
};

// ─── DATA: PASSWORD GAME ─────────────────────────────────────────────────────
const passwordChallenges = [
  { password:'emma2008',       strength: 0, why: "Uses your name + birth year — way too easy to guess. Never use personal info!" },
  { password:'password123',    strength: 0, why:'"password" + numbers is literally the most common password ever. Change it immediately!' },
  { password:'HappyCat!',      strength: 1, why: "Getting better! Mix of uppercase, lowercase and symbol — but only 9 chars. Still crackable." },
  { password:'S@lt&P3pp3r!',   strength: 2, why: "Strong! Good length, mixed case, numbers and symbols. Hard to crack " },
  { password:'flower',         strength: 0, why: "Simple dictionary word — hackers run programs that try every word in seconds. Too weak!" },
  { password:'iL0ve2Dance#99', strength: 2, why: "Great password! A memorable phrase with substitutions, numbers and a symbol = very strong " },
];

// ─── DATA: REAL OR FAKE ───────────────────────────────────────────────────────
const realOrFakeHeadlines = [
  { headline:'"Scientists discover tomatoes can reduce heart disease risk"',              real: true,  why: "Real — backed by multiple nutritional studies. Specific, verifiable claim." },
  { headline:'"Government secretly adding memory-erasing chemicals to tap water"',       real: false, why: "Fake — classic conspiracy language. No evidence, no named scientists." },
  { headline:'"Australia introduces new rules for social media age verification"',       real: true,  why: "Real — genuine policy area several governments have been actively legislating." },
  { headline:'"Teen goes viral after local school bans TikTok on campus Wi-Fi"',         real: true,  why: "Real — schools globally have been restricting social media access." },
  { headline:'"NASA confirms aliens made first contact — governments hiding it"',        real: false, why: "Fake — if NASA confirmed this, every credible outlet would cover it." },
  { headline:'"Eating breakfast does not noticeably boost school performance, study finds"', real: true, why: "Real — counter-intuitive findings like this often come from genuine research." },
];

// ─── DATA: PHISHING ───────────────────────────────────────────────────────────
const phishingMessages = [
  {
    sender:'support@instag-ram.co',
    subject:'Your account will be deleted in 24 hours',
    body:'We noticed suspicious activity. Click here immediately to verify your identity and save your account. Enter your password to confirm.',
    isPhish: true,
    clues: ["Wrong domain —'instag-ram.co' not'instagram.com'", "Urgency tactic ('24 hours')", "Asks for your password — real platforms never do this"],
  },
  {
    sender:'noreply@myschool.edu.au',
    subject:'Term 3 timetable update',
    body:'Hi students, your updated timetable for Term 3 is now available on the school portal. Log in at portal.myschool.edu.au to view it.',
    isPhish: false,
    clues: ["Legitimate school domain", "Directs to official portal (not a random link)", "No urgency, no password request — just routine info"],
  },
  {
    sender:'prizes@win-now365.net',
    subject:'You\'ve been selected! Claim your $500 gift card',
    body: "Congratulations! You are our lucky winner. To claim your prize, click the link and provide your full name, address, and card details within 2 hours.",
    isPhish: true,
    clues: ["Suspicious domain", "Asks for address AND card details", "You never entered a competition — you can't win one you didn't enter"],
  },
  {
    sender:'hello@spotify.com',
    subject:'Your December Wrapped is ready',
    body: "It's that time of year! See your most-played songs, artists and podcasts of the year. Head to your app or spotify.com/wrapped to check it out.",
    isPhish: false,
    clues: ["Legitimate spotify.com sender", "No password or personal info requested", "Directs to main domain, not a third-party link"],
  },
];

// ─── DATA: WORD MATCH ────────────────────────────────────────────────────────
const wordMatchPairs = [
  { term:'2FA',          def:'A second check (like a text code) on top of your password' },
  { term:'Phishing',     def:'Fake messages designed to trick you into giving info' },
  { term:'VPN',          def:'Encrypts your internet traffic and hides your location' },
  { term:'Encryption',   def:'Scrambles data so only the right person can read it' },
  { term:'Privacy mode', def: "Stops your browser saving history — but doesn't hide you online" },
  { term:'Doxxing',      def: "Publicly posting someone's private info to harm or harass them" },
];

// ─── GAME: PASSWORD STRENGTH ─────────────────────────────────────────────────
function PasswordGame() {
  const [idx, setIdx] = useState(0);
  const [revealed, setRevealed] = useState(false);
  const [chosen, setChosen] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [done, setDone] = useState(false);
  const item = passwordChallenges[idx];
  const labels = [' Weak',' Okay',' Strong'];
  const colors = ['text-destructive','text-yellow-600 dark:text-yellow-400','text-green-600 dark:text-green-400'];
  const bgs    = ['border-destructive/40 bg-destructive/5','border-yellow-400/40 bg-yellow-50 dark:bg-yellow-950/30','border-green-500/40 bg-green-50 dark:bg-green-950/30'];
  const guess = (val: number) => { if (revealed) return; setChosen(val); setRevealed(true); if (val === item.strength) setScore(s => s + 1); };
  const next = () => { if (idx + 1 >= passwordChallenges.length) { setDone(true); return; } setIdx(i => i + 1); setRevealed(false); setChosen(null); };
  const restart = () => { setIdx(0); setRevealed(false); setChosen(null); setScore(0); setDone(false); };
  if (done) return (
    <div className="text-center space-y-3 py-2">
      <div className="flex justify-center">{score >= 5 ? <Trophy className="h-9 w-9 text-primary" strokeWidth={1.5}/> : score >= 3 ? <Star className="h-9 w-9 text-primary" strokeWidth={1.5}/> : <ShieldCheck className="h-9 w-9 text-primary" strokeWidth={1.5}/>}</div>
      <p className="text-base font-medium">{score} / {passwordChallenges.length} correct</p>
      <p className="text-sm text-muted-foreground text-pretty">{score >= 5 ?'Password expert!' : score >= 3 ?'Good instincts! Review tips to level up.' :'Password knowledge is one of the most important online skills.'}</p>
      <button onClick={restart} className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg border border-border text-sm text-muted-foreground hover:text-foreground hover:bg-muted transition-colors group">
        <RefreshCw className="h-3.5 w-3.5 group-hover:rotate-180 transition-transform duration-300" /> Try again
      </button>
    </div>
  );
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between text-xs text-muted-foreground">
        <span>Password {idx + 1} of {passwordChallenges.length}</span>
        <span className="font-medium text-foreground">{score} correct</span>
      </div>
      <div className="h-1 rounded-full bg-muted overflow-hidden">
        <div className="h-full rounded-full transition-all duration-500" style={{ width: `${(idx / passwordChallenges.length) * 100}%`, background: G.grad }} />
      </div>
      <div className="rounded-lg border border-border bg-muted/40 px-4 py-3 font-mono text-sm font-medium tracking-wide">{item.password}</div>
      <div className="grid grid-cols-3 gap-2">
        {labels.map((label, i) => (
          <button key={i} onClick={() => guess(i)} disabled={revealed}
            className={['py-2.5 px-2 rounded-lg border text-sm font-medium transition-all',
              revealed && i === item.strength ? bgs[i] + ' ' + colors[i] : '',
              revealed && chosen === i && i !== item.strength ?'border-destructive/40 bg-destructive/5 text-destructive line-through opacity-70' : '',
              !revealed ?'border-border bg-card text-muted-foreground hover:border-primary/40 hover:bg-primary/5 hover:text-foreground' : '',
            ].join(' ')}>{label}</button>
        ))}
      </div>
      {revealed && (
        <div className="rounded-lg border border-border bg-muted/40 p-4 space-y-3">
          <div className="flex items-start gap-2">
            <Lightbulb className="h-4 w-4 shrink-0 text-primary mt-0.5" strokeWidth={1.5} />
            <p className="text-xs text-muted-foreground leading-relaxed text-pretty">{item.why}</p>
          </div>
          <button onClick={next} className="w-full py-2.5 rounded-lg text-sm font-medium text-primary-foreground bg-primary hover:opacity-90 transition-opacity">
            {idx + 1 < passwordChallenges.length ?'Next password →' :'See my score →'}
          </button>
        </div>
      )}
    </div>
  );
}

// ─── GAME: REAL OR FAKE ───────────────────────────────────────────────────────
function RealOrFakeGame() {
  const [idx, setIdx] = useState(0);
  const [revealed, setRevealed] = useState(false);
  const [choice, setChoice] = useState<boolean | null>(null);
  const [score, setScore] = useState(0);
  const [done, setDone] = useState(false);
  const item = realOrFakeHeadlines[idx];
  const guess = (val: boolean) => { if (revealed) return; setChoice(val); setRevealed(true); if (val === item.real) setScore(s => s + 1); };
  const next = () => { if (idx + 1 >= realOrFakeHeadlines.length) { setDone(true); return; } setIdx(i => i + 1); setRevealed(false); setChoice(null); };
  const restart = () => { setIdx(0); setRevealed(false); setChoice(null); setScore(0); setDone(false); };
  if (done) return (
    <div className="text-center space-y-3 py-2">
      <div className="flex justify-center">{score >= 5 ? <Trophy className="h-9 w-9 text-primary" strokeWidth={1.5}/> : score >= 3 ? <Star className="h-9 w-9 text-primary" strokeWidth={1.5}/> : <ShieldCheck className="h-9 w-9 text-primary" strokeWidth={1.5}/>}</div>
      <p className="text-base font-medium">{score} / {realOrFakeHeadlines.length} correct</p>
      <p className="text-sm text-muted-foreground text-pretty">{score >= 5 ? "News detective! You can spot misinformation like a pro." : score >= 3 ? "Decent radar! Some tricky ones." : "Misinformation is designed to fool smart people — keep practising!"}</p>
      <button onClick={restart} className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg border border-border text-sm text-muted-foreground hover:text-foreground hover:bg-muted transition-colors group">
        <RefreshCw className="h-3.5 w-3.5 group-hover:rotate-180 transition-transform duration-300" /> Try again
      </button>
    </div>
  );
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between text-xs text-muted-foreground">
        <span>Headline {idx + 1} of {realOrFakeHeadlines.length}</span>
        <span className="font-medium text-foreground">{score} correct</span>
      </div>
      <div className="h-1 rounded-full bg-muted overflow-hidden">
        <div className="h-full rounded-full transition-all duration-500" style={{ width: `${(idx / realOrFakeHeadlines.length) * 100}%`, background: G.grad }} />
      </div>
      <div className="rounded-lg border border-border bg-card p-4"><p className="text-sm italic leading-relaxed">{item.headline}</p></div>
      {!revealed ? (
        <div className="grid grid-cols-2 gap-3">
          <button onClick={() => guess(true)} className="py-3 rounded-lg border border-green-400/40 bg-green-50 dark:bg-green-950/30 text-sm font-medium text-green-700 dark:text-green-400 hover:opacity-90 transition-opacity">Real</button>
          <button onClick={() => guess(false)} className="py-3 rounded-lg border border-destructive/40 bg-destructive/5 text-sm font-medium text-destructive hover:opacity-90 transition-opacity">Fake</button>
        </div>
      ) : (
        <div className="space-y-3">
          <div className={['rounded-lg px-4 py-3 text-sm font-medium flex items-center gap-2', item.real ?'border border-green-400/40 bg-green-50 dark:bg-green-950/30 text-green-700 dark:text-green-400' :'border border-destructive/40 bg-destructive/5 text-destructive'].join(' ')}>
            {item.real ? <CheckCircle className="h-4 w-4 shrink-0" /> : <XCircle className="h-4 w-4 shrink-0" />}
            {item.real ?'Real!' :'Fake!'}{choice === item.real ? ' You got it' : ' Tricky one — keep going!'}
          </div>
          <div className="rounded-lg border border-border bg-muted/40 p-3"><p className="text-xs font-medium mb-1">Why?</p><p className="text-xs text-muted-foreground leading-relaxed text-pretty">{item.why}</p></div>
          <button onClick={next} className="w-full py-2.5 rounded-lg text-sm font-medium text-primary-foreground bg-primary hover:opacity-90 transition-opacity">
            {idx + 1 < realOrFakeHeadlines.length ?'Next headline →' :'See my score →'}
          </button>
        </div>
      )}
    </div>
  );
}

// ─── GAME: SPOT THE PHISH ────────────────────────────────────────────────────
function SpotThePhish() {
  const [idx, setIdx] = useState(0);
  const [revealed, setRevealed] = useState(false);
  const [choice, setChoice] = useState<boolean | null>(null);
  const [score, setScore] = useState(0);
  const [done, setDone] = useState(false);
  const item = phishingMessages[idx];
  const guess = (val: boolean) => { if (revealed) return; setChoice(val); setRevealed(true); if (val === item.isPhish) setScore(s => s + 1); };
  const next = () => { if (idx + 1 >= phishingMessages.length) { setDone(true); return; } setIdx(i => i + 1); setRevealed(false); setChoice(null); };
  const restart = () => { setIdx(0); setRevealed(false); setChoice(null); setScore(0); setDone(false); };
  if (done) return (
    <div className="text-center space-y-3 py-2">
      <div className="flex justify-center">{score >= 3 ? <Trophy className="h-9 w-9 text-primary" strokeWidth={1.5}/> : <ShieldCheck className="h-9 w-9 text-primary" strokeWidth={1.5}/>}</div>
      <p className="text-base font-medium">{score} / {phishingMessages.length} caught</p>
      <p className="text-sm text-muted-foreground text-pretty">{score >= 3 ? "Great phish detector!" : "Phishing fools millions — keep building your radar."}</p>
      <button onClick={restart} className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg border border-border text-sm text-muted-foreground hover:text-foreground hover:bg-muted transition-colors group">
        <RefreshCw className="h-3.5 w-3.5 group-hover:rotate-180 transition-transform duration-300" /> Try again
      </button>
    </div>
  );
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between text-xs text-muted-foreground">
        <span>Message {idx + 1} of {phishingMessages.length}</span>
        <span className="font-medium text-foreground">{score} caught</span>
      </div>
      <div className="rounded-lg border border-border bg-card overflow-hidden text-xs">
        <div className="px-4 py-3 border-b border-border bg-muted/40 space-y-1">
          <p className="text-muted-foreground"><span className="font-medium text-foreground">From: </span>{item.sender}</p>
          <p className="text-muted-foreground"><span className="font-medium text-foreground">Subject: </span>{item.subject}</p>
        </div>
        <p className="px-4 py-3 leading-relaxed">{item.body}</p>
      </div>
      {!revealed ? (
        <div className="grid grid-cols-2 gap-3">
          <button onClick={() => guess(true)} className="py-3 rounded-lg border border-destructive/40 bg-destructive/5 text-sm font-medium text-destructive hover:opacity-90 transition-opacity">Phishing</button>
          <button onClick={() => guess(false)} className="py-3 rounded-lg border border-green-400/40 bg-green-50 dark:bg-green-950/30 text-sm font-medium text-green-700 dark:text-green-400 hover:opacity-90 transition-opacity">Legit</button>
        </div>
      ) : (
        <div className="space-y-3">
          <div className={['rounded-lg px-4 py-3 text-sm font-medium flex items-center gap-2', item.isPhish ?'border border-destructive/40 bg-destructive/5 text-destructive' :'border border-green-400/40 bg-green-50 dark:bg-green-950/30 text-green-700 dark:text-green-400'].join(' ')}>
            {item.isPhish ?'Phishing!' :'Legit!'}{choice === item.isPhish ? ' You got it' : ' Nearly — check the clues!'}
          </div>
          <div className="rounded-lg border border-border bg-muted/40 p-3 space-y-2">
            <p className="text-xs font-medium">Clues to look for:</p>
            <ul className="space-y-1">{item.clues.map((c, i) => <li key={i} className="text-xs text-muted-foreground flex items-start gap-1.5"><span className="shrink-0 text-primary mt-0.5">•</span>{c}</li>)}</ul>
          </div>
          <button onClick={next} className="w-full py-2.5 rounded-lg text-sm font-medium text-primary-foreground bg-primary hover:opacity-90 transition-opacity">
            {idx + 1 < phishingMessages.length ?'Next message →' :'See my score →'}
          </button>
        </div>
      )}
    </div>
  );
}

// ─── GAME: WORD MATCH ────────────────────────────────────────────────────────
function WordMatchGame() {
  const [matches, setMatches] = useState<Record<string, string>>({});
  const [revealed, setRevealed] = useState(false);
  const [selectedTerm, setSelectedTerm] = useState<string | null>(null);
  const [defs] = useState(() => [...wordMatchPairs.map(p => p.def)].sort(() => Math.random() - 0.5));
  const selectTerm = (term: string) => { if (revealed) return; setSelectedTerm(prev => prev === term ? null : term); };
  const selectDef = (def: string) => { if (revealed || !selectedTerm) return; setMatches(m => ({ ...m, [selectedTerm]: def })); setSelectedTerm(null); };
  const correctCount = wordMatchPairs.filter(p => matches[p.term] === p.def).length;
  const allMatched = Object.keys(matches).length >= wordMatchPairs.length;
  const getTermColor = (term: string) => {
    if (!revealed) return selectedTerm === term ?'border-primary/60 bg-primary/10 text-primary' : matches[term] ?'border-primary/30 bg-primary/5' :'border-border bg-card hover:border-primary/30';
    return matches[term] === wordMatchPairs.find(p => p.term === term)?.def ?'border-green-500/50 bg-green-50 dark:bg-green-950/30 text-green-700 dark:text-green-400' :'border-destructive/40 bg-destructive/5 text-destructive';
  };
  const getDefColor = (def: string) => {
    if (!revealed) return Object.values(matches).includes(def) ?'border-primary/30 bg-primary/5 opacity-60' :'border-border bg-card hover:border-primary/30 cursor-pointer';
    const matchedTerm = Object.keys(matches).find(k => matches[k] === def);
    if (!matchedTerm) return'border-border bg-muted/30 opacity-50';
    return wordMatchPairs.find(p => p.term === matchedTerm)?.def === def ?'border-green-500/50 bg-green-50 dark:bg-green-950/30' :'border-destructive/40 bg-destructive/5';
  };
  return (
    <div className="space-y-4">
      <p className="text-xs text-muted-foreground">{revealed ? `${correctCount} / ${wordMatchPairs.length} matched correctly!` : selectedTerm ? `"${selectedTerm}" selected — pick its definition` :'Select a term, then match it to its definition'}</p>
      <div className="grid grid-cols-2 gap-3 items-start">
        <div className="space-y-2">{wordMatchPairs.map(({ term }) => <button key={term} onClick={() => selectTerm(term)} disabled={revealed} className={['w-full text-left px-3 py-2.5 rounded-lg border text-xs font-medium transition-colors', getTermColor(term)].join(' ')}>{term}{matches[term] && !revealed && <span className="ml-1 text-primary/60">↔</span>}</button>)}</div>
        <div className="space-y-2">{defs.map(def => <button key={def} onClick={() => selectDef(def)} disabled={revealed || Object.values(matches).includes(def)} className={['w-full text-left px-3 py-2.5 rounded-lg border text-xs leading-snug transition-colors', getDefColor(def)].join(' ')}>{def}</button>)}</div>
      </div>
      {!revealed ? (
        <button disabled={!allMatched} onClick={() => setRevealed(true)} className="w-full py-2.5 rounded-lg text-sm font-medium text-primary-foreground bg-primary hover:opacity-90 disabled:opacity-40 disabled:cursor-not-allowed transition-opacity">
          {allMatched ?'Check my matches →' : `Match ${wordMatchPairs.length - Object.keys(matches).length} more`}
        </button>
      ) : (
        <button onClick={() => { setMatches({}); setRevealed(false); setSelectedTerm(null); }} className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg border border-border text-sm text-muted-foreground hover:text-foreground hover:bg-muted transition-colors group">
          <RefreshCw className="h-3.5 w-3.5 group-hover:rotate-180 transition-transform duration-300" /> Try again
        </button>
      )}
    </div>
  );
}

// ─── GAME CARD META ───────────────────────────────────────────────────────────
const gameMeta = [
  { icon: Lock,  grad: G.grad,                                           title:'Rate that password',   sub:'Weak, okay, or strong?',              rounds:'6 rounds',  component: <PasswordGame /> },
  { icon: Eye,   grad:'linear-gradient(135deg, #B794F6 0%, #FF6B9D 100%)', title:'Real or fake?',       sub:'Spot the misinformation',             rounds:'6 rounds',  component: <RealOrFakeGame /> },
  { icon: Wifi,  grad: G.grad,                                           title:'Spot the phish',   sub:'Phishing email or legit?',            rounds:'4 rounds',  component: <SpotThePhish /> },
  { icon: Brain, grad:'linear-gradient(135deg, #B794F6 0%, #FF6B9D 100%)', title:'Digital vocab match', sub:'Match the term to its meaning',      rounds:'6 terms',   component: <WordMatchGame /> },
];

// ─── PAGE ─────────────────────────────────────────────────────────────────────
export default function PublicGamesPage() {
  return (
    <PublicLayout>
      <div className="max-w-5xl mx-auto px-2 md:px-4 space-y-10 py-2">

        {/* Header */}
        <div className="space-y-2 opacity-0 intersect:opacity-100 transition duration-700">
          <div className="flex items-center gap-2">
            <Gamepad2 className="h-4 w-4 text-primary" strokeWidth={1.75} />
            <p className="text-xs font-semibold tracking-widest uppercase text-muted-foreground">Play &amp; Learn</p>
          </div>
          <h1 className="text-2xl md:text-3xl font-light tracking-tight text-balance">
            Digital literacy games 
          </h1>
          <p className="text-sm text-muted-foreground text-pretty max-w-xl">
            Quick, fun activities that teach real skills — passwords, fake news, phishing, and digital vocab.
            No account needed. Just play.
          </p>
          <div className="flex flex-wrap gap-2 pt-1">
            {[
              { emoji:'', label:'Passwords',  color:'bg-pink-50 dark:bg-pink-950/30 border-pink-200 dark:border-pink-800 text-pink-700 dark:text-pink-300' },
              { emoji:'', label:'Fake news',  color:'bg-purple-50 dark:bg-purple-950/30 border-purple-200 dark:border-purple-800 text-purple-700 dark:text-purple-300' },
              { emoji:'', label:'Phishing',   color:'bg-blue-50 dark:bg-blue-950/30 border-blue-200 dark:border-blue-800 text-blue-700 dark:text-blue-300' },
              { emoji:'', label:'Vocab',      color:'bg-green-50 dark:bg-green-950/30 border-green-200 dark:border-green-800 text-green-700 dark:text-green-300' },
            ].map(({ emoji, label, color }) => (
              <span key={label} className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full border text-xs font-medium ${color}`}>
                {emoji} {label}
              </span>
            ))}
          </div>
        </div>

        {/* Game cards grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {gameMeta.map(({ icon: Icon, grad, title, sub, rounds, component }, i) => (
            <div key={title}
              className="rounded-lg border border-border bg-card overflow-hidden flex flex-col
                         opacity-0 intersect:opacity-100 transition duration-700"
              style={{ transitionDelay: `${i * 80}ms` }}>
              {/* Card header */}
              <div className="flex items-center gap-3 px-5 py-4 border-b border-border bg-muted/30">
                <div className="h-9 w-9 rounded-lg flex items-center justify-center shrink-0"
                  style={{ background: grad }}>
                  <Icon className="h-4 w-4 text-white" strokeWidth={2} />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium text-foreground leading-tight">{title}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">{sub}</p>
                </div>
                <span className="text-xs text-muted-foreground border border-border bg-background rounded-full px-2.5 py-1 shrink-0">
                  {rounds}
                </span>
              </div>
              {/* Game body */}
              <div className="p-5 flex-1">
                {component}
              </div>
            </div>
          ))}
        </div>

        {/* Footer note */}
        <div className="rounded-lg border border-border bg-muted/30 px-5 py-4 flex items-start gap-3
                        opacity-0 intersect:opacity-100 transition duration-700">
          <Gamepad2 className="h-4 w-4 text-primary shrink-0 mt-0.5" strokeWidth={1.5} />
          <p className="text-xs text-muted-foreground text-pretty">
            <span className="font-medium text-foreground">More activities coming soon.</span>{' '}
            These games are here to make digital literacy feel approachable — not stressful.
            Play as many times as you like; no scores are saved anywhere.
          </p>
        </div>
      </div>
    </PublicLayout>
  );
}
