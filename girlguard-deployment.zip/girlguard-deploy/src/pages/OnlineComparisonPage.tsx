import { useState, useEffect, useRef } from 'react';
import { Instagram, TrendingDown, Brain, Heart, Shield, Sparkles, Users, BookOpen, Dumbbell, Clock, Eye, ChevronRight, RotateCcw } from 'lucide-react';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';

const G = {
  gradSoft: 'linear-gradient(135deg, rgba(255,107,157,0.12) 0%, rgba(183,148,246,0.12) 100%)',
  grad: 'linear-gradient(135deg, #FF6B9D 0%, #B794F6 100%)',
};

function StatBar({ value, label }: { value: number; label: string }) {
  const [width, setWidth] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) { setTimeout(() => setWidth(value), 120); observer.disconnect(); } },
      { threshold: 0.3 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, [value]);
  return (
    <div className="space-y-1.5" ref={ref}>
      <div className="flex items-baseline justify-between gap-2">
        <span className="text-xs text-muted-foreground text-pretty">{label}</span>
        <span className="text-xl font-light text-primary shrink-0">{value}%</span>
      </div>
      <div className="h-1.5 w-full rounded-full bg-border overflow-hidden">
        <div className="h-full rounded-full transition-all duration-1000 ease-out"
          style={{ width: `${width}%`, background: G.grad }} />
      </div>
    </div>
  );
}

const quizQuestions = [
  {
    key: 'feeling',
    q: 'After scrolling social media, how do you usually feel?',
    options: ['Better or inspired', 'About the same', 'A bit worse', 'Significantly worse'],
    scores: [0, 1, 2, 3],
  },
  {
    key: 'comparison',
    q: 'How often do you compare your appearance or life to what you see online?',
    options: ['Rarely or never', 'Sometimes', 'Often', 'Almost always'],
    scores: [0, 1, 2, 3],
  },
  {
    key: 'screentime',
    q: 'How many hours a day do you spend on social media?',
    options: ['Under 1 hour', '1–2 hours', '2–4 hours', '4+ hours'],
    scores: [0, 1, 2, 3],
  },
];

type DimScore = 0 | 1 | 2 | 3;

const dimensionResults: Record<string, Record<DimScore, { label: string; signal: 'ok' | 'caution' | 'concern'; insight: string; action: string }>> = {
  feeling: {
    0: {
      label: 'Scrolling lifts you up',
      signal: 'ok',
      insight: "You leave social media feeling better or neutral — that's genuinely rare and healthy. You're curating a feed that serves you.",
      action: "Keep noticing. If that ever shifts, it's a sign to refresh your feed.",
    },
    1: {
      label: 'Neutral — but watch the drift',
      signal: 'ok',
      insight: "Feeling unchanged is fine, but 'neutral' can slowly become 'drained' without you noticing. Emotional flatness after scrolling is a subtle warning sign.",
      action: "Try a 3-day check-in: rate your mood out of 10 before and after opening a social app. Patterns become obvious fast.",
    },
    2: {
      label: 'Scrolling is draining you',
      signal: 'caution',
      insight: "Consistently feeling a bit worse after social media is your mind telling you something. Research shows that 'passive scrolling' — watching without interacting — is the most harmful pattern. You're absorbing content but not connecting.",
      action: "Immediately after opening an app, set a 10-minute timer. When it goes off, close the app and ask how you feel. If it's negative — that app gets moved off your home screen today.",
    },
    3: {
      label: 'Social media is hurting you',
      signal: 'concern',
      insight: "Feeling significantly worse after scrolling is a clear signal that the content you're consuming is actively working against your mental health. This isn't weakness — the apps are engineered to trigger comparison and inadequacy to keep you engaged.",
      action: "Delete the apps from your phone for 7 days. Not forever — just 7 days. Studies show mood and body image improve measurably within a week of a break. Use the browser version if you need to check in.",
    },
  },
  comparison: {
    0: {
      label: 'Comparison-resistant',
      signal: 'ok',
      insight: "You have a strong sense of your own identity offline — you're not measuring your worth against curated highlight reels. This protects your self-esteem significantly.",
      action: "Share this mindset. If friends are struggling with comparison, your perspective is genuinely valuable.",
    },
    1: {
      label: 'Occasional comparison',
      signal: 'ok',
      insight: "Comparing sometimes is completely normal — it's a human instinct. The key is whether those moments leave a lasting negative impression or pass quickly.",
      action: "When you notice comparison happening, try naming it out loud: 'That's a curated photo, not real life.' Naming it breaks its power.",
    },
    2: {
      label: 'Caught in the comparison loop',
      signal: 'caution',
      insight: "Frequent comparison is quietly eroding your self-image. What makes it insidious is that you're comparing your whole self — including your private doubts, bad days, and unfiltered moments — to someone else's most polished, filtered, best-angle version of themselves.",
      action: "Audit your following list this week. For each account, ask: 'Does this person make me feel better or worse about myself?' Unfollow anyone in the 'worse' category — you don't owe anyone your attention or your mental health.",
    },
    3: {
      label: 'Constant comparison is taking over',
      signal: 'concern',
      insight: "Comparing almost always means the online world has become the primary lens through which you measure your own value. This is directly linked to anxiety, depression, and eating disorders in research. You deserve a reality check: the 'perfect' people you're comparing yourself to are also comparing themselves to others.",
      action: "For 2 weeks, follow only accounts that post about skills, hobbies, humour, or causes — not appearance or lifestyle. Your feed is your mental diet. Change the inputs, change the outputs.",
    },
  },
  screentime: {
    0: {
      label: 'Minimal exposure',
      signal: 'ok',
      insight: "Under 1 hour a day means social media is a tool you use, not a world you live in. You have significantly more time for real experiences, relationships, and rest.",
      action: "Stay intentional about keeping it this way as you get older — the apps are designed to creep upwards.",
    },
    1: {
      label: 'Manageable usage',
      signal: 'ok',
      insight: "1–2 hours is within the range most researchers consider moderate. It becomes a problem mainly when that time replaces sleep, exercise, or face-to-face connection.",
      action: "Check when you're using it — late-night scrolling in bed is far more harmful than the same time during the day. Move your charger out of your bedroom if that's you.",
    },
    2: {
      label: '2–4 hours is a significant chunk',
      signal: 'caution',
      insight: "That's up to 28 hours a week — roughly a part-time job's worth of hours — spent on apps engineered to maximize time-on-screen. Research consistently shows this range correlates with increased anxiety and reduced life satisfaction in teens.",
      action: "Set a hard daily limit using your phone's built-in Screen Time or Digital Wellbeing tools. Start with reducing by 30 minutes. In one week, reduce by another 30. Small reductions compound.",
    },
    3: {
      label: '4+ hours: the apps have won',
      signal: 'concern',
      insight: "4+ hours a day means social media is crowding out sleep, homework, exercise, and real relationships. This isn't a character flaw — these platforms employ teams of engineers to make you stay this long. But the consequences fall on you, not them.",
      action: "Try this: delete all social apps from your home screen and put them in a folder three swipes deep. Not deleted — just inconvenient. Friction breaks automatic habits. Track usage for 7 days. Then decide what's worth keeping.",
    },
  },
};

function getSignalStyle(signal: 'ok' | 'caution' | 'concern') {
  if (signal === 'ok')      return { color: 'text-green-600 dark:text-green-400', border: 'border-green-500/25', bg: 'bg-green-500/5',  dot: 'bg-green-500' };
  if (signal === 'caution') return { color: 'text-amber-600 dark:text-amber-400', border: 'border-amber-500/25', bg: 'bg-amber-500/5', dot: 'bg-amber-500' };
  return                           { color: 'text-destructive',                    border: 'border-destructive/25', bg: 'bg-destructive/5', dot: 'bg-destructive' };
}

const dimensionLabels: Record<string, string> = {
  feeling: 'How scrolling makes you feel',
  comparison: 'How often you compare yourself',
  screentime: 'Daily screen time',
};

export default function OnlineComparisonPage() {
  const [quizAnswers, setQuizAnswers] = useState<(number | null)[]>([null, null, null]);
  const [quizSubmitted, setQuizSubmitted] = useState(false);

  const allAnswered = quizAnswers.every(a => a !== null);
  const compareAreas = [
    { icon: Instagram, title: 'Physical Appearance', desc: 'Body shape, face, skin, hair, makeup, and fashion choices compared to filtered and edited images' },
    { icon: Sparkles, title: 'Lifestyle & Experiences', desc: 'Vacations, parties, events, and daily activities that seem more exciting than your own life' },
    { icon: Users, title: 'Relationships & Popularity', desc: 'Number of friends, romantic relationships, likes, comments, and followers' },
    { icon: BookOpen, title: 'Achievements & Success', desc: 'Academic performance, talents, awards, and accomplishments that others showcase' },
  ];

  const impacts = [
    { icon: TrendingDown, title: 'Low Self-Esteem & Body Image Issues', desc: 'Constantly comparing yourself to edited, filtered images can make you feel inadequate about your appearance and worth' },
    { icon: Heart, title: 'Anxiety & Depression', desc: 'Fear of missing out (FOMO), social anxiety, and feelings of loneliness even when surrounded by people' },
    { icon: Brain, title: 'Sleep Disruption', desc: 'Late-night scrolling affects sleep quality, which impacts mood, concentration, and overall health' },
    { icon: Shield, title: 'Perfectionism & Pressure', desc: 'Feeling like you need to present a perfect image online, leading to stress and exhaustion' },
  ];

  const dailyRisks = [
    { icon: BookOpen, title: 'Academic Performance', desc: 'Distraction and reduced focus on schoolwork and studying' },
    { icon: Users, title: 'Real Relationships', desc: 'Less quality time with family and friends in person' },
    { icon: Dumbbell, title: 'Physical Health', desc: 'Less exercise, poor posture, eye strain, and disrupted eating patterns' },
    { icon: Sparkles, title: 'Hobbies & Interests', desc: 'Less time for activities you actually enjoy doing' },
    { icon: Brain, title: 'Self-Identity', desc: 'Difficulty knowing who you really are versus who you present online' },
  ];

  const truths = [
    { title: "It's Not Real Life", desc: "People only post their best moments. You're comparing your everyday reality to someone else's highlight reel." },
    { title: 'Filters & Editing Are Everywhere', desc: 'Most images are filtered, edited, or enhanced. Even "natural" photos are often carefully curated and edited.' },
    { title: 'Everyone Feels This Way', desc: "Even people who seem perfect online struggle with comparison and insecurity. You're not alone in feeling this way." },
  ];

  const habits = [
    { num: 1, icon: Clock, title: 'Set Actual Time Limits (And Stick to Them)', body: 'Go to your phone settings → Screen Time (iPhone) or Digital Wellbeing (Android) → Set app limits for Instagram, TikTok, Snapchat to 30-60 minutes per day total.', note: "Why this works: You'll be shocked how much time you're actually spending." },
    { num: 2, icon: Users, title: 'Unfollow Anyone Who Makes You Feel Bad', body: "Influencers, celebrities, even friends — if their posts make you feel inadequate, jealous, or anxious, unfollow them. You don't owe anyone your attention.", note: 'How to do it: Go through your following list. If you see someone and think "ugh," hit unfollow.' },
    { num: 3, icon: Eye, title: 'Turn Off Notifications (Seriously)', body: "Every notification pulls you back in. Turn off all social media notifications. Check apps when YOU want to, not when they tell you to.", note: 'Settings → Notifications → Turn off badges, sounds, and banners for social apps.' },
    { num: 4, icon: Shield, title: 'No Phone Zones', body: 'Create times and places where your phone doesn\'t exist: during meals, in your bedroom at night, during homework, when hanging out with friends.', note: 'Try this: Charge your phone outside your bedroom at night. Your sleep will improve instantly.' },
    { num: 5, icon: Sparkles, title: 'Do Something Real', body: 'When you catch yourself scrolling mindlessly, put your phone down and do anything else: draw, read, go for a walk, listen to music, cook something.', note: 'Make a list of 5 things you enjoy that don\'t involve a screen. When bored, pick one.' },
    { num: 6, icon: Brain, title: "Remember: It's All Fake", body: "Every photo you see is the best of 50 takes. Every body is edited. You're comparing your real life to everyone else's fake highlight reel.", note: "Try this: Next time you post, notice how many photos you took before picking 'the one.'" },
    { num: 7, icon: Heart, title: 'Talk to Someone', body: "If social media is seriously affecting your mental health, tell someone. A parent, school counselor, therapist, or trusted adult.", note: 'Crisis Text Line: Text HOME to 741741 anytime, free, confidential support.' },
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-12 p-4 md:p-8">
      {/* Hero */}
      <div className="space-y-3">
        <p className="text-xs font-semibold tracking-widest uppercase text-muted-foreground">Mental Health</p>
        <h1 className="text-3xl md:text-4xl font-light tracking-tight text-balance">Social Media Comparison & Daily Life Risks</h1>
        <p className="text-base text-muted-foreground text-pretty">
          Understanding how online comparison affects mental health and daily life
        </p>
      </div>

      {/* Social media mood check-in quiz */}
      <section className="space-y-5 animate-fade-in">
        <div className="flex items-start gap-3">
          <div className="h-9 w-9 rounded-xl flex items-center justify-center shrink-0" style={{ background: G.gradSoft }}>
            <Sparkles className="h-4.5 w-4.5 text-primary" strokeWidth={1.75} />
          </div>
          <div>
            <h2 className="text-xl font-light tracking-tight">Quick Check-In</h2>
            <p className="text-sm text-muted-foreground">3 questions to reflect on how social media is affecting you</p>
          </div>
        </div>
        <div className="rounded-xl border border-border p-5 space-y-6">
          {quizQuestions.map((q, qi) => (
            <div key={qi} className="space-y-3">
              <p className="text-sm font-medium text-foreground">{qi + 1}. {q.q}</p>
              <div className="grid grid-cols-2 gap-2">
                {q.options.map((opt, oi) => {
                  const selected = quizAnswers[qi] === oi;
                  return (
                    <button key={oi} onClick={() => {
                      const next = [...quizAnswers]; next[qi] = oi; setQuizAnswers(next);
                      setQuizSubmitted(false);
                    }}
                      className={[
                        'text-left text-xs px-3 py-2.5 rounded-lg border transition-all duration-150',
                        selected
                          ? 'border-primary/50 bg-primary/8 text-primary font-medium'
                          : 'border-border text-muted-foreground hover:border-primary/30 hover:text-foreground',
                      ].join(' ')}>
                      {opt}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
          <button
            disabled={!allAnswered}
            onClick={() => setQuizSubmitted(true)}
            className="w-full h-10 rounded-lg text-sm font-medium transition-all duration-200
              disabled:opacity-40 disabled:cursor-not-allowed
              enabled:text-primary-foreground enabled:hover:opacity-90"
            style={allAnswered ? { background: G.grad } : { background: 'hsl(var(--border))' }}>
            See my result
          </button>
          {quizSubmitted && (
            <div className="space-y-3 animate-fade-in pt-1">
              <p className="text-xs font-semibold tracking-widest uppercase text-muted-foreground pb-1">Your results — 3 dimensions</p>
              {quizQuestions.map((q, qi) => {
                const answerIdx = quizAnswers[qi];
                if (answerIdx === null) return null;
                const score = q.scores[answerIdx] as DimScore;
                const dimResult = dimensionResults[q.key][score];
                const style = getSignalStyle(dimResult.signal);
                return (
                  <div key={q.key} className={['rounded-xl border p-4 space-y-2', style.border, style.bg].join(' ')}>
                    <div className="flex items-start gap-2">
                      <div className={['h-2 w-2 rounded-full shrink-0 mt-1.5', style.dot].join(' ')} />
                      <div className="min-w-0 flex-1">
                        <p className="text-[10px] font-semibold tracking-widest uppercase text-muted-foreground mb-0.5">
                          {dimensionLabels[q.key]}
                        </p>
                        <p className={['text-sm font-semibold', style.color].join(' ')}>{dimResult.label}</p>
                      </div>
                    </div>
                    <p className="text-sm text-muted-foreground text-pretty leading-relaxed pl-4">{dimResult.insight}</p>
                    <div className="flex items-start gap-2 pl-4 pt-1 border-t border-current/10">
                      <ChevronRight className="h-3.5 w-3.5 text-primary shrink-0 mt-0.5" strokeWidth={2} />
                      <p className="text-xs text-foreground font-medium text-pretty">{dimResult.action}</p>
                    </div>
                  </div>
                );
              })}
              <button onClick={() => { setQuizAnswers([null, null, null]); setQuizSubmitted(false); }}
                className="text-xs text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1.5">
                <RotateCcw className="h-3 w-3" strokeWidth={1.75} /> Retake check-in
              </button>
            </div>
          )}
        </div>
      </section>

      {/* Stats with bars */}
      <section className="space-y-5 opacity-0 intersect:opacity-100 transition duration-700">
        <div className="flex items-start gap-3">
          <div className="h-9 w-9 rounded-xl flex items-center justify-center shrink-0" style={{ background: G.gradSoft }}>
            <Instagram className="h-4.5 w-4.5 text-primary" strokeWidth={1.75} />
          </div>
          <div>
            <h2 className="text-xl font-light tracking-tight">The Comparison Trap</h2>
            <p className="text-sm text-muted-foreground">Social media creates unrealistic standards that affect how we see ourselves</p>
          </div>
        </div>
        <div className="rounded-xl border border-border p-5 space-y-5">
          <StatBar value={87} label="of teen girls compare themselves to images they see on social media" />
          <StatBar value={50} label="of girls say social media makes them feel worse about their appearance" />
          <StatBar value={35} label="of teen girls are 'almost constantly' on social media" />
        </div>
      </section>

      {/* What we compare — icon cards */}
      <section className="space-y-5 opacity-0 intersect:opacity-100 transition duration-700">
        <div className="flex items-start gap-3">
          <div className="h-9 w-9 rounded-xl flex items-center justify-center shrink-0" style={{ background: G.gradSoft }}>
            <Eye className="h-4.5 w-4.5 text-primary" strokeWidth={1.75} />
          </div>
          <div>
            <h2 className="text-xl font-light tracking-tight">What We Compare Online</h2>
            <p className="text-sm text-muted-foreground">Common areas where comparison happens</p>
          </div>
        </div>
        <div className="grid gap-3 md:grid-cols-2">
          {compareAreas.map(({ icon: Icon, title, desc }) => (
            <div key={title} className="rounded-xl border border-border p-4 flex items-start gap-3 h-full">
              <div className="shrink-0 mt-0.5 h-8 w-8 rounded-lg flex items-center justify-center" style={{ background: G.gradSoft }}>
                <Icon className="h-4 w-4 text-primary" strokeWidth={1.75} />
              </div>
              <div className="space-y-0.5 min-w-0">
                <p className="text-sm font-medium text-foreground">{title}</p>
                <p className="text-xs text-muted-foreground leading-relaxed text-pretty">{desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Mental health impact */}
      <section className="space-y-5 opacity-0 intersect:opacity-100 transition duration-700">
        <div className="flex items-start gap-3">
          <div className="h-9 w-9 rounded-xl flex items-center justify-center shrink-0" style={{ background: G.gradSoft }}>
            <Brain className="h-4.5 w-4.5 text-primary" strokeWidth={1.75} />
          </div>
          <div>
            <h2 className="text-xl font-light tracking-tight">Mental Health & Emotional Effects</h2>
            <p className="text-sm text-muted-foreground">How constant comparison impacts your wellbeing</p>
          </div>
        </div>
        <div className="grid gap-3 md:grid-cols-2">
          {impacts.map(({ icon: Icon, title, desc }) => (
            <div key={title} className="rounded-xl border border-border p-4 flex items-start gap-3 h-full">
              <div className="shrink-0 mt-0.5 h-8 w-8 rounded-lg flex items-center justify-center" style={{ background: G.gradSoft }}>
                <Icon className="h-4 w-4 text-primary" strokeWidth={1.75} />
              </div>
              <div className="space-y-0.5 min-w-0">
                <p className="text-sm font-medium text-foreground">{title}</p>
                <p className="text-xs text-muted-foreground leading-relaxed text-pretty">{desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Daily risks */}
      <section className="space-y-5 opacity-0 intersect:opacity-100 transition duration-700">
        <div className="flex items-start gap-3">
          <div className="h-9 w-9 rounded-xl flex items-center justify-center shrink-0" style={{ background: G.gradSoft }}>
            <TrendingDown className="h-4.5 w-4.5 text-primary" strokeWidth={1.75} />
          </div>
          <div>
            <h2 className="text-xl font-light tracking-tight">Daily Life Risks & Real-World Impact</h2>
            <p className="text-sm text-muted-foreground">How social media comparison affects your everyday life</p>
          </div>
        </div>
        <div className="space-y-2">
          {dailyRisks.map(({ icon: Icon, title, desc }) => (
            <div key={title} className="flex items-start gap-3 p-3 rounded-xl border border-border">
              <div className="shrink-0 mt-0.5 h-7 w-7 rounded-lg flex items-center justify-center" style={{ background: G.gradSoft }}>
                <Icon className="h-3.5 w-3.5 text-primary" strokeWidth={1.75} />
              </div>
              <div className="min-w-0">
                <span className="text-sm font-medium text-foreground">{title}: </span>
                <span className="text-sm text-muted-foreground">{desc}</span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* The truth */}
      <section className="space-y-5 opacity-0 intersect:opacity-100 transition duration-700">
        <div className="flex items-start gap-3">
          <div className="h-9 w-9 rounded-xl flex items-center justify-center shrink-0" style={{ background: G.gradSoft }}>
            <Eye className="h-4.5 w-4.5 text-primary" strokeWidth={1.75} />
          </div>
          <div>
            <h2 className="text-xl font-light tracking-tight">The Truth About What You See Online</h2>
          </div>
        </div>
        <div className="grid gap-3 md:grid-cols-3">
          {truths.map(({ title, desc }) => (
            <div key={title} className="rounded-xl border border-primary/20 p-4 space-y-2 h-full">
              <p className="text-sm font-medium text-foreground">{title}</p>
              <p className="text-xs text-muted-foreground text-pretty">{desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Healthy habits — numbered steps */}
      <section className="space-y-5 opacity-0 intersect:opacity-100 transition duration-700">
        <div className="flex items-start gap-3">
          <div className="h-9 w-9 rounded-xl flex items-center justify-center shrink-0" style={{ background: G.gradSoft }}>
            <Sparkles className="h-4.5 w-4.5 text-primary" strokeWidth={1.75} />
          </div>
          <div>
            <h2 className="text-xl font-light tracking-tight">How to Actually Feel Better</h2>
            <p className="text-sm text-muted-foreground">Practical steps you can take today</p>
          </div>
        </div>

        <div className="rounded-xl border border-primary/25 p-4 flex items-start gap-3">
          <Heart className="h-4 w-4 text-primary shrink-0 mt-0.5" strokeWidth={1.5} />
          <div>
            <p className="text-sm font-medium text-foreground mb-1">Start Here: The 5-Minute Check-In</p>
            <p className="text-sm text-muted-foreground text-pretty">
              Before you open Instagram, TikTok, or any social app, ask yourself: "How do I feel right now?" Then check again after 10 minutes of scrolling. If you feel worse, close the app. Your mental health is more important than staying updated.
            </p>
          </div>
        </div>

        <Accordion type="single" collapsible className="space-y-2">
          {habits.map(({ num, icon: Icon, title, body, note }) => (
            <AccordionItem key={num} value={`habit-${num}`}
              className="rounded-xl border border-border overflow-hidden px-0">
              <AccordionTrigger className="px-4 py-3 hover:no-underline hover:bg-muted/40 transition-colors">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="h-7 w-7 rounded-full flex items-center justify-center font-semibold text-xs text-white shrink-0"
                    style={{ background: G.grad }}>{num}</div>
                  <div className="h-6 w-6 rounded-lg flex items-center justify-center shrink-0" style={{ background: G.gradSoft }}>
                    <Icon className="h-3 w-3 text-primary" strokeWidth={1.75} />
                  </div>
                  <span className="text-sm font-medium text-foreground text-left truncate">{title}</span>
                </div>
              </AccordionTrigger>
              <AccordionContent className="px-4 pb-4 pt-1 pl-[calc(1rem+1.75rem+1.5rem+1.5rem)]">
                <div className="space-y-1.5">
                  <p className="text-sm text-muted-foreground text-pretty">{body}</p>
                  <p className="text-xs italic text-muted-foreground text-pretty flex items-start gap-1.5">
                    <ChevronRight className="h-3 w-3 shrink-0 mt-0.5 text-primary" strokeWidth={2} />
                    {note}
                  </p>
                </div>
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>

        <div className="rounded-xl border border-border p-4">
          <p className="text-sm font-medium text-foreground mb-1">What If I Can't Give Up Social Media?</p>
          <p className="text-sm text-muted-foreground text-pretty">
            You don't have to quit completely. Just make it work FOR you instead of against you. Start with one thing from this list. Even small changes make a huge difference.
          </p>
        </div>

        <div className="rounded-xl border border-primary/20 p-4">
          <p className="text-sm text-muted-foreground text-pretty">
            <strong className="text-foreground">Remember:</strong> You are enough exactly as you are right now. Your worth isn't measured in likes, followers, or how you look in photos. The people who love you don't care about any of that. And neither should you.
          </p>
        </div>
      </section>
    </div>
  );
}
