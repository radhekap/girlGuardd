import { useState } from'react';
import { Label } from'@/components/ui/label';
import { Button } from'@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from'@/components/ui/select';
import { Scale, ExternalLink, AlertCircle, Shield, BookOpen } from'lucide-react';

const G = {
  gradSoft: 'linear-gradient(135deg, rgba(255,107,157,0.12) 0%, rgba(183,148,246,0.12) 100%)',
  grad: 'linear-gradient(135deg, #FF6B9D 0%, #B794F6 100%)',
};

interface Law { title: string; summary: string; link: string; category: string; }

const federalLaws: Law[] = [
  { title:"Children's Online Privacy Protection Act (COPPA)", summary:'Protects children under 13 by requiring parental consent before collecting personal information online. Gives parents control over what information websites can collect from their kids.', link:'https://www.ftc.gov/business-guidance/privacy-security/childrens-privacy', category:'Privacy & Protection' },
  { title:'Federal Cyberstalking Law (18 U.S.C. § 2261A)', summary:'Makes it a federal crime to use electronic communications to stalk, harass, or threaten someone. Covers online harassment that crosses state lines or uses interstate communications.', link:'https://www.justice.gov/d9/2023-03/cyberstalking_0.pdf', category:'Harassment & Stalking' },
  { title:'Federal Sextortion Law', summary:'Criminalizes threatening to share intimate images to coerce someone into providing more images, money, or sexual acts. Carries severe federal penalties including prison time.', link:'https://www.fbi.gov/how-we-can-help-you/victim-services/scams-and-safety/common-scams-and-crimes/sextortion', category:'Image-Based Abuse' },
  { title:'Computer Fraud and Abuse Act (CFAA)', summary:"Prohibits unauthorized access to computers and online accounts. Covers hacking, password theft, and accessing someone's accounts without permission.", link:'https://www.law.cornell.edu/uscode/text/18/1030', category:'Cybercrime' },
  { title:'Federal Child Exploitation Laws', summary:'Strictly prohibits creating, distributing, or possessing explicit images of minors. Even self-produced images by minors can be illegal. Victims have legal protections.', link:'https://www.ncmec.org/what-we-do/child-sexual-exploitation/', category:'Child Protection' },
];

const stateLawResources = [
  { title:'Cyber Civil Rights Initiative - State Law Database', description:'Comprehensive database of state laws on image-based abuse, cyberstalking, and online harassment', link:'https://cybercivilrights.org/ccri-state-law-database/' },
  { title:'National Conference of State Legislatures - Cyberstalking Laws', description:'State-by-state breakdown of cyberstalking and online harassment laws', link:'https://www.ncsl.org/technology-and-communication/cyberstalking-and-cyberharassment-laws' },
  { title:'FindLaw - State Computer Crime Laws', description:'Directory of computer crime and cybersecurity laws by state', link:'https://www.findlaw.com/criminal/criminal-charges/computer-crime-laws-by-state.html' },
];

const legalAidOrganizations = [
  { title:'Cyber Civil Rights Initiative', description:'Free legal referrals and support for victims of non-consensual image sharing and online abuse', link:'https://cybercivilrights.org/' },
  { title:'National Center for Victims of Crime', description:'Resources and referrals for crime victims, including cybercrime', link:'https://victimsofcrime.org/' },
  { title:'Legal Services Corporation - Find Legal Aid', description:'Find free legal aid in your area', link:'https://www.lsc.gov/about-lsc/what-legal-aid/get-legal-help' },
  { title:'StopNCII – Stop Non-Consensual Intimate Images', description:'Free tool and support hub to help prevent sharing of intimate images without consent', link:'https://stopncii.org/' },
];

export default function CybersecurityLawsPage() {
  const [selectedCountry, setSelectedCountry] = useState('');
  const [selectedState, setSelectedState] = useState('');
  const [showLaws, setShowLaws] = useState(false);

  const usStates = ['Alabama','Alaska','Arizona','Arkansas','California','Colorado','Connecticut','Delaware','Florida','Georgia','Hawaii','Idaho','Illinois','Indiana','Iowa','Kansas','Kentucky','Louisiana','Maine','Maryland','Massachusetts','Michigan','Minnesota','Mississippi','Missouri','Montana','Nebraska','Nevada','New Hampshire','New Jersey','New Mexico','New York','North Carolina','North Dakota','Ohio','Oklahoma','Oregon','Pennsylvania','Rhode Island','South Carolina','South Dakota','Tennessee','Texas','Utah','Vermont','Virginia','Washington','West Virginia','Wisconsin','Wyoming'];

  return (
    <div className="max-w-4xl mx-auto space-y-12 p-4 md:p-8">

      {/* Hero */}
      <div className="space-y-3">
        <p className="text-xs font-semibold tracking-widest uppercase text-muted-foreground">Legal Resources</p>
        <h1 className="text-3xl md:text-4xl font-light tracking-tight">Cybersecurity Laws</h1>
        <p className="text-base text-muted-foreground">
          Understand your legal rights and find laws that protect you from online abuse.
        </p>
      </div>

      {/* Disclaimer */}
      <div className="rounded-xl border border-primary/25 p-4 flex items-start gap-3">
        <AlertCircle className="h-4 w-4 text-primary shrink-0 mt-0.5" strokeWidth={1.5} />
        <div className="space-y-0.5">
          <p className="text-sm font-medium text-foreground">Educational Information Only</p>
          <p className="text-sm text-muted-foreground text-pretty">
            This information is for educational purposes and does not constitute legal advice. Laws change frequently. For specific legal guidance, consult a licensed attorney in your area.
          </p>
        </div>
      </div>

      {/* Location selector */}
      <section className="space-y-5 opacity-0 intersect:opacity-100 transition duration-700">
        <div className="flex items-start gap-3">
          <div className="h-9 w-9 rounded-xl flex items-center justify-center shrink-0" style={{ background: G.gradSoft }}>
            <Scale className="h-4.5 w-4.5 text-primary" strokeWidth={1.75} />
          </div>
          <div>
            <h2 className="text-xl font-light tracking-tight">Find Laws in Your Area</h2>
            <p className="text-sm text-muted-foreground">Select your location to see relevant cybersecurity and online safety laws</p>
          </div>
        </div>
        <div className="rounded-xl border border-border p-5 space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="country" className="text-sm font-normal">Country/Region</Label>
              <Select value={selectedCountry} onValueChange={setSelectedCountry}>
                <SelectTrigger id="country"><SelectValue placeholder="Select country" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="us">United States</SelectItem>
                  <SelectItem value="other">Other (See Resources Below)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {selectedCountry === 'us' && (
              <div className="space-y-2">
                <Label htmlFor="state" className="text-sm font-normal">State</Label>
                <Select value={selectedState} onValueChange={setSelectedState}>
                  <SelectTrigger id="state"><SelectValue placeholder="Select state" /></SelectTrigger>
                  <SelectContent>
                    {usStates.map(state => (
                      <SelectItem key={state} value={state.toLowerCase().replace(/ /g, '-')}>{state}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
          </div>
          <Button onClick={() => { if (selectedCountry) setShowLaws(true); }} disabled={!selectedCountry}>
            Show Laws & Resources
          </Button>
        </div>
      </section>

      {/* Federal laws */}
      {showLaws && selectedCountry === 'us' && (
        <>
          <section className="space-y-5">
            <div className="flex items-start gap-3">
              <div className="h-9 w-9 rounded-xl flex items-center justify-center shrink-0" style={{ background: G.gradSoft }}>
                <Shield className="h-4.5 w-4.5 text-primary" strokeWidth={1.75} />
              </div>
              <div>
                <h2 className="text-xl font-light tracking-tight">Federal Laws (Apply to All States)</h2>
              </div>
            </div>
            <div className="space-y-3">
              {federalLaws.map((law) => (
                <div key={law.title} className="rounded-xl border border-border p-4 space-y-2">
                  <div className="flex items-start justify-between gap-3 flex-wrap">
                    <p className="text-sm font-medium text-foreground">{law.title}</p>
                    <span className="text-xs px-2 py-0.5 rounded-full border border-primary/20 text-primary shrink-0">{law.category}</span>
                  </div>
                  <p className="text-xs text-muted-foreground text-pretty">{law.summary}</p>
                  <a href={law.link} target="_blank" rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-xs text-primary hover:underline">
                    Read Full Law <ExternalLink className="h-3 w-3" />
                  </a>
                </div>
              ))}
            </div>
          </section>

          <section className="space-y-4">
            <div className="flex items-start gap-3">
              <div className="h-9 w-9 rounded-xl flex items-center justify-center shrink-0" style={{ background: G.gradSoft }}>
                <BookOpen className="h-4.5 w-4.5 text-primary" strokeWidth={1.75} />
              </div>
              <div>
                <h2 className="text-xl font-light tracking-tight">
                  {selectedState ? `${usStates.find(s => s.toLowerCase().replace(/ /g, '-') === selectedState)} State Laws` : 'State-Specific Laws'}
                </h2>
                <p className="text-sm text-muted-foreground">Use these resources to find laws specific to your state</p>
              </div>
            </div>
            <div className="space-y-2">
              {stateLawResources.map(r => (
                <div key={r.title} className="rounded-xl border border-border p-4 flex items-start gap-3">
                  <ExternalLink className="h-4 w-4 text-primary shrink-0 mt-0.5" strokeWidth={1.5} />
                  <div className="space-y-0.5 min-w-0">
                    <a href={r.link} target="_blank" rel="noopener noreferrer" className="text-sm font-medium hover:underline text-foreground">{r.title}</a>
                    <p className="text-xs text-muted-foreground">{r.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </section>
        </>
      )}

      {showLaws && selectedCountry === 'other' && (
        <section className="space-y-4">
          <div className="flex items-start gap-3">
            <div className="h-9 w-9 rounded-xl flex items-center justify-center shrink-0" style={{ background: G.gradSoft }}>
              <Scale className="h-4.5 w-4.5 text-primary" strokeWidth={1.75} />
            </div>
            <div>
              <h2 className="text-xl font-light tracking-tight">International Resources</h2>
              <p className="text-sm text-muted-foreground">Resources for finding cybersecurity laws outside the United States</p>
            </div>
          </div>
          <div className="space-y-2">
            {[
              { title: 'INTERPOL Cybercrime Resources', desc: 'International cybercrime information and reporting resources', link: 'https://www.interpol.int/Crimes/Cybercrime' },
              { title: 'UN Office on Drugs and Crime - Cybercrime', desc: 'Global cybercrime resources and country-specific information', link: 'https://www.unodc.org/unodc/en/cybercrime/index.html' },
            ].map(r => (
              <div key={r.title} className="rounded-xl border border-border p-4 flex items-start gap-3">
                <ExternalLink className="h-4 w-4 text-primary shrink-0 mt-0.5" strokeWidth={1.5} />
                <div className="space-y-0.5 min-w-0">
                  <a href={r.link} target="_blank" rel="noopener noreferrer" className="text-sm font-medium hover:underline text-foreground">{r.title}</a>
                  <p className="text-xs text-muted-foreground">{r.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Legal Aid Organizations */}
      <section className="space-y-5 opacity-0 intersect:opacity-100 transition duration-700">
        <div className="flex items-start gap-3">
          <div className="h-9 w-9 rounded-xl flex items-center justify-center shrink-0 border border-primary/30">
            <Shield className="h-4.5 w-4.5 text-primary" strokeWidth={1.75} />
          </div>
          <div>
            <h2 className="text-xl font-light tracking-tight">Legal Aid & Support Organizations</h2>
            <p className="text-sm text-muted-foreground">Free and low-cost legal help for victims of cybercrime</p>
          </div>
        </div>
        <div className="grid gap-3 md:grid-cols-2">
          {legalAidOrganizations.map(org => (
            <div key={org.title} className="rounded-xl border border-border p-4 flex items-start gap-3 h-full">
              <ExternalLink className="h-4 w-4 text-primary shrink-0 mt-0.5" strokeWidth={1.5} />
              <div className="space-y-0.5 min-w-0">
                <a href={org.link} target="_blank" rel="noopener noreferrer" className="text-sm font-medium hover:underline text-foreground">{org.title}</a>
                <p className="text-xs text-muted-foreground text-pretty">{org.description}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Your Legal Rights */}
      <section className="space-y-5 opacity-0 intersect:opacity-100 transition duration-700">
        <div className="flex items-start gap-3">
          <div className="h-9 w-9 rounded-xl flex items-center justify-center shrink-0" style={{ background: G.gradSoft }}>
            <Scale className="h-4.5 w-4.5 text-primary" strokeWidth={1.75} />
          </div>
          <div>
            <h2 className="text-xl font-light tracking-tight">Your Legal Rights</h2>
            <p className="text-sm text-muted-foreground">Important rights you have as a victim of online abuse</p>
          </div>
        </div>
        <div className="grid gap-3 md:grid-cols-2">
          {[
            { title: 'Right to Report', desc: "You have the right to report cybercrimes to law enforcement, even if you're a minor. You won't get in trouble for being a victim." },
            { title: 'Right to Protection', desc: 'Courts can issue restraining orders and protective orders against people who harass or threaten you online.' },
            { title: 'Right to Remove Content', desc: 'Under certain laws, you can request removal of non-consensual intimate images from websites and platforms.' },
            { title: 'Right to Privacy', desc: 'Your personal information is protected by various privacy laws. Unauthorized sharing can be illegal.' },
            { title: 'Right to Legal Representation', desc: 'You have the right to consult with an attorney. Many organizations offer free legal help to victims.' },
          ].map(({ title, desc }) => (
            <div key={title} className="rounded-xl border border-border p-4 space-y-1.5 h-full">
              <div className="flex items-center gap-2">
                <div className="h-1.5 w-1.5 rounded-full shrink-0" style={{ background: G.grad }} />
                <p className="text-sm font-medium text-foreground">{title}</p>
              </div>
              <p className="text-xs text-muted-foreground text-pretty pl-3.5">{desc}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
